# Contributing

Thanks for looking. This is a small project and contributions are genuinely welcome.

## The most useful thing you can do

**Tell us about a bank whose messages don't parse.** There is no analytics in this app, so we have no idea a format is broken unless someone says so. This is the single most valuable kind of report.

Before opening one, try the built-in tools — you may be able to fix it yourself without waiting for us:

1. **Settings → Developer mode → Parser sandbox** — paste a message and see exactly what the parser extracts.
2. **Settings → Bank SMS senders** — attach a custom rule to that sender with your own regex.

If you get a working rule, please share it in an issue. It can ship as a default for everyone else.

**When reporting a message format, redact it first.** Replace the amount with a fake one, and replace account digits with `XXXX`. We need the *shape* of the message, not your actual transaction. Never paste a full unredacted bank SMS.

## Reporting bugs

Include:

- Android version and device model (some manufacturers restrict background work and notification access in ways we can't detect)
- What you did, what happened, what you expected
- Whether encryption was on
- The stack trace, if the app crashed

Please **never** include passwords, passphrases, full account numbers, or unredacted bank messages.

## Code contributions

### Ground rules

The money model is load-bearing. Please don't break these without discussing it first — each one exists because breaking it produces a silently wrong number rather than a crash, which is much worse:

1. **Money is `Long` minor units. Never `Double`, never `Float`.** Not for display, not for intermediate maths, not "just this once."
2. **Currency travels with the amount.** No function should accept a bare amount without knowing its currency.
3. **Never sum across currencies.** If you need a total, accumulate into a `MoneyBag`. If you find yourself wanting a single combined figure, that's the design telling you no.
4. **Never auto-convert using a stored rate.** Rates exist only to pre-fill a suggestion the user then confirms. A rate the user accepted is frozen onto that record permanently.
5. **Balances are derived, never stored.**
6. **No `INTERNET` permission.** Ever. Any PR adding it, or adding a dependency that requires it, will be declined. This is the app's central promise.

### Adding a database field

1. Add it to the entity **with a default value**
2. Bump `DB_VERSION` in `AppDatabase.kt`
3. Add a `Migration` with the `ALTER TABLE`

Destructive migration is deliberately disabled. Skipping step 3 crashes on next launch rather than silently deleting someone's financial history — please keep it that way.

### Tests

Run `./gradlew test` before opening a PR.

If you touch money maths, the people/settlement logic, or the parser, **add a test**. The existing suite in `MoneyTest.kt` is the pattern to follow. Each test's comment should explain *why* the rule matters, not just what it asserts.

### Style

- Match the surrounding code; there's no formatter enforced.
- Comments should explain *why*, not restate *what*. The existing code aims for this — if a comment would just narrate the next line, leave it out.
- User-facing text: plain English, no jargon, no exclamation marks. Say "Couldn't encrypt the database. Your data is unchanged," not "Error! Operation failed!"

## Translations

Not yet set up — user-facing strings are currently inline in the Compose code rather than in `strings.xml`. Extracting them is a genuinely useful contribution if you'd like to take it on; open an issue first so two people don't do it at once.

## Licence

Contributions are accepted under GPL-3.0, the same licence as the project. By opening a PR you're agreeing your contribution can be distributed under it.

## Contact

ops@sahilshaikh.org
