---
name: Bug report
about: Something is broken or behaving wrongly
title: ""
labels: bug
---

**Never include** passwords, passphrases, full account numbers, or unredacted bank messages.

### What happened

### What you expected

### Steps to reproduce

1.
2.
3.

### Was encryption enabled?

- [ ] Yes
- [ ] No
- [ ] Was in the middle of enabling it

### Does it involve more than one currency?

<!--
Worth asking specifically: most subtle bugs in this app are multi-currency
ones. If a figure looks wrong, tell us which currencies were involved.
-->

### If a figure was wrong

<!-- What the app showed, and what it should have shown. Made-up amounts are fine. -->

### Device

- Android version:
- Device model:
- App version:
- Installed from: <!-- direct APK / Obtainium / F-Droid / built it myself -->

### Stack trace, if it crashed

```
```
