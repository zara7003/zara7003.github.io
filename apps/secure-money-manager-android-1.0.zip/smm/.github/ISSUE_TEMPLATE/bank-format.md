---
name: Bank messages not parsing
about: A bank's SMS or notifications aren't being read correctly
title: "[Bank format] "
labels: bank-format
---

**Please redact before posting.** Replace the amount with a made-up one and account digits with `XXXX`. We need the *shape* of the message, not your real transaction. Never paste an unredacted bank SMS.

### Bank and country

<!-- e.g. "Qatar National Bank, Qatar" -->

### Source

- [ ] SMS
- [ ] App notification (which app: )

### A redacted example message

```
e.g. Your card ending XXXX was debited QAR 123.45 at SOME MERCHANT on 01-01-26.
```

### What the app did

- [ ] Nothing appeared at all
- [ ] Wrong amount
- [ ] Wrong currency
- [ ] Wrong direction (income vs expense)
- [ ] Wrong or missing merchant
- [ ] Went to the wrong account

### What the parser sandbox shows

<!--
Settings → Developer mode → Parser sandbox, paste the redacted message,
and tell us what it extracted. This saves a lot of guessing.
-->

### Did you get a working rule?

<!--
If you managed to fix it yourself in Settings → Bank SMS senders, please
paste the regex here — it can ship as a default so nobody else hits this.
-->

### Device

- Android version:
- Device model:
