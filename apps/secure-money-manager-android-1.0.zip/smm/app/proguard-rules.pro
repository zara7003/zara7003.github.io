# Room entities are constructed via reflection at runtime.
-keep class com.securemoney.manager.data.** { *; }

# SQLCipher's JNI bridge needs its class names intact.
-keep class net.zetetic.database.** { *; }
-dontwarn net.zetetic.database.**

# Kotlin coroutines / Compose runtime internals that some ProGuard
# configs otherwise strip too aggressively.
-dontwarn kotlinx.coroutines.**
-keepclassmembers class kotlin.Metadata { *; }
