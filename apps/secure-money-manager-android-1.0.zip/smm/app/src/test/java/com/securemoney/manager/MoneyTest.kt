package com.securemoney.manager

import com.securemoney.manager.data.*
import com.securemoney.manager.parse.TransactionParser
import org.junit.Assert.*
import org.junit.Test

/**
 * These tests exist because the app does money arithmetic across
 * currencies and four different settlement types. Every one of them
 * encodes a rule that, if broken, produces a silently wrong number
 * rather than a crash — which is the dangerous kind of bug.
 */
class MoneyTest {

    /* ── Minor units ── */

    @Test fun `parses two-decimal input exactly`() {
        assertEquals(1450L, "14.50".toMinor("QAR"))
        assertEquals(1450L, "14.5".toMinor("QAR"))
        assertEquals(1400L, "14".toMinor("QAR"))
    }

    @Test fun `strips thousands separators`() {
        assertEquals(145075L, "1,450.75".toMinor("QAR"))
        assertEquals(100000000L, "1,000,000".toMinor("QAR"))
    }

    @Test fun `respects three-decimal currencies`() {
        // KWD has 3 decimals: 14.500 KWD is 14500 fils, not 1450.
        assertEquals(14500L, "14.5".toMinor("KWD"))
        assertEquals(14567L, "14.567".toMinor("KWD"))
    }

    @Test fun `respects zero-decimal currencies`() {
        // JPY has no minor unit. 1500 yen is 1500, not 150000.
        assertEquals(1500L, "1500".toMinor("JPY"))
    }

    @Test fun `rejects nonsense`() {
        assertNull("".toMinor("QAR"))
        assertNull("abc".toMinor("QAR"))
        assertNull("   ".toMinor("QAR"))
    }

    @Test fun `rounds half up rather than truncating`() {
        // Truncation loses a fil on every odd half. Over thousands of rows
        // that becomes a visible discrepancy.
        assertEquals(1456L, "14.555".toMinor("QAR"))
        assertEquals(1455L, "14.554".toMinor("QAR"))
    }

    @Test fun `no floating point drift across many additions`() {
        // The reason amounts are Long: summing 0.10 a thousand times as a
        // Double does not give exactly 100.00.
        var total = 0L
        repeat(1000) { total += "0.10".toMinor("QAR")!! }
        assertEquals(10000L, total)
        assertEquals("QAR 100.00", total.format("QAR"))
    }

    /* ── Formatting ── */

    @Test fun `formats with the right number of decimals`() {
        assertEquals("QAR 14.50", 1450L.format("QAR"))
        assertEquals("KWD 14.500", 14500L.format("KWD"))
        assertEquals("JPY 1,500", 1500L.format("JPY"))
    }

    @Test fun `format and parse round-trip`() {
        listOf("QAR" to 145075L, "KWD" to 14567L, "JPY" to 1500L).forEach { (cur, minor) ->
            val text = minor.format(cur, withCode = false)
            assertEquals("round trip failed for $cur", minor, text.toMinor(cur))
        }
    }

    /* ── MoneyBag: the anti-mixing guarantee ── */

    @Test fun `keeps currencies separate`() {
        val bag = MoneyBag().add("QAR", 5000).add("INR", 100000).add("QAR", 2000)
        assertEquals(7000L, bag["QAR"])
        assertEquals(100000L, bag["INR"])
        // The bug this whole class exists to prevent: 7000 + 100000 = 107000
        // being presented as a total. There is no API that returns that.
        assertEquals(listOf("INR", "QAR"), bag.currencies)
    }

    @Test fun `unknown currency reads as zero not error`() {
        assertEquals(0L, MoneyBag().add("QAR", 100)["EUR"])
    }

    @Test fun `display shows every currency and never one combined figure`() {
        val text = MoneyBag().add("QAR", 2211000).add("INR", 22270000).display()
        assertTrue(text.contains("QAR"))
        assertTrue(text.contains("INR"))
        assertTrue(text.contains("·"))
    }

    @Test fun `zero balances are hidden from display`() {
        val bag = MoneyBag().add("QAR", 5000).add("EUR", 0)
        assertEquals(1, bag.entries().size)
        assertEquals("QAR", bag.entries().first().first)
    }

    @Test fun `empty bag displays a dash not a zero`() {
        // "0" implies you have nothing. "—" says there's nothing to show.
        assertEquals("—", MoneyBag().display())
    }

    @Test fun `subtract is add of a negative`() {
        val bag = MoneyBag().add("QAR", 5000).subtract("QAR", 2000)
        assertEquals(3000L, bag["QAR"])
    }

    @Test fun `bags combine per currency`() {
        val a = MoneyBag.of("QAR" to 1000L, "INR" to 5000L)
        val b = MoneyBag.of("QAR" to 500L, "EUR" to 200L)
        val sum = a.plus(b)
        assertEquals(1500L, sum["QAR"])
        assertEquals(5000L, sum["INR"])
        assertEquals(200L, sum["EUR"])
    }
}

class TransactionRulesTest {

    private fun tx(
        kind: String = TxKind.EXPENSE,
        personId: Long? = null,
        entryType: String? = null,
        confirmed: Boolean = true,
        amount: Long = 1000
    ) = TransactionEntity(
        merchant = "x", amountMinor = amount, currency = "QAR", kind = kind,
        accountId = 1, personId = personId, personEntryType = entryType,
        occurredAt = 0, confirmed = confirmed
    )

    /* ── What counts as your spending ── */

    @Test fun `plain expense counts as spend`() {
        assertTrue(tx().countsAsSpend)
    }

    @Test fun `unconfirmed entry never counts`() {
        // Pending items sit in the Review queue; counting them would make
        // totals jump around before the user has agreed to anything.
        assertFalse(tx(confirmed = false).countsAsSpend)
    }

    @Test fun `open advance is not your spending`() {
        // You expect this money back, so it must not inflate your budgets.
        assertFalse(tx(personId = 1, entryType = PersonEntryType.PAID_FOR).countsAsSpend)
    }

    @Test fun `absorbed advance becomes your spending`() {
        // Once you give up on reimbursement it really is your cost.
        assertTrue(tx(personId = 1, entryType = PersonEntryType.ABSORBED).countsAsSpend)
    }

    @Test fun `offset against support becomes your spending`() {
        assertTrue(tx(personId = 1, entryType = PersonEntryType.OFFSET_SUPPORT).countsAsSpend)
    }

    @Test fun `support payment is your spending immediately`() {
        // It is not a loan and never creates a claim.
        assertTrue(tx(personId = 1, entryType = PersonEntryType.SUPPORT_PAID).countsAsSpend)
    }

    @Test fun `transfers are never spending`() {
        // Moving your own money between your own accounts is not an expense.
        assertFalse(tx(kind = TxKind.TRANSFER_OUT).countsAsSpend)
        assertFalse(tx(kind = TxKind.TRANSFER_IN).countsAsSpend)
    }

    @Test fun `adjustments are never spending`() {
        assertFalse(tx(kind = TxKind.ADJUSTMENT).countsAsSpend)
    }

    @Test fun `income linked to a person is not your income`() {
        // Money you're holding for someone else isn't yours to count.
        assertFalse(tx(kind = TxKind.INCOME, personId = 1,
            entryType = PersonEntryType.RECEIVED_FOR).countsAsIncome)
    }

    /* ── Account effect ── */

    @Test fun `expense and transfer out reduce the account`() {
        assertEquals(-1000L, tx(kind = TxKind.EXPENSE).signedMinor)
        assertEquals(-1000L, tx(kind = TxKind.TRANSFER_OUT).signedMinor)
    }

    @Test fun `income and transfer in increase the account`() {
        assertEquals(1000L, tx(kind = TxKind.INCOME).signedMinor)
        assertEquals(1000L, tx(kind = TxKind.TRANSFER_IN).signedMinor)
    }

    @Test fun `a transfer nets to zero across both accounts`() {
        // Same-currency transfer must not change total holdings.
        val out = tx(kind = TxKind.TRANSFER_OUT, amount = 500000)
        val into = tx(kind = TxKind.TRANSFER_IN, amount = 500000)
        assertEquals(0L, out.signedMinor + into.signedMinor)
    }

    /* ── Person net position ── */

    /** Mirrors the SQL in observePersonNets. Positive = they owe you. */
    private fun net(entries: List<TransactionEntity>) = entries.sumOf {
        when (it.personEntryType) {
            PersonEntryType.PAID_FOR, PersonEntryType.SETTLE_OUT -> it.amountMinor
            PersonEntryType.RECEIVED_FOR, PersonEntryType.SETTLE_IN -> -it.amountMinor
            else -> 0L
        }
    }

    @Test fun `advance then full repayment settles to zero`() {
        assertEquals(0L, net(listOf(
            tx(personId = 1, entryType = PersonEntryType.PAID_FOR, amount = 500000),
            tx(personId = 1, entryType = PersonEntryType.SETTLE_IN, amount = 500000)
        )))
    }

    @Test fun `absorbing an advance clears the claim`() {
        // The key rule: a written-off advance must NOT linger as a debt
        // forever. Absorb contributes zero to the outstanding position.
        assertEquals(0L, net(listOf(
            tx(personId = 1, entryType = PersonEntryType.ABSORBED, amount = 500000)
        )))
    }

    @Test fun `offset against support clears the claim too`() {
        assertEquals(0L, net(listOf(
            tx(personId = 1, entryType = PersonEntryType.OFFSET_SUPPORT, amount = 200000)
        )))
    }

    @Test fun `holding someone's money means you owe them`() {
        assertEquals(-1200000L, net(listOf(
            tx(personId = 1, entryType = PersonEntryType.RECEIVED_FOR, amount = 1200000)
        )))
    }

    @Test fun `partial repayment leaves the remainder outstanding`() {
        assertEquals(200000L, net(listOf(
            tx(personId = 1, entryType = PersonEntryType.PAID_FOR, amount = 500000),
            tx(personId = 1, entryType = PersonEntryType.SETTLE_IN, amount = 300000)
        )))
    }

    @Test fun `a support payment does not create a claim`() {
        assertEquals(0L, net(listOf(
            tx(personId = 1, entryType = PersonEntryType.SUPPORT_PAID, amount = 200000)
        )))
    }

    @Test fun `absorb and spend are complementary not double counted`() {
        // An absorbed advance appears in exactly one place: your spending.
        // It must not also sit in the outstanding position.
        val absorbed = tx(personId = 1, entryType = PersonEntryType.ABSORBED, amount = 500000)
        assertTrue(absorbed.countsAsSpend)
        assertEquals(0L, net(listOf(absorbed)))
    }
}

class ParserTest {

    private val rules = TransactionParser.defaultRules()

    @Test fun `extracts amount and currency from a generic debit message`() {
        val r = TransactionParser.parse(
            "Your card ending 4821 was debited QAR 214.50 at LULU HYPERMARKET.",
            "BANK", rules, emptyList()
        )
        assertEquals(21450L, r.amountMinor)
        assertEquals("QAR", r.currency)
        assertTrue(r.currencyWasDetected)
        assertTrue(r.isExpense)
    }

    @Test fun `handles rupee symbol and word forms`() {
        val r = TransactionParser.parse(
            "Rs.5,000.00 debited from a/c XX1234 to VISA AGENCY.",
            "BANK", rules, emptyList()
        )
        assertEquals(500000L, r.amountMinor)
        assertEquals("INR", r.currency)
    }

    @Test fun `direction comes from keywords not guesswork`() {
        val credit = TransactionParser.parse(
            "USD 1200.00 credited to your account. Salary.", "BANK", rules, emptyList()
        )
        assertFalse(credit.isExpense)

        val debit = TransactionParser.parse(
            "USD 45.00 debited for purchase.", "BANK", rules, emptyList()
        )
        assertTrue(debit.isExpense)
    }

    @Test fun `extracts card digits for account matching`() {
        val r = TransactionParser.parse(
            "Card ending 4821 debited AED 99.00 at CARREFOUR.", "BANK", rules, emptyList()
        )
        assertEquals("4821", r.accountDigits)
    }

    @Test fun `unparseable message is flagged rather than guessed`() {
        val r = TransactionParser.parse(
            "Your statement is ready to view.", "BANK", rules, emptyList()
        )
        assertFalse(r.isUsable)
        assertNull(r.amountMinor)
    }

    @Test fun `falls back to base currency without inventing detection`() {
        val r = TransactionParser.parse(
            "Debited 500 for purchase.", "BANK", rules, emptyList(), fallbackCurrency = "QAR"
        )
        // Currency may fall back, but the flag must say it was not detected,
        // so the UI knows to ask rather than assume.
        assertFalse(r.currencyWasDetected)
        assertEquals("QAR", r.currency)
    }

    @Test fun `longest person alias wins`() {
        val people = listOf(
            PersonEntity(id = 1, name = "Sam", autoMatchSms = true),
            PersonEntity(id = 2, name = "Sam Khan", smsAliases = "Sam Khan", autoMatchSms = true)
        )
        val r = TransactionParser.parse(
            "QAR 500 transferred to Sam Khan.", "BANK", rules, people
        )
        assertEquals(2L, r.personId)
    }

    @Test fun `people are ignored when detection is disabled`() {
        // The caller passes an empty list when the setting is off; the
        // parser must not reach around it.
        val r = TransactionParser.parse(
            "QAR 500 transferred to Sam.", "BANK", rules, emptyList()
        )
        assertNull(r.personId)
    }

    @Test fun `broken regex in a rule does not crash the parser`() {
        // A user can type a bad regex in Settings. That must degrade, not
        // take down the SMS receiver.
        val bad = listOf(SmsRuleEntity(
            label = "broken", senderPattern = "[", amountRegex = "([", priority = 99
        ))
        val r = TransactionParser.parse("QAR 100 debited", "BANK", bad, emptyList())
        assertNotNull(r)   // no exception thrown
    }

    @Test fun `confidence is low when little was recognised`() {
        val weak = TransactionParser.parse("500", "X", rules, emptyList())
        val strong = TransactionParser.parse(
            "Card ending 1234 debited QAR 50.00 at SHOP NAME.", "BANK", rules, emptyList()
        )
        assertTrue(strong.confidence > weak.confidence)
    }
}

class FxTest {

    @Test fun `indicative rates are marked as unconfirmed`() {
        val seeded = FxRateEntity(fromCurrency = "USD", toCurrency = "QAR", rate = 3.64)
        assertTrue(seeded.isIndicative)

        val userSet = seeded.copy(setByUserAt = System.currentTimeMillis())
        assertFalse(userSet.isIndicative)
    }

    @Test fun `a frozen rate is stored not recomputed`() {
        // The whole point: an INR advance offset against a QAR obligation
        // records what the user decided, permanently.
        val tx = TransactionEntity(
            merchant = "Agency fee", amountMinor = 500000, currency = "INR",
            kind = TxKind.EXPENSE, accountId = 1,
            personId = 1, personEntryType = PersonEntryType.OFFSET_SUPPORT,
            fxCounterCurrency = "QAR", fxCounterMinor = 200000,
            fxRateUsed = 0.4, occurredAt = 0
        )
        assertEquals("QAR", tx.fxCounterCurrency)
        assertEquals(200000L, tx.fxCounterMinor)
        assertEquals(0.4, tx.fxRateUsed!!, 0.0001)
        // The primary amount stays in its own currency, untouched.
        assertEquals("INR", tx.currency)
        assertEquals(500000L, tx.amountMinor)
    }

    @Test fun `same currency needs no rate`() {
        val tx = TransactionEntity(
            merchant = "x", amountMinor = 1000, currency = "QAR",
            kind = TxKind.EXPENSE, accountId = 1, occurredAt = 0
        )
        assertNull(tx.fxRateUsed)
        assertNull(tx.fxCounterCurrency)
    }
}

class CurrencyTest {

    @Test fun `known currencies carry the right decimal count`() {
        assertEquals(2, Currencies.decimals("QAR"))
        assertEquals(3, Currencies.decimals("KWD"))
        assertEquals(0, Currencies.decimals("JPY"))
    }

    @Test fun `unknown currency degrades to two decimals rather than failing`() {
        assertEquals(2, Currencies.decimals("XYZ"))
        assertEquals("XYZ", Currencies.info("XYZ").code)
    }

    @Test fun `lookup is case insensitive`() {
        assertEquals("QAR", Currencies.info("qar").code)
    }
}
