package com.securemoney.manager.ui

import android.content.Context
import android.content.Intent
import androidx.activity.result.ActivityResultLauncher
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.securemoney.manager.*
import com.securemoney.manager.data.*
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    ctx: Context, app: SmmApp, dao: SmmDao, settings: Settings,
    notifPermission: ActivityResultLauncher<String>,
    onDatabaseReopened: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var sheet by remember { mutableStateOf<String?>(null) }

    LazyColumn(Modifier.fillMaxSize()) {
        item { ScreenTitle("Settings") }

        item { SectionLabel("Appearance") }
        item {
            Column {
                listOf("system" to "Match device", "light" to "Light", "dark" to "Dark").forEach { (k, l) ->
                    ListItem(
                        modifier = Modifier.clickable {
                            scope.launch { app.settings.set(Keys.THEME, k) }
                        },
                        headlineContent = { Text(l, fontSize = 14.sp) },
                        trailingContent = {
                            RadioButton(settings.theme == k, {
                                scope.launch { app.settings.set(Keys.THEME, k) }
                            })
                        }
                    )
                }
            }
        }
        item {
            SwitchRow("Compact rows", "Fit more entries on screen", settings.compactRows) {
                scope.launch { app.settings.set(Keys.COMPACT_ROWS, it) }
            }
        }
        item {
            SwitchRow("Show tag filters on Records", null, settings.showTags) {
                scope.launch { app.settings.set(Keys.SHOW_TAGS, it) }
            }
        }
        item { ActionRow("Customise footer tabs", "${settings.navCount} shown, rest under More") {
            sheet = "nav"
        } }

        item { SectionLabel("Privacy") }
        item {
            SwitchRow("Hide amounts until tapped", "Blurs balances behind a tap", settings.hideAmounts) {
                scope.launch { app.settings.set(Keys.HIDE_AMOUNTS, it) }
            }
        }
        item {
            SwitchRow("Blur in app switcher", "Hides content in Recent Apps", settings.blurRecents) {
                scope.launch { app.settings.set(Keys.BLUR_RECENTS, it) }
            }
        }
        item { ActionRow(
            if (AppDatabase.isOpen()) "Encryption is on" else "Set up encryption",
            "AES-256, unlocked by passphrase or fingerprint"
        ) { sheet = "encryption" } }

        item { SectionLabel("Automatic capture — off by default") }
        item {
            InfoCard(
                "Nothing is read until you turn a source on below AND approve specific senders or apps individually. Unapproved content is discarded unread."
            )
        }
        item { ActionRow("Bank SMS senders", "Approve which numbers get read") { sheet = "sms" } }
        item { ActionRow("Notification apps", "Approve which apps get read") { sheet = "notif" } }
        item {
            SwitchRow(
                "Hold parsed entries for review",
                "Recommended — nothing reaches your ledger without a tap",
                settings.holdForReview
            ) { scope.launch { app.settings.set(Keys.HOLD_FOR_REVIEW, it) } }
        }
        item {
            SwitchRow(
                "Detect people in messages",
                "Matches names you've set up against SMS text",
                settings.detectPeople
            ) { scope.launch { app.settings.set(Keys.DETECT_PEOPLE, it) } }
        }

        item { SectionLabel("Reminders") }
        item { ActionRow("Manage reminders", "All off until you enable one") { sheet = "reminders" } }

        item { SectionLabel("Data") }
        item { ActionRow("Export", "JSON, CSV, Excel or encrypted") { sheet = "export" } }
        item { ActionRow("Import a backup", "Merge or replace") { sheet = "import" } }
        item { ActionRow("Exchange rates", "Your own rates — never fetched") { sheet = "rates" } }
        item { ActionRow("Developer mode", "Parser sandbox, event log, integrity check") { sheet = "dev" } }

        item { SectionLabel("About") }
        item {
            InfoCard(
                "This app requests no INTERNET permission. Check Android's permission list for this app — you'll find no network access is listed, because none was requested.",
                tone = "good"
            )
        }
        item { ActionRow("Licence — GPL-3.0", "Free software, and it always will be") { sheet = "license" } }
        item { ActionRow("Terms of use") { sheet = "terms" } }
        item {
            ListItem(
                headlineContent = { Text("Contact", fontSize = 14.sp) },
                supportingContent = { Text("ops@sahilshaikh.org", fontSize = 12.sp) }
            )
        }
        item {
            Text(
                "Built by Sahil Shaikh and contributors.",
                Modifier.padding(20.dp, 4.dp, 20.dp, 40.dp),
                fontSize = 11.sp
            )
        }
    }

    when (sheet) {
        "export" -> ExportSheet(ctx, dao) { sheet = null }
        "rates" -> FxRatesSheet(dao) { sheet = null }
        "nav" -> NavCustomiseSheet(app, settings) { sheet = null }
        "sms" -> SmsSendersSheet(dao) { sheet = null }
        "notif" -> NotifAppsSheet(dao) { sheet = null }
        "reminders" -> RemindersSheet(dao) { sheet = null }
        "encryption" -> {
            var migrating by remember { mutableStateOf(false) }
            var migrateError by remember { mutableStateOf<String?>(null) }
            EncryptionSetupSheet(
                onEnabled = { key ->
                    migrating = true
                    scope.launch {
                        // The DB must be closed before its file can be rewritten,
                        // and reopened afterwards WITH the new key.
                        AppDatabase.close()
                        val ok = com.securemoney.manager.data.Crypto.encryptExistingDatabase(ctx, key)
                        migrating = false
                        if (ok) {
                            AppDatabase.get(ctx, key)
                            // The old dao handle now points at a CLOSED database.
                            // Tell the host to re-derive it, or every later query
                            // throws "attempt to re-open an already-closed object".
                            onDatabaseReopened()
                            sheet = null
                        } else {
                            // Original plaintext file is untouched — safe to retry
                            // or just keep using the app unencrypted.
                            AppDatabase.get(ctx)
                            onDatabaseReopened()
                            migrateError = "Couldn't encrypt the database. Your data is unchanged and still readable. You can try again, or export a backup first and file a bug report."
                        }
                    }
                },
                onDismiss = { sheet = null }
            )
            if (migrating) {
                AlertDialog(
                    onDismissRequest = {},
                    confirmButton = {},
                    title = { Text("Encrypting your data") },
                    text = { Text("This can take a moment for a large ledger. Don't close the app.") }
                )
            }
            migrateError?.let {
                AlertDialog(
                    onDismissRequest = { migrateError = null },
                    confirmButton = { TextButton({ migrateError = null }) { Text("OK") } },
                    title = { Text("Encryption didn't complete") },
                    text = { Text(it) }
                )
            }
        }
        "license" -> LicenseSheet { sheet = null }
        "terms" -> TermsSheet { sheet = null }
        "dev" -> DevModeSheet(dao) { sheet = null }
        "import" -> ImportSheet(ctx, dao) { sheet = null }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TermsSheet(onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp)) {
            SheetHeader("Terms of use")
            Box(Modifier.heightIn(max = 500.dp).verticalScroll(rememberScrollState())) {
                Text(TERMS_TEXT, fontSize = 11.sp, lineHeight = 17.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LicenseSheet(onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp)) {
            SheetHeader("GPL-3.0", "Free software, always")
            Text(
                "Secure Money Manager is licensed under the GNU General Public License version 3.\n\n" +
                "You're free to use, study, modify and redistribute this app, provided any version " +
                "you distribute stays under the same licence and its source stays available. The " +
                "full licence text ships with the source code repository.\n\n" +
                "This version, once released, stays free and open forever — that can't be revoked, " +
                "including by us. Any future version could use different terms, but this one won't change.",
                fontSize = 12.sp, lineHeight = 18.sp
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NavCustomiseSheet(app: SmmApp, settings: Settings, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var tabs by remember { mutableStateOf(settings.navTabs) }
    var count by remember { mutableIntStateOf(settings.navCount) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp)) {
            SheetHeader("Footer tabs", "Pick 3 to 6 — the rest sit under More")
            Slider(
                value = count.toFloat(), onValueChange = { count = it.toInt() },
                valueRange = 3f..6f, steps = 2
            )
            Text("$count tabs shown", fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            ALL_NAV.filter { it.first != "settings" }.forEach { (key, label) ->
                val on = key in tabs
                SwitchRow(label, null, on) { checked ->
                    tabs = if (checked) tabs + key else tabs - key
                }
            }
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    scope.launch {
                        app.settings.set(Keys.NAV_TABS, tabs.joinToString(","))
                        app.settings.set(Keys.NAV_COUNT, count)
                    }
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save") }
        }
    }
}

@Composable
fun ExportScreen(ctx: Context, dao: SmmDao) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        ExportSheetContent(ctx, dao)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportSheet(ctx: Context, dao: SmmDao, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp)) {
            ExportSheetContent(ctx, dao)
        }
    }
}

@Composable
private fun ExportSheetContent(ctx: Context, dao: SmmDao) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var passphrase by remember { mutableStateOf("") }
    var showEncrypted by remember { mutableStateOf(false) }

    Column {
        SheetHeader("Export", "Writes a file, then hands it to the share sheet")
        InfoCard("This app has no internet access, so it can't send anything itself. Whatever you choose next — email, Drive, WhatsApp — does the sending.")

        Spacer(Modifier.height(8.dp))
        listOf(
            "JSON" to "Full detail — the only format you can import back",
            "CSV" to "Opens in Excel, Sheets or Numbers",
            "XLSX" to "A real workbook with balances, totals and people"
        ).forEach { (label, sub) ->
            ActionRow(label, sub) {
                busy = true
                scope.launch {
                    val f = when (label) {
                        "JSON" -> com.securemoney.manager.io.ExportManager.exportJson(ctx, dao)
                        "CSV" -> com.securemoney.manager.io.ExportManager.exportCsv(ctx, dao)
                        else -> com.securemoney.manager.io.ExportManager.exportXlsx(ctx, dao)
                    }
                    busy = false
                    ctx.startActivity(Intent.createChooser(
                        com.securemoney.manager.io.ExportManager.shareIntent(ctx, f), "Share export"
                    ))
                }
            }
        }
        ActionRow("Encrypted (.smmz)", "AES-256, needs a passphrase to open") {
            showEncrypted = true
        }

        if (busy) {
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(Modifier.fillMaxWidth())
        }

        if (showEncrypted) {
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = passphrase, onValueChange = { passphrase = it },
                label = { Text("Passphrase for this export") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Remember this — it isn't stored anywhere and can't be recovered.",
                fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    val pass = passphrase
                    scope.launch {
                        val f = com.securemoney.manager.io.ExportManager
                            .exportEncrypted(ctx, dao, pass.toCharArray())
                        ctx.startActivity(Intent.createChooser(
                            com.securemoney.manager.io.ExportManager.shareIntent(ctx, f), "Share export"
                        ))
                        passphrase = ""; showEncrypted = false
                    }
                },
                enabled = passphrase.length >= 4,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Create & share") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImportSheet(ctx: Context, dao: SmmDao, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf<String?>(null) }
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            runCatching {
                val text = ctx.contentResolver.openInputStream(uri)!!.bufferedReader().readText()
                com.securemoney.manager.io.ImportManager.importJson(
                    text, dao, com.securemoney.manager.io.ImportManager.Mode.MERGE
                )
            }.onSuccess { r ->
                status = "Imported ${r.transactions} entries, skipped ${r.skipped} duplicates."
            }.onFailure {
                status = "Couldn't read that file — is it a Secure Money Manager JSON export?"
            }
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp)) {
            SheetHeader("Import a backup", "Only the JSON format round-trips fully")
            InfoCard("Merging skips anything that looks like a duplicate. Nothing is deleted.")
            Spacer(Modifier.height(12.dp))
            Button({ picker.launch(arrayOf("application/json")) }, Modifier.fillMaxWidth()) {
                Text("Choose a JSON backup file")
            }
            status?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, fontSize = 12.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FxRatesSheet(dao: SmmDao, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val rates by dao.observeRates().collectAsStateWithLifecycle(emptyList())

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp)) {
            SheetHeader("Exchange rates", "Never fetched. Used only to pre-fill a suggestion.")
            InfoCard("The app never converts your balances using these. Cross-currency settlements always let you enter what actually happened.")
            Spacer(Modifier.height(8.dp))
            Box(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                Column {
                    rates.sortedBy { it.isIndicative }.forEach { r ->
                        var value by remember(r.id) { mutableStateOf(String.format("%.4f", r.rate)) }
                        ListItem(
                            headlineContent = { Text("${r.fromCurrency} → ${r.toCurrency}", fontSize = 13.sp) },
                            supportingContent = {
                                Text(
                                    if (r.isIndicative) "Indicative — never confirmed" else "Set by you",
                                    fontSize = 10.sp,
                                    color = if (r.isIndicative) MaterialTheme.colorScheme.error
                                            else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            trailingContent = {
                                OutlinedTextField(
                                    value = value, onValueChange = { value = it },
                                    singleLine = true, modifier = Modifier.width(110.dp),
                                    textStyle = MaterialTheme.typography.bodySmall,
                                    trailingIcon = {
                                        IconButton({
                                            val d = value.toDoubleOrNull() ?: return@IconButton
                                            scope.launch {
                                                dao.update(r.copy(
                                                    rate = d, setByUserAt = System.currentTimeMillis()
                                                ))
                                            }
                                        }) { Icon(Icons.Default.OpenInNew, "Save", Modifier.size(14.dp)) }
                                    }
                                )
                            }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DevModeSheet(dao: SmmDao, onDismiss: () -> Unit) {
    val log by dao.observeLog().collectAsStateWithLifecycle(emptyList())
    val scope = rememberCoroutineScope()
    var integrity by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp)) {
            SheetHeader("Developer mode", "Event log and database check")
            Button(
                onClick = { scope.launch { integrity = dao.integrityCheck().joinToString() } },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Run integrity check") }
            integrity?.let { Text(it, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)) }
            Spacer(Modifier.height(12.dp))
            Text("Recent events (newest first)", fontSize = 11.sp, fontWeight = FontWeight.Medium)
            Box(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                Column {
                    log.forEach {
                        Text("[${it.level}] ${it.tag}: ${it.message}", fontSize = 10.sp)
                    }
                }
            }
        }
    }
}
