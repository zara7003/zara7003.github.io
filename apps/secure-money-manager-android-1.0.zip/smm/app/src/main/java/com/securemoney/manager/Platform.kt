package com.securemoney.manager

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.work.*
import com.securemoney.manager.data.*
import com.securemoney.manager.parse.TransactionParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.concurrent.TimeUnit

val Context.dataStore by preferencesDataStore("smm_settings")

object Keys {
    val THEME           = stringPreferencesKey("theme")
    val ONBOARDED       = booleanPreferencesKey("onboarded")
    val BASE_CURRENCY   = stringPreferencesKey("base_currency")
    val ACTIVE_GROUP    = longPreferencesKey("active_group")     // 0 = all
    val HIDE_AMOUNTS    = booleanPreferencesKey("hide_amounts")
    val BLUR_RECENTS    = booleanPreferencesKey("blur_recents")
    val SMS_IMPORT      = booleanPreferencesKey("sms_import")
    val NOTIF_LISTENER  = booleanPreferencesKey("notif_listener")
    val HOLD_FOR_REVIEW = booleanPreferencesKey("hold_for_review")
    val DETECT_PEOPLE   = booleanPreferencesKey("detect_people")
    val PHOTO_PROMPT    = booleanPreferencesKey("photo_prompt")
    val REMINDERS_SEEN  = booleanPreferencesKey("reminders_seen")
    val DEV_MODE        = booleanPreferencesKey("dev_mode")
    val COMPACT_ROWS    = booleanPreferencesKey("compact_rows")
    val SHOW_TAGS       = booleanPreferencesKey("show_tags")
    val NAV_TABS        = stringPreferencesKey("nav_tabs")
    val NAV_COUNT       = intPreferencesKey("nav_count")
    val TERMS_ACCEPTED  = intPreferencesKey("terms_version_accepted")
}

/** Footer tab options. Add a screen here and in MainActivity's `when`. */
val ALL_NAV = listOf(
    "records" to "Records",
    "calendar" to "Calendar",
    "accounts" to "Accounts",
    "people" to "People",
    "budgets" to "Budgets",
    "categories" to "Categories",
    "tags" to "Tags",
    "review" to "Review",
    "settings" to "Settings"
)
val DEFAULT_NAV = listOf("records", "accounts", "people", "budgets")

/** Bump when the terms text changes materially; users re-acknowledge. */
const val TERMS_VERSION = 1

data class Settings(
    val theme: String = "system",
    val onboarded: Boolean = false,
    val baseCurrency: String = "USD",
    val activeGroupId: Long = 0L,
    val hideAmounts: Boolean = true,
    val blurRecents: Boolean = true,
    // Capture ships OFF. Always.
    val smsImport: Boolean = false,
    val notifListener: Boolean = false,
    val holdForReview: Boolean = true,
    val detectPeople: Boolean = false,
    val photoPrompt: Boolean = false,
    val remindersSeen: Boolean = false,
    val devMode: Boolean = false,
    val compactRows: Boolean = false,
    val showTags: Boolean = true,
    val navTabs: List<String> = DEFAULT_NAV,
    val navCount: Int = 4,
    val termsAccepted: Int = 0
) {
    val needsTerms: Boolean get() = termsAccepted < TERMS_VERSION
}

class SettingsRepo(private val ctx: Context) {
    val flow: Flow<Settings> = ctx.dataStore.data.map { p ->
        Settings(
            theme = p[Keys.THEME] ?: "system",
            onboarded = p[Keys.ONBOARDED] ?: false,
            baseCurrency = p[Keys.BASE_CURRENCY] ?: "USD",
            activeGroupId = p[Keys.ACTIVE_GROUP] ?: 0L,
            hideAmounts = p[Keys.HIDE_AMOUNTS] ?: true,
            blurRecents = p[Keys.BLUR_RECENTS] ?: true,
            smsImport = p[Keys.SMS_IMPORT] ?: false,
            notifListener = p[Keys.NOTIF_LISTENER] ?: false,
            holdForReview = p[Keys.HOLD_FOR_REVIEW] ?: true,
            detectPeople = p[Keys.DETECT_PEOPLE] ?: false,
            photoPrompt = p[Keys.PHOTO_PROMPT] ?: false,
            remindersSeen = p[Keys.REMINDERS_SEEN] ?: false,
            devMode = p[Keys.DEV_MODE] ?: false,
            compactRows = p[Keys.COMPACT_ROWS] ?: false,
            showTags = p[Keys.SHOW_TAGS] ?: true,
            navCount = (p[Keys.NAV_COUNT] ?: 4).coerceIn(3, 6),
            navTabs = p[Keys.NAV_TABS]?.split(",")?.filter { it.isNotBlank() }
                ?.takeIf { it.isNotEmpty() } ?: DEFAULT_NAV,
            termsAccepted = p[Keys.TERMS_ACCEPTED] ?: 0
        )
    }

    suspend fun <T> set(key: Preferences.Key<T>, value: T) {
        ctx.dataStore.edit { it[key] = value }
    }

    suspend fun once(): Settings = flow.first()
}

class SmmApp : Application() {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    lateinit var settings: SettingsRepo

    override fun onCreate() {
        super.onCreate()
        instance = this
        settings = SettingsRepo(this)
        // Note: the database is NOT opened here. When encryption is on it
        // cannot be opened until the user supplies the key.
    }

    companion object { lateinit var instance: SmmApp private set }
}

/**
 * First-run content. Deliberately generic — no personal names, no
 * country assumptions. The user picks their own groups and currency in
 * onboarding; these are only the shapes.
 */
object Seed {

    suspend fun run(dao: SmmDao, baseCurrency: String, groupNames: List<String>) {
        if (dao.allGroupsOnce().isNotEmpty()) return

        groupNames.forEachIndexed { i, name ->
            val id = dao.insert(GroupEntity(
                name = name,
                icon = "\uD83C\uDF10",
                defaultCurrency = baseCurrency,
                sortOrder = i
            ))
            // Two starter accounts per group, so the app isn't empty but
            // isn't presumptuous either.
            dao.insert(AccountEntity(
                name = "Bank", groupId = id, currency = baseCurrency,
                type = "BANK", icon = "\uD83C\uDFE6", colorHex = "#5B8CB8", sortOrder = 0
            ))
            dao.insert(AccountEntity(
                name = "Cash", groupId = id, currency = baseCurrency,
                type = "CASH", icon = "\uD83D\uDCB5", colorHex = "#E3C25F", sortOrder = 1
            ))
        }

        listOf(
            Triple("Groceries",      "\uD83D\uDED2", "#81B29A"),
            Triple("Eating out",     "\uD83C\uDF7D", "#E07A5F"),
            Triple("Transport",      "\uD83D\uDE97", "#5B8CB8"),
            Triple("Rent",           "\uD83C\uDFE0", "#8D6E63"),
            Triple("Bills",          "\u26A1",       "#E3C25F"),
            Triple("Health",         "\uD83D\uDC8A", "#B07AA1"),
            Triple("Shopping",       "\uD83D\uDC55", "#C08552"),
            Triple("Family support", "\uD83E\uDD1D", "#7B9E87"),
            Triple("Travel",         "\u2708\uFE0F", "#4F6D8C"),
            Triple("Education",      "\uD83C\uDF93", "#9C6B9E"),
            Triple("Pets",           "\uD83D\uDC15", "#C9A661"),
            Triple("Fees & charges", "\uD83E\uDDFE", "#A45C40"),
            Triple("Uncategorised",  "\u2754",       "#8A93A6")
        ).forEachIndexed { i, (n, ic, col) ->
            dao.insert(CategoryEntity(
                name = n, isExpense = true, icon = ic, colorHex = col, sortOrder = i
            ))
        }
        listOf(
            Triple("Salary",     "\uD83D\uDCB0", "#6FBF8E"),
            Triple("Reimbursed", "\u21A9",       "#81B29A"),
            Triple("Other income","\uD83D\uDCC8","#5E8B7E")
        ).forEachIndexed { i, (n, ic, col) ->
            dao.insert(CategoryEntity(
                name = n, isExpense = false, icon = ic, colorHex = col, sortOrder = i
            ))
        }

        TransactionParser.defaultRules().forEach { dao.insert(it) }
        // Reminder templates, all disabled. Visible, never firing.
        ReminderEntity.templates().forEach { dao.insert(it) }

        dao.log(EventLogEntity(
            tag = "SEED",
            message = "First run: ${groupNames.size} groups, base $baseCurrency, capture off"
        ))
    }

    /**
     * Indicative starting rates so cross-currency prompts have a number to
     * pre-fill. Every one is marked setByUserAt = null, so the UI shows
     * "never confirmed" until the user replaces it. The app never converts
     * balances or totals with these.
     */
    suspend fun seedIndicativeRates(dao: SmmDao, base: String) {
        if (dao.allRatesOnce().isNotEmpty()) return
        // Rough magnitudes against USD, for pre-filling only.
        val perUsd = mapOf(
            "QAR" to 3.64, "AED" to 3.67, "SAR" to 3.75, "INR" to 83.0,
            "EUR" to 0.92, "GBP" to 0.79, "PKR" to 278.0, "BDT" to 110.0,
            "LKR" to 300.0, "PHP" to 56.0, "EGP" to 48.0, "TRY" to 32.0,
            "KWD" to 0.31, "BHD" to 0.38, "OMR" to 0.38, "NPR" to 133.0,
            "CAD" to 1.36, "AUD" to 1.52, "CHF" to 0.88, "SGD" to 1.34,
            "MYR" to 4.7, "THB" to 36.0, "JPY" to 150.0, "CNY" to 7.2,
            "ZAR" to 18.5, "KES" to 130.0, "NGN" to 1500.0, "USD" to 1.0
        )
        val baseRate = perUsd[base] ?: 1.0
        perUsd.forEach { (code, rate) ->
            if (code == base) return@forEach
            dao.insert(FxRateEntity(
                fromCurrency = base,
                toCurrency = code,
                rate = rate / baseRate,
                setByUserAt = null,
                note = "Indicative only — please set your own rate"
            ))
        }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  CAPTURE GATE
 * ══════════════════════════════════════════════════════════════════
 *  A message is read only when BOTH hold:
 *    1. the master toggle for that source is on, and
 *    2. the sender or package is on the allowlist and enabled.
 *  No wildcard exists. An empty allowlist means nothing is read, and an
 *  empty allowlist is the shipped state.
 */
object Ingest {

    suspend fun handleSms(ctx: Context, body: String, sender: String) {
        if (!AppDatabase.isOpen()) return         // locked, so nothing to write to
        val dao = AppDatabase.get(ctx).dao()
        val s = SettingsRepo(ctx).once()
        if (!s.smsImport) return

        val approved = dao.approvedSenders().firstOrNull {
            it.sender.equals(sender, true) || sender.contains(it.sender, true)
        }
        if (approved == null) {
            // Note that the sender exists; discard the content unread.
            dao.noteCandidate("SMS", sender, sender)
            return
        }
        dao.touchSender(approved.id, System.currentTimeMillis())
        ingest(ctx, dao, s, body, sender, "SMS", approved.defaultAccountId, approved.smsRuleId)
    }

    suspend fun handleNotification(ctx: Context, text: String, pkg: String, label: String) {
        if (!AppDatabase.isOpen()) return
        val dao = AppDatabase.get(ctx).dao()
        val s = SettingsRepo(ctx).once()
        if (!s.notifListener) return

        val approved = dao.approvedApps().firstOrNull { it.packageName.equals(pkg, true) }
        if (approved == null) {
            dao.noteCandidate("NOTIFICATION", pkg, label)
            return
        }
        dao.touchApp(approved.id, System.currentTimeMillis())
        ingest(ctx, dao, s, text, pkg, "NOTIFICATION", approved.defaultAccountId, null)
    }

    private suspend fun ingest(
        ctx: Context, dao: SmmDao, s: Settings,
        body: String, origin: String, source: String,
        pinnedAccountId: Long?, pinnedRuleId: Long?
    ) {
        val allRules = dao.activeSmsRules()
        val rules = pinnedRuleId
            ?.let { id -> allRules.filter { it.id == id }.ifEmpty { allRules } }
            ?: allRules

        val people = if (s.detectPeople) dao.autoMatchPeople() else emptyList()
        val r = TransactionParser.parse(body, origin, rules, people, s.baseCurrency)

        if (!r.isUsable) {
            dao.log(EventLogEntity(
                level = "WARN", tag = source,
                message = "No amount found from $origin"   // body never logged
            ))
            return
        }

        val accounts = dao.allAccountsOnce().filter { !it.archived }
        val merchant = r.merchant ?: "Unknown ($origin)"

        // Account resolution, most reliable first:
        //   pinned on the sender > learned correction > card digits >
        //   only account in that currency > give up and ask
        val learnedAcc = dao.learned(LearnedRuleEntity.MERCHANT_ACCOUNT, merchant.lowercase())
            ?.takeIf { it.hitCount >= LearnedRuleEntity.AUTO_APPLY_THRESHOLD }
        val sameCurrency = accounts.filter { it.currency == r.currency }
        val account = pinnedAccountId?.let { id -> accounts.firstOrNull { it.id == id } }
            ?: learnedAcc?.let { l -> accounts.firstOrNull { it.id == l.targetId } }
            ?: r.accountDigits?.let { d ->
                accounts.firstOrNull { it.accountDigits.isNotBlank() && it.accountDigits == d }
            }
            ?: sameCurrency.singleOrNull()
            ?: sameCurrency.firstOrNull()
            ?: accounts.firstOrNull()
            ?: return

        val learnedCat = dao.learned(LearnedRuleEntity.MERCHANT_CATEGORY, merchant.lowercase())
        val categoryId = learnedCat?.targetId

        // Auto-confirm only when everything lines up: review is off, the
        // parse was strong, the currency was explicit, and the account
        // wasn't a guess.
        val accountWasCertain = pinnedAccountId != null || learnedAcc != null ||
            sameCurrency.size == 1
        val confident = r.confidence >= 0.7f && r.currencyWasDetected && accountWasCertain

        dao.insert(TransactionEntity(
            merchant = merchant,
            amountMinor = r.amountMinor!!,
            currency = r.currency,
            kind = if (r.isExpense) TxKind.EXPENSE else TxKind.INCOME,
            accountId = account.id,
            categoryId = categoryId,
            personId = r.personId,
            personEntryType = r.personId?.let {
                if (r.isExpense) PersonEntryType.PAID_FOR else PersonEntryType.SETTLE_IN
            },
            source = source,
            rawMessage = body,          // kept only for approved senders
            occurredAt = System.currentTimeMillis(),
            confirmed = !s.holdForReview && confident
        ))

        dao.log(EventLogEntity(
            tag = source,
            message = "$origin → ${r.amountMinor.format(r.currency)} at $merchant"
        ))
    }
}

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val app = context.applicationContext as? SmmApp ?: return
        // Join multipart parts before parsing, or long messages truncate mid-amount.
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val sender = msgs.firstOrNull()?.originatingAddress ?: return
        app.scope.launch { runCatching { Ingest.handleSms(context, body, sender) } }
    }
}

class BankNotificationService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName ?: return
        val e = sbn.notification?.extras ?: return
        val text = listOfNotNull(
            e.getString("android.title"),
            e.getString("android.text"),
            e.getString("android.bigText")
        ).joinToString(" ")
        if (text.isBlank()) return

        val label = runCatching {
            val pm = applicationContext.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        }.getOrDefault(pkg)

        val app = applicationContext as? SmmApp ?: return
        app.scope.launch {
            runCatching { Ingest.handleNotification(applicationContext, text, pkg, label) }
        }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  REMINDERS
 * ══════════════════════════════════════════════════════════════════ */
const val REMINDER_CHANNEL = "smm_reminders"

fun ensureReminderChannel(ctx: Context) {
    if (android.os.Build.VERSION.SDK_INT < 26) return
    val mgr = ctx.getSystemService(android.app.NotificationManager::class.java) ?: return
    if (mgr.getNotificationChannel(REMINDER_CHANNEL) != null) return
    mgr.createNotificationChannel(
        android.app.NotificationChannel(
            REMINDER_CHANNEL, "Reminders",
            android.app.NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = "Your own reminders. Created by you, sent nowhere." }
    )
}

class ReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val id = inputData.getLong("reminderId", -1)
        // When encrypted and locked we cannot read the reminder text. Skip
        // quietly rather than leaking anything to a notification.
        if (!AppDatabase.isOpen()) return Result.success()

        val dao = AppDatabase.get(applicationContext).dao()
        val r = dao.reminder(id) ?: return Result.success()
        if (!r.enabled) return Result.success()

        ensureReminderChannel(applicationContext)

        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            putExtra("route", when (r.action) {
                "RECORDS" -> "records"; "ACCOUNTS" -> "accounts"
                "PEOPLE" -> "people";   "REVIEW" -> "review"
                "EXPORT" -> "export";   else -> "records"
            })
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = android.app.PendingIntent.getActivity(
            applicationContext, r.id.toInt(), intent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or
                android.app.PendingIntent.FLAG_IMMUTABLE
        )

        val n = androidx.core.app.NotificationCompat.Builder(applicationContext, REMINDER_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(r.title)
            .setContentText(r.message)
            .setStyle(androidx.core.app.NotificationCompat.BigTextStyle().bigText(r.message))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()

        runCatching {
            androidx.core.app.NotificationManagerCompat.from(applicationContext)
                .notify(r.id.toInt(), n)
        }
        dao.update(r.copy(lastFiredAt = System.currentTimeMillis()))
        return Result.success()
    }
}

private fun intervalDays(freq: String) = when (freq) {
    "DAILY" -> 1L
    "EVERY_2_DAYS" -> 2L
    "WEEKLY" -> 7L
    "BIWEEKLY" -> 14L
    "MONTHLY" -> 30L
    else -> 7L
}

fun scheduleReminder(ctx: Context, r: ReminderEntity) {
    val tag = "reminder-${r.id}"
    val wm = WorkManager.getInstance(ctx)
    if (!r.enabled) { wm.cancelUniqueWork(tag); return }

    val now = Calendar.getInstance()
    val next = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, r.hour); set(Calendar.MINUTE, r.minute)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        when (r.frequency) {
            "MONTHLY" -> {
                set(Calendar.DAY_OF_MONTH, r.dayOfMonth.coerceIn(1, 28))
                if (before(now)) add(Calendar.MONTH, 1)
            }
            "WEEKLY", "BIWEEKLY" -> {
                val want = r.daysOfWeek.split(",").mapNotNull { it.trim().toIntOrNull() }
                if (want.isNotEmpty()) {
                    var guard = 0
                    while ((get(Calendar.DAY_OF_WEEK) !in want || before(now)) && guard < 21) {
                        add(Calendar.DAY_OF_YEAR, 1); guard++
                    }
                } else if (before(now)) add(Calendar.DAY_OF_YEAR, 1)
            }
            else -> if (before(now)) add(Calendar.DAY_OF_YEAR, 1)
        }
    }

    val req = PeriodicWorkRequestBuilder<ReminderWorker>(intervalDays(r.frequency), TimeUnit.DAYS)
        .setInitialDelay((next.timeInMillis - now.timeInMillis).coerceAtLeast(0), TimeUnit.MILLISECONDS)
        .setInputData(workDataOf("reminderId" to r.id))
        .addTag(tag)
        .build()
    wm.enqueueUniquePeriodicWork(tag, ExistingPeriodicWorkPolicy.UPDATE, req)
}

fun cancelReminder(ctx: Context, id: Long) =
    WorkManager.getInstance(ctx).cancelUniqueWork("reminder-$id")
