package com.securemoney.manager.data

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale

/**
 * ══════════════════════════════════════════════════════════════════
 *  MONEY — why amounts are Long, and why currency travels with them
 * ══════════════════════════════════════════════════════════════════
 *
 * Amounts are stored as Long MINOR units (fils, paise, cents). Never
 * Double: floating point cannot represent 0.10 exactly, and across
 * thousands of rows that error compounds into a visibly wrong balance.
 *
 * A bare Long is dangerous though — nothing stops you adding 5000 paise
 * to 2000 fils and getting a meaningless 7000. So the app pairs every
 * amount with its currency and refuses to add across currencies.
 * See [MoneyBag], which is what totals are actually accumulated into.
 */

/** Currencies known to the app. Users can add their own at runtime. */
data class CurrencyInfo(
    val code: String,
    val symbol: String,
    val name: String,
    /** Decimal places. JPY/KWD differ from the usual 2. */
    val decimals: Int = 2
)

object Currencies {
    val BUILT_IN = listOf(
        CurrencyInfo("QAR", "QR",  "Qatari Riyal"),
        CurrencyInfo("INR", "₹",   "Indian Rupee"),
        CurrencyInfo("USD", "$",   "US Dollar"),
        CurrencyInfo("EUR", "€",   "Euro"),
        CurrencyInfo("GBP", "£",   "Pound Sterling"),
        CurrencyInfo("AED", "AED", "UAE Dirham"),
        CurrencyInfo("SAR", "SAR", "Saudi Riyal"),
        CurrencyInfo("KWD", "KWD", "Kuwaiti Dinar", decimals = 3),
        CurrencyInfo("BHD", "BHD", "Bahraini Dinar", decimals = 3),
        CurrencyInfo("OMR", "OMR", "Omani Rial",    decimals = 3),
        CurrencyInfo("PKR", "₨",   "Pakistani Rupee"),
        CurrencyInfo("BDT", "৳",   "Bangladeshi Taka"),
        CurrencyInfo("LKR", "Rs",  "Sri Lankan Rupee"),
        CurrencyInfo("PHP", "₱",   "Philippine Peso"),
        CurrencyInfo("EGP", "E£",  "Egyptian Pound"),
        CurrencyInfo("TRY", "₺",   "Turkish Lira"),
        CurrencyInfo("CAD", "C$",  "Canadian Dollar"),
        CurrencyInfo("AUD", "A$",  "Australian Dollar"),
        CurrencyInfo("CHF", "CHF", "Swiss Franc"),
        CurrencyInfo("SGD", "S$",  "Singapore Dollar"),
        CurrencyInfo("MYR", "RM",  "Malaysian Ringgit"),
        CurrencyInfo("THB", "฿",   "Thai Baht"),
        CurrencyInfo("JPY", "¥",   "Japanese Yen", decimals = 0),
        CurrencyInfo("CNY", "¥",   "Chinese Yuan"),
        CurrencyInfo("ZAR", "R",   "South African Rand"),
        CurrencyInfo("KES", "KSh", "Kenyan Shilling"),
        CurrencyInfo("NGN", "₦",   "Nigerian Naira"),
        CurrencyInfo("BRL", "R$",  "Brazilian Real"),
        CurrencyInfo("MXN", "Mex$","Mexican Peso"),
        CurrencyInfo("NPR", "Rs",  "Nepalese Rupee")
    )

    private val byCode = BUILT_IN.associateBy { it.code }

    fun info(code: String): CurrencyInfo =
        byCode[code.uppercase()] ?: CurrencyInfo(code.uppercase(), code.uppercase(), code.uppercase())

    fun decimals(code: String) = info(code).decimals
}

/** Format minor units for display, respecting the currency's decimal places. */
fun Long.format(currency: String, withCode: Boolean = true): String {
    val d = Currencies.decimals(currency)
    val value = BigDecimal(this).movePointLeft(d)
    val pattern = if (d == 0) "%,.0f" else "%,.${d}f"
    val num = String.format(Locale.US, pattern, value)
    return if (withCode) "$currency $num" else num
}

fun Long.formatSigned(currency: String, isExpense: Boolean): String =
    (if (isExpense) "−" else "+") + format(currency)

/** Parse user input ("1,450.75") into minor units for the given currency. */
fun String.toMinor(currency: String): Long? {
    val cleaned = trim().replace(",", "").replace(" ", "")
    if (cleaned.isEmpty()) return null
    val bd = cleaned.toBigDecimalOrNull() ?: return null
    return bd.movePointRight(Currencies.decimals(currency))
        .setScale(0, RoundingMode.HALF_UP).toLong()
}

/**
 * ══════════════════════════════════════════════════════════════════
 *  MONEY BAG — a total that refuses to lie
 * ══════════════════════════════════════════════════════════════════
 *
 * Holds one running total PER CURRENCY. There is deliberately no
 * `.total()` returning a single number, because that number cannot
 * exist without an exchange rate, and a rate baked into a total is a
 * number that silently goes stale.
 *
 * "QAR 22,110 · INR 222,700 · EUR 1,400" — three true figures instead
 * of one invented one.
 */
class MoneyBag private constructor(private val map: MutableMap<String, Long>) {

    constructor() : this(mutableMapOf())

    fun add(currency: String, minor: Long): MoneyBag {
        val c = currency.uppercase()
        map[c] = (map[c] ?: 0L) + minor
        return this
    }

    fun subtract(currency: String, minor: Long) = add(currency, -minor)

    operator fun get(currency: String): Long = map[currency.uppercase()] ?: 0L

    val currencies: List<String> get() = map.keys.sorted()
    val isEmpty: Boolean get() = map.isEmpty() || map.values.all { it == 0L }
    fun asMap(): Map<String, Long> = map.toMap()

    /** Non-zero entries only, biggest absolute value first. */
    fun entries(): List<Pair<String, Long>> =
        map.entries.filter { it.value != 0L }
            .sortedByDescending { kotlin.math.abs(it.value) }
            .map { it.key to it.value }

    /** "QAR 22,110 · INR 222,700". Never a single combined figure. */
    fun display(separator: String = "  ·  ", emptyText: String = "—"): String {
        val e = entries()
        return if (e.isEmpty()) emptyText
        else e.joinToString(separator) { (c, v) -> v.format(c) }
    }

    fun plus(other: MoneyBag): MoneyBag {
        val out = MoneyBag(map.toMutableMap())
        other.asMap().forEach { (c, v) -> out.add(c, v) }
        return out
    }

    companion object {
        fun of(vararg pairs: Pair<String, Long>) =
            MoneyBag().apply { pairs.forEach { add(it.first, it.second) } }
    }
}

/** Sum a collection into a MoneyBag, keeping currencies apart. */
inline fun <T> Iterable<T>.toMoneyBag(
    currencyOf: (T) -> String,
    minorOf: (T) -> Long
): MoneyBag {
    val bag = MoneyBag()
    for (item in this) bag.add(currencyOf(item), minorOf(item))
    return bag
}
