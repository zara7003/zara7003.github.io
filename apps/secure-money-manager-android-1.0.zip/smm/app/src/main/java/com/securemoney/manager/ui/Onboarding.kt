package com.securemoney.manager.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.securemoney.manager.data.Currencies

/**
 * First run. Five steps, none skippable, because the alternative is a
 * user who never learns that capture is off, that there is no recovery,
 * or that the app cannot reach the internet.
 */
@Composable
fun Onboarding(
    onFinish: (baseCurrency: String, groups: List<String>, acceptedTerms: Boolean) -> Unit
) {
    var step by remember { mutableIntStateOf(0) }
    var currency by remember { mutableStateOf("USD") }
    var groups by remember { mutableStateOf(listOf("Home")) }
    var newGroup by remember { mutableStateOf("") }
    var permsAcknowledged by remember { mutableStateOf(false) }
    var termsAccepted by remember { mutableStateOf(false) }

    val totalSteps = 5

    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {

            // Progress
            Row(Modifier.fillMaxWidth().padding(20.dp, 20.dp, 20.dp, 0.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                repeat(totalSteps) { i ->
                    Box(
                        Modifier.weight(1f).height(3.dp).clip(RoundedCornerShape(2.dp))
                            .background(
                                if (i <= step) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outlineVariant
                            )
                    )
                }
            }

            Box(Modifier.weight(1f).verticalScroll(rememberScrollState())
                .padding(24.dp, 28.dp, 24.dp, 16.dp)) {
                when (step) {

                    /* ── 0. Welcome ── */
                    0 -> Column {
                        Text("Secure Money Manager", fontSize = 26.sp,
                            fontWeight = FontWeight.SemiBold, lineHeight = 32.sp)
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "A ledger for money held in more than one country.",
                            fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(28.dp))
                        listOf(
                            "\uD83D\uDD0C" to "No internet permission at all. The app is technically incapable of uploading your data, showing ads, or phoning home.",
                            "\uD83D\uDD10" to "Optional AES-256 encryption on the database, unlocked by your passcode, passphrase or fingerprint.",
                            "\uD83C\uDF10" to "Every currency kept separate. Nothing is silently converted.",
                            "\uD83D\uDCE4" to "Exports happen only when you press the button, and go wherever you send them."
                        ).forEach { (icon, text) ->
                            Row(Modifier.padding(bottom = 18.dp)) {
                                Text(icon, fontSize = 20.sp, modifier = Modifier.width(36.dp))
                                Text(text, fontSize = 13.sp, lineHeight = 19.sp)
                            }
                        }
                        Text(
                            "Free and open source under GPL-3.0. Built by Sahil Shaikh and contributors.",
                            fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    /* ── 1. Base currency ── */
                    1 -> Column {
                        Text("Pick your main currency", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Used as the default for new accounts, and as the reference when you enter your own exchange rates. You can hold as many other currencies as you like.",
                            fontSize = 13.sp, lineHeight = 19.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(20.dp))
                        Currencies.BUILT_IN.chunked(1).forEach { row ->
                            row.forEach { c ->
                                Card(
                                    Modifier.fillMaxWidth().padding(bottom = 6.dp)
                                        .clickable { currency = c.code },
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (currency == c.code)
                                            MaterialTheme.colorScheme.primaryContainer
                                        else MaterialTheme.colorScheme.surface
                                    )
                                ) {
                                    Row(Modifier.fillMaxWidth().padding(14.dp),
                                        Arrangement.SpaceBetween, Alignment.CenterVertically) {
                                        Column {
                                            Text(c.code, fontSize = 14.sp,
                                                fontWeight = FontWeight.Medium,
                                                fontFamily = FontFamily.Monospace)
                                            Text(c.name, fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        if (currency == c.code)
                                            Icon(Icons.Default.Check, null,
                                                tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }

                    /* ── 2. Groups ── */
                    2 -> Column {
                        Text("Where do you keep money?", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Groups are how accounts get sorted — usually countries, but they can be anything: Business, Travel, Family. Each group can hold accounts in several currencies.",
                            fontSize = 13.sp, lineHeight = 19.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(20.dp))

                        groups.forEach { g ->
                            Row(
                                Modifier.fillMaxWidth().padding(bottom = 8.dp),
                                Arrangement.SpaceBetween, Alignment.CenterVertically
                            ) {
                                Text("\uD83C\uDF10  $g", fontSize = 14.sp)
                                if (groups.size > 1) {
                                    IconButton({ groups = groups - g }) {
                                        Icon(Icons.Default.Close, "Remove", Modifier.size(18.dp))
                                    }
                                }
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = newGroup, onValueChange = { newGroup = it },
                                placeholder = { Text("Add a group", fontSize = 13.sp) },
                                singleLine = true, modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(8.dp))
                            TextButton(
                                onClick = {
                                    val n = newGroup.trim()
                                    if (n.isNotBlank() && n !in groups) groups = groups + n
                                    newGroup = ""
                                }
                            ) { Text("Add") }
                        }

                        Spacer(Modifier.height(12.dp))
                        Text("Suggestions", fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(listOf("Qatar", "India", "UAE", "UK", "France", "Business", "Travel")) { s ->
                                AssistChip(
                                    onClick = { if (s !in groups) groups = groups + s },
                                    label = { Text(s, fontSize = 12.sp) }
                                )
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        InfoCard("Each group starts with a Bank and a Cash account in $currency. Rename, add or delete them freely afterwards.")
                    }

                    /* ── 3. Permissions — must be seen ── */
                    3 -> Column {
                        Text("What this app can and cannot do", fontSize = 22.sp,
                            fontWeight = FontWeight.SemiBold, lineHeight = 28.sp)
                        Spacer(Modifier.height(16.dp))

                        Card(
                            Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text("No internet access", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "This app does not request the INTERNET permission. Android will not let it open a network connection, so it cannot upload your data, load an advert, or check for anything online — even if it wanted to.",
                                    fontSize = 12.sp, lineHeight = 18.sp,
                                    modifier = Modifier.padding(top = 6.dp)
                                )
                            }
                        }

                        Spacer(Modifier.height(16.dp))
                        Text("Everything below is OFF right now", fontSize = 14.sp,
                            fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(8.dp))

                        listOf(
                            Triple("Reading bank SMS", "OFF",
                                "If you switch this on, you then approve individual senders one at a time. There is no option to read all messages. Anything from a sender you have not approved is discarded without being opened."),
                            Triple("Reading app notifications", "OFF",
                                "Same approach: you approve specific apps. Everything else is ignored."),
                            Triple("Reminder notifications", "OFF",
                                "You write your own reminders and choose when they appear. Android will ask for notification permission the first time you enable one, not now."),
                            Triple("Automatic exports", "OFF",
                                "There are none. Files are written only when you press Export, and shared only where you send them.")
                        ).forEach { (title, state, body) ->
                            Card(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                                Column(Modifier.padding(14.dp)) {
                                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                                        Text(title, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant
                                        ) {
                                            Text(state, Modifier.padding(6.dp, 2.dp),
                                                fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                        }
                                    }
                                    Text(body, fontSize = 11.sp, lineHeight = 17.sp,
                                        modifier = Modifier.padding(top = 6.dp),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        Spacer(Modifier.height(8.dp))
                        Row(
                            Modifier.fillMaxWidth().clickable { permsAcknowledged = !permsAcknowledged },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(permsAcknowledged, { permsAcknowledged = it })
                            Text("I have read this", fontSize = 13.sp)
                        }
                    }

                    /* ── 4. Terms ── */
                    4 -> Column {
                        Text("Terms of use", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(12.dp))
                        Surface(
                            Modifier.fillMaxWidth().heightIn(max = 380.dp),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
                                Text(TERMS_TEXT, fontSize = 11.sp, lineHeight = 17.sp)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(
                            Modifier.fillMaxWidth().clickable { termsAccepted = !termsAccepted },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(termsAccepted, { termsAccepted = it })
                            Text("I accept these terms", fontSize = 13.sp)
                        }
                    }
                }
            }

            // Navigation
            Row(Modifier.fillMaxWidth().padding(24.dp, 8.dp, 24.dp, 28.dp)) {
                if (step > 0) {
                    OutlinedButton({ step-- }, Modifier.weight(1f)) { Text("Back") }
                    Spacer(Modifier.width(10.dp))
                }
                Button(
                    onClick = {
                        if (step < totalSteps - 1) step++
                        else onFinish(currency, groups, true)
                    },
                    enabled = when (step) {
                        2 -> groups.isNotEmpty()
                        3 -> permsAcknowledged
                        4 -> termsAccepted
                        else -> true
                    },
                    modifier = Modifier.weight(if (step > 0) 1f else 1f)
                ) { Text(if (step < totalSteps - 1) "Continue" else "Start") }
            }
        }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  TERMS
 * ══════════════════════════════════════════════════════════════════ */
const val TERMS_TEXT = """SECURE MONEY MANAGER — TERMS OF USE

Version 1 · Free software under GPL-3.0

1. WHO MADE THIS

Secure Money Manager is built by Sahil Shaikh and contributors. The source code is public and open to review at the repository linked in the About screen. You are welcome to read it, audit it, fork it, or contribute to it.

2. COST

This app is free software, released under the GNU General Public License version 3. That licence is irrevocable for any version already released: this version is free, and will always remain free, and nobody can take that away — including us.

Future versions may be released under different terms. If that ever happens, every version published up to that point stays free and open under GPL-3.0, and anyone is free to continue from it.

We do not charge for the app. We do not show adverts. We do not sell data, because we do not receive any.

3. WHAT WE GUARANTEE

We guarantee that this app does not collect, transmit or sell your information, and that this is verifiable rather than merely promised.

The app does not request Android's INTERNET permission. Without it, the operating system refuses to let the app open a network connection at all. It cannot upload your records, report your activity, load an advert or contact any server, regardless of what its code says. You can confirm this yourself: check the permission list, or read the manifest in the public source.

Everything the app stores stays in its own private storage on your device. Data leaves only when you personally export a file and choose where to send it.

4. WHAT WE DO NOT GUARANTEE

To the maximum extent permitted by law, this software is provided "as is", without warranty of any kind. This mirrors sections 15 and 16 of the GPL-3.0, which form part of these terms.

Specifically, we do not promise that:

- every feature works on every Android device, version or manufacturer skin. Some manufacturers restrict background work, notification access or SMS delivery in ways we cannot control or always detect;
- automatic reading of bank messages will interpret every message correctly. Message formats vary between banks and change without notice. Treat parsed entries as a draft to check, never as authoritative;
- the app is free of defects.

You use this app at your own risk. We are not liable for any loss, including financial loss, data loss, missed payments, or decisions made on the basis of figures shown in the app.

Nothing here removes rights you hold under consumer protection law that cannot be excluded by agreement.

5. YOUR DATA IS YOUR RESPONSIBILITY

Because we hold none of your data, we cannot recover any of it.

- Keep your own backups. Use Export regularly and store the file somewhere you trust.
- Exported files in JSON, CSV and XLSX format are NOT encrypted. A backup sitting in cloud storage, an email or a chat app is only as private as that service. Use the encrypted export option if this matters to you.
- If you enable encryption and then forget your passphrase or passcode, and also lose your fingerprint enrolment, your data cannot be recovered by us, by you, or by anyone. There is no master key and no reset. This is a deliberate property of encryption, not an oversight.
- Secure your device itself. Encryption in this app protects the database file; it cannot protect you from malware running on a compromised phone.

6. NOT FINANCIAL, TAX OR LEGAL ADVICE

This app performs arithmetic on figures you enter. It is not an accountant, a tax tool, or a financial adviser, and its output is not advice. Where the app's figures differ from your bank's, your bank is authoritative. Consult a qualified professional for financial, tax or legal matters.

7. EXCHANGE RATES

The app never fetches exchange rates, because it has no internet access. Any rate shown is either one you entered yourself, or an indicative placeholder shipped with the app that is clearly marked as unconfirmed.

The app does not convert your balances. Each currency is reported separately and truthfully. Where a cross-currency settlement genuinely requires a rate, you supply it, and the figure you accept is stored permanently on that record rather than recalculated later.

8. PERMISSIONS

Every optional capability is switched off when you install the app. Reading bank SMS and reading app notifications each require you to enable them and then approve specific senders or apps individually. There is no setting that reads everything.

Content from a source you have not approved is discarded without being opened or stored. The app notes only that the sender exists, so that you can approve it later if you choose.

9. AGE

This app is intended for people aged 16 and over.

10. FEEDBACK IS GENUINELY WELCOME

If something does not work on your device, or a bank's messages are not being read correctly, please tell us — it is the main way the app improves, and we have no analytics to tell us instead.

Email: ops@sahilshaikh.org

Bug reports, feature ideas, translations and code contributions are all appreciated. Please do not include passwords, passphrases, full account numbers or unredacted bank messages in anything you send us.

11. CHANGES TO THESE TERMS

If these terms change materially, the app will ask you to read and accept the new version. Continuing to use an older release is always an option, since it remains available under GPL-3.0.

12. GOVERNING LAW

These terms are governed by the laws of the State of Qatar, without prejudice to consumer rights that apply where you live.

13. THE LICENCE ITSELF

This app is licensed under GPL-3.0. In short, you may use it for any purpose, study it, change it and redistribute it — provided you pass on the same freedoms, keep it open source, and state what you changed. The full licence text ships with the source code.

Last updated: this version accompanies release 1.0.
"""
