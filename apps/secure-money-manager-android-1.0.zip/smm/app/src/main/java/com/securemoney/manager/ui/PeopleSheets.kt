package com.securemoney.manager.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.securemoney.manager.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private val shortFmt = SimpleDateFormat("d MMM", Locale.US)

/* ══════════════════════════════════════════════════════════════════
 *  PERSON DETAIL
 * ══════════════════════════════════════════════════════════════════ */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonSheet(dao: SmmDao, person: PersonEntity, onDismiss: () -> Unit) {
    val accounts by dao.observeAccounts().collectAsStateWithLifecycle(emptyList())
    val cats by dao.observeCategories().collectAsStateWithLifecycle(emptyList())
    val entries by dao.observeForPerson(person.id).collectAsStateWithLifecycle(emptyList())
    val nets by dao.observePersonNets().collectAsStateWithLifecycle(emptyList())
    val costs by dao.observePersonCosts().collectAsStateWithLifecycle(emptyList())
    val openAdvances by dao.observeOpenAdvances(person.id).collectAsStateWithLifecycle(emptyList())
    val period = remember { currentPeriodKey() }
    val supportPaid by dao.observeSupportPaid(person.id, period).collectAsStateWithLifecycle(0L)

    var mode by remember { mutableStateOf<String?>(null) }
    var resolving by remember { mutableStateOf<TransactionEntity?>(null) }
    var editing by remember { mutableStateOf(false) }

    val myNets = nets.filter { it.personId == person.id && it.netMinor != 0L }
    val myCosts = costs.filter { it.personId == person.id }
        .toMoneyBag({ it.currency }, { it.netMinor })

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp).verticalScroll(rememberScrollState())) {
            Box(Modifier.fillMaxWidth(), Alignment.Center) {
                Box(Modifier.width(36.dp).height(4.dp).clip(RoundedCornerShape(2.dp))
                    .background(MaterialTheme.colorScheme.outline))
            }
            Spacer(Modifier.height(14.dp))

            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(44.dp).clip(RoundedCornerShape(22.dp))
                            .background(person.colorHex.toColorOr().copy(alpha = 0.2f)),
                        Alignment.Center
                    ) {
                        Text(person.name.take(2).uppercase(), fontSize = 13.sp,
                            color = person.colorHex.toColorOr())
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(person.name, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                        person.relationship.takeIf { it.isNotBlank() }?.let {
                            Text(it, fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                TextButton({ editing = true }) { Text("Edit", fontSize = 12.sp) }
            }

            /* Position — one line per currency, never combined. */
            Spacer(Modifier.height(14.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    if (myNets.isEmpty()) {
                        Text("All settled up", fontSize = 15.sp, fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        myNets.forEach { n ->
                            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                                Text(
                                    if (n.netMinor > 0) "Owes you" else "You owe",
                                    fontSize = 13.sp,
                                    color = if (n.netMinor > 0) inflow() else outflow()
                                )
                                Text(
                                    kotlin.math.abs(n.netMinor).format(n.currency),
                                    fontSize = 15.sp, fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Medium,
                                    color = if (n.netMinor > 0) inflow() else outflow()
                                )
                            }
                        }
                        if (myNets.size > 1) {
                            Text(
                                "Each currency settles on its own.",
                                fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    if (!myCosts.isEmpty) {
                        Spacer(Modifier.height(10.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Spacer(Modifier.height(8.dp))
                        Text("HAS COST YOU IN TOTAL", fontSize = 9.sp, letterSpacing = 1.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        myCosts.entries().forEach { (c, v) ->
                            Text(v.format(c), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }

            /* Recurring support tracker */
            if (person.allowanceMinor > 0) {
                val due = person.allowanceMinor
                val left = (due - supportPaid).coerceAtLeast(0)
                Spacer(Modifier.height(10.dp))
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("MONTHLY SUPPORT · $period", fontSize = 9.sp, letterSpacing = 1.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "${supportPaid.format(person.allowanceCurrency)} of ${due.format(person.allowanceCurrency)}",
                            fontSize = 14.sp, fontFamily = FontFamily.Monospace
                        )
                        LinearProgressIndicator(
                            progress = { (supportPaid.toFloat() / due).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                                .height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = if (left == 0L) inflow() else MaterialTheme.colorScheme.primary
                        )
                        Text(
                            if (left == 0L) "Covered this month — nothing more to send."
                            else "${left.format(person.allowanceCurrency)} still to send.",
                            fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp),
                            color = if (left == 0L) inflow() else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            /* Open advances awaiting resolution */
            if (openAdvances.isNotEmpty()) {
                FieldLabel("Waiting to be resolved (${openAdvances.size})")
                openAdvances.forEach { adv ->
                    Card(
                        Modifier.fillMaxWidth().padding(bottom = 6.dp)
                            .clickable { resolving = adv },
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(14.dp),
                            Arrangement.SpaceBetween, Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(adv.merchant, fontSize = 13.sp)
                                Text(
                                    "${PersonEntryType.label(adv.personEntryType)} · ${shortFmt.format(Date(adv.occurredAt))}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(adv.amountMinor.format(adv.currency), fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace)
                            Icon(Icons.Default.ChevronRight, null,
                                tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
                Text(
                    "Tap one to mark it repaid, absorb it as your own cost, or offset it against the monthly support.",
                    fontSize = 10.sp, lineHeight = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(16.dp))
            Button({ mode = "new" }, Modifier.fillMaxWidth()) { Text("Add entry") }

            FieldLabel("History")
            if (entries.isEmpty()) {
                Text("Nothing recorded yet.", fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            entries.forEach { e ->
                val isCost = e.personEntryType in PersonEntryType.PERSONAL_COST
                Column(Modifier.padding(vertical = 8.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(e.merchant, fontSize = 13.sp)
                            Text(
                                "${PersonEntryType.label(e.personEntryType)} · ${shortFmt.format(Date(e.occurredAt))}",
                                fontSize = 10.sp,
                                color = if (isCost) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(e.amountMinor.format(e.currency), fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (TxKind.reducesAccount(e.kind)) outflow() else inflow())
                            // Cross-currency settlement shows both sides.
                            if (e.fxCounterMinor != null && e.fxCounterCurrency != null) {
                                Text(
                                    "= ${e.fxCounterMinor.format(e.fxCounterCurrency)}",
                                    fontSize = 10.sp, fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
    }

    if (mode == "new") {
        PersonEntrySheet(dao, person, accounts, cats) { mode = null }
    }
    resolving?.let { adv ->
        ResolveAdvanceSheet(dao, person, adv, accounts, cats, period) { resolving = null }
    }
    if (editing) {
        PersonEditorSheet(dao, person) { editing = false }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  NEW PERSON ENTRY
 * ══════════════════════════════════════════════════════════════════ */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonEntrySheet(
    dao: SmmDao, person: PersonEntity,
    accounts: List<AccountEntity>, cats: List<CategoryEntity>,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var type by remember { mutableStateOf(PersonEntryType.PAID_FOR) }
    var accountId by remember { mutableStateOf(accounts.firstOrNull()?.id) }
    var amount by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var categoryId by remember { mutableStateOf(person.defaultAbsorbCategoryId) }
    var error by remember { mutableStateOf<String?>(null) }

    val account = accounts.firstOrNull { it.id == accountId }
    val currency = account?.currency ?: "USD"
    val needsCategory = type in PersonEntryType.PERSONAL_COST

    val options = listOf(
        PersonEntryType.PAID_FOR to "Money leaves your account now. They owe you.",
        PersonEntryType.RECEIVED_FOR to "Money arrives but it's theirs. You owe them.",
        PersonEntryType.SETTLE_IN to "They paid you back.",
        PersonEntryType.SETTLE_OUT to "You paid them back.",
        PersonEntryType.SUPPORT_PAID to "The regular monthly support. Your own cost, not a loan."
    )

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp).verticalScroll(rememberScrollState())) {
            SheetHeader("Entry for ${person.name}", "What actually happened")

            options.forEach { (key, help) ->
                Card(
                    Modifier.fillMaxWidth().padding(bottom = 6.dp).clickable { type = key },
                    colors = CardDefaults.cardColors(
                        containerColor = if (type == key)
                            MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(type == key, { type = key })
                        Column(Modifier.padding(start = 4.dp)) {
                            Text(PersonEntryType.label(key), fontSize = 13.sp)
                            Text(help, fontSize = 10.sp, lineHeight = 14.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            FieldLabel("Account")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(accounts, key = { it.id }) { a ->
                    FilterChip(accountId == a.id, { accountId = a.id },
                        { Text("${a.name} · ${a.currency}", fontSize = 11.sp) })
                }
            }

            FieldLabel("Amount in $currency")
            OutlinedTextField(
                value = amount, onValueChange = { amount = it; error = null },
                prefix = { Text(currency, fontSize = 13.sp, fontFamily = FontFamily.Monospace) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )

            FieldLabel("What was it for")
            OutlinedTextField(
                value = desc, onValueChange = { desc = it },
                placeholder = { Text("e.g. agency fee", fontSize = 12.sp) },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )

            if (needsCategory) {
                FieldLabel("Category — this counts as your own spending")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(cats.filter { it.isExpense }, key = { it.id }) { c ->
                        FilterChip(categoryId == c.id, { categoryId = c.id },
                            { Text("${c.icon} ${c.name}", fontSize = 11.sp) })
                    }
                }
            }

            error?.let {
                Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 12.dp))
            }

            Spacer(Modifier.height(18.dp))
            Button(
                onClick = {
                    val minor = amount.toMinor(currency)
                    when {
                        minor == null -> error = "Enter an amount."
                        account == null -> error = "Pick an account."
                        needsCategory && categoryId == null -> error = "Pick a category."
                        else -> scope.launch {
                            val out = type in setOf(
                                PersonEntryType.PAID_FOR, PersonEntryType.SETTLE_OUT,
                                PersonEntryType.SUPPORT_PAID
                            )
                            dao.insert(TransactionEntity(
                                merchant = desc.ifBlank {
                                    "${person.name} — ${PersonEntryType.label(type)}"
                                },
                                amountMinor = minor,
                                currency = currency,
                                kind = if (out) TxKind.EXPENSE else TxKind.INCOME,
                                accountId = account.id,
                                categoryId = if (needsCategory) categoryId else null,
                                personId = person.id,
                                personEntryType = type,
                                supportPeriod = if (type in PersonEntryType.SATISFIES_SUPPORT)
                                    currentPeriodKey() else null,
                                occurredAt = System.currentTimeMillis()
                            ))
                            onDismiss()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save entry") }
        }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  RESOLVE AN ADVANCE
 *  Three endings. The third can cross currencies, which is the only
 *  place in the app that needs a rate — and you supply it.
 * ══════════════════════════════════════════════════════════════════ */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResolveAdvanceSheet(
    dao: SmmDao, person: PersonEntity, advance: TransactionEntity,
    accounts: List<AccountEntity>, cats: List<CategoryEntity>,
    period: String, onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var choice by remember { mutableStateOf(PersonEntryType.SETTLE_IN) }
    var amount by remember {
        mutableStateOf(advance.amountMinor.format(advance.currency, withCode = false).replace(",", ""))
    }
    var accountId by remember { mutableStateOf(advance.accountId) }
    var categoryId by remember { mutableStateOf(person.defaultAbsorbCategoryId) }
    var counterAmount by remember { mutableStateOf("") }
    var rateWasIndicative by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val supportCurrency = person.allowanceCurrency
    val crossCurrency = choice == PersonEntryType.OFFSET_SUPPORT &&
        advance.currency != supportCurrency
    val needsCategory = choice != PersonEntryType.SETTLE_IN

    // Pre-fill the counter amount from any known rate, and remember whether
    // that rate was ever confirmed so we can warn.
    LaunchedEffect(choice, amount) {
        if (crossCurrency) {
            val r = dao.bestRate(advance.currency, supportCurrency)
            rateWasIndicative = r != null && !r.second
            val minor = amount.toMinor(advance.currency)
            if (r != null && minor != null) {
                val v = (minor / Math.pow(10.0, Currencies.decimals(advance.currency).toDouble())) * r.first
                counterAmount = String.format(
                    Locale.US, "%.${Currencies.decimals(supportCurrency)}f", v
                )
            }
        }
    }

    val choices = listOf(
        Triple(PersonEntryType.SETTLE_IN, "They paid me back",
            "Money comes into your account. The claim clears. Not your expense."),
        Triple(PersonEntryType.ABSORBED, "Absorb as my own cost",
            "No money moves — it already left. Becomes your expense under a category you pick."),
        Triple(PersonEntryType.OFFSET_SUPPORT, "Offset against monthly support",
            "Becomes your cost AND counts toward $period's support, so you skip that transfer.")
    )

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp).verticalScroll(rememberScrollState())) {
            SheetHeader(
                "Resolve ${advance.amountMinor.format(advance.currency)}",
                advance.merchant
            )

            choices.forEach { (key, title, help) ->
                val disabled = key == PersonEntryType.OFFSET_SUPPORT && person.allowanceMinor == 0L
                Card(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp)
                        .clickable(enabled = !disabled) { choice = key },
                    colors = CardDefaults.cardColors(
                        containerColor = if (choice == key)
                            MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(Modifier.padding(14.dp)) {
                        RadioButton(choice == key, { choice = key }, enabled = !disabled)
                        Column(Modifier.padding(start = 4.dp)) {
                            Text(title, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                                color = if (disabled) MaterialTheme.colorScheme.onSurfaceVariant
                                        else MaterialTheme.colorScheme.onSurface)
                            Text(
                                if (disabled) "Set a monthly support amount for ${person.name} first."
                                else help,
                                fontSize = 10.sp, lineHeight = 14.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            FieldLabel("Amount in ${advance.currency} — partial is fine")
            OutlinedTextField(
                value = amount, onValueChange = { amount = it; error = null },
                prefix = { Text(advance.currency, fontSize = 13.sp, fontFamily = FontFamily.Monospace) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                supportingText = {
                    Text("Resolve less than the full amount and the rest stays open.", fontSize = 10.sp)
                }
            )

            if (choice == PersonEntryType.SETTLE_IN) {
                FieldLabel("Which account received it")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(accounts.filter { it.currency == advance.currency }, key = { it.id }) { a ->
                        FilterChip(accountId == a.id, { accountId = a.id },
                            { Text(a.name, fontSize = 11.sp) })
                    }
                }
            }

            /* The one place a rate is genuinely needed. */
            if (crossCurrency) {
                FieldLabel("How much $supportCurrency support does this cover?")
                OutlinedTextField(
                    value = counterAmount, onValueChange = { counterAmount = it; error = null },
                    prefix = { Text(supportCurrency, fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                val a = amount.toMinor(advance.currency)
                val b = counterAmount.toMinor(supportCurrency)
                if (a != null && b != null && a > 0) {
                    val implied = (b / Math.pow(10.0, Currencies.decimals(supportCurrency).toDouble())) /
                        (a / Math.pow(10.0, Currencies.decimals(advance.currency).toDouble()))
                    Text(
                        "Rate: 1 ${advance.currency} = ${"%.4f".format(implied)} $supportCurrency",
                        fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(top = 6.dp),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(Modifier.height(8.dp))
                InfoCard(
                    if (rateWasIndicative)
                        "The suggestion above came from an indicative rate that has never been confirmed. Change it to whatever you and ${person.name} actually agreed — that figure is stored on this record permanently and never recalculated."
                    else
                        "Whatever you enter is stored on this record permanently and never recalculated, so this settlement can't drift later.",
                    tone = if (rateWasIndicative) "warn" else "neutral"
                )
            }

            if (needsCategory) {
                FieldLabel("Your category for this cost")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(cats.filter { it.isExpense }, key = { it.id }) { c ->
                        FilterChip(categoryId == c.id, { categoryId = c.id },
                            { Text("${c.icon} ${c.name}", fontSize = 11.sp) })
                    }
                }
                Text(
                    "It'll appear in Budgets and your outflow from now on.",
                    fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            error?.let {
                Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 12.dp))
            }

            Spacer(Modifier.height(18.dp))
            Button(
                onClick = {
                    val minor = amount.toMinor(advance.currency)
                    val counterMinor = if (crossCurrency) counterAmount.toMinor(supportCurrency) else null
                    when {
                        minor == null -> error = "Enter an amount."
                        minor > advance.amountMinor ->
                            error = "That's more than the ${advance.amountMinor.format(advance.currency)} advance."
                        needsCategory && categoryId == null ->
                            error = "Pick a category — this becomes your own expense."
                        crossCurrency && counterMinor == null ->
                            error = "Enter how much support this covers."
                        else -> scope.launch {
                            val remaining = advance.amountMinor - minor
                            val rate = if (counterMinor != null && minor > 0)
                                counterMinor.toDouble() / minor.toDouble() else null

                            if (choice == PersonEntryType.SETTLE_IN) {
                                // Real money came back: a new income row clears it.
                                dao.insert(TransactionEntity(
                                    merchant = "${person.name} repaid: ${advance.merchant}",
                                    amountMinor = minor,
                                    currency = advance.currency,
                                    kind = TxKind.INCOME,
                                    accountId = accountId,
                                    personId = person.id,
                                    personEntryType = PersonEntryType.SETTLE_IN,
                                    settlesTransactionId = advance.id,
                                    occurredAt = System.currentTimeMillis()
                                ))
                                if (remaining > 0) dao.update(advance.copy(amountMinor = remaining))
                                else dao.delete(advance)
                            } else {
                                // Absorb / offset: no money moves — the cash already
                                // left. So RECLASSIFY the original row rather than
                                // inserting a second one, which would double-count it.
                                if (remaining <= 0L) {
                                    dao.update(advance.copy(
                                        personEntryType = choice,
                                        categoryId = categoryId,
                                        supportPeriod = if (choice == PersonEntryType.OFFSET_SUPPORT)
                                            period else null,
                                        fxCounterCurrency = if (crossCurrency) supportCurrency else null,
                                        fxCounterMinor = counterMinor,
                                        fxRateUsed = rate,
                                        note = (advance.note + " · " +
                                            PersonEntryType.label(choice)).trim()
                                    ))
                                } else {
                                    // Partial: shrink the advance and add a sibling
                                    // row for the resolved slice, so both are auditable.
                                    dao.update(advance.copy(amountMinor = remaining))
                                    dao.insert(advance.copy(
                                        id = 0,
                                        amountMinor = minor,
                                        personEntryType = choice,
                                        categoryId = categoryId,
                                        settlesTransactionId = advance.id,
                                        supportPeriod = if (choice == PersonEntryType.OFFSET_SUPPORT)
                                            period else null,
                                        fxCounterCurrency = if (crossCurrency) supportCurrency else null,
                                        fxCounterMinor = counterMinor,
                                        fxRateUsed = rate,
                                        merchant = advance.merchant + " (part)"
                                    ))
                                }
                            }
                            onDismiss()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Record resolution") }
        }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  PERSON EDITOR
 * ══════════════════════════════════════════════════════════════════ */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonEditorSheet(dao: SmmDao, existing: PersonEntity?, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val cats by dao.observeCategories().collectAsStateWithLifecycle(emptyList())
    val accounts by dao.observeAccounts().collectAsStateWithLifecycle(emptyList())

    var name by remember { mutableStateOf(existing?.name ?: "") }
    var relationship by remember { mutableStateOf(existing?.relationship ?: "") }
    var color by remember { mutableStateOf(existing?.colorHex ?: COLOR_CHOICES[4]) }
    var aliases by remember { mutableStateOf(existing?.smsAliases ?: "") }
    var autoMatch by remember { mutableStateOf(existing?.autoMatchSms ?: false) }
    var supportCurrency by remember {
        mutableStateOf(existing?.allowanceCurrency
            ?: accounts.firstOrNull()?.currency ?: "USD")
    }
    var support by remember {
        mutableStateOf(existing?.allowanceMinor?.takeIf { it > 0 }
            ?.format(existing.allowanceCurrency, withCode = false)?.replace(",", "") ?: "")
    }
    var absorbCat by remember { mutableStateOf(existing?.defaultAbsorbCategoryId) }
    var error by remember { mutableStateOf<String?>(null) }

    val currencies = accounts.map { it.currency }.distinct().ifEmpty { listOf("USD") }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp).verticalScroll(rememberScrollState())) {
            SheetHeader(
                if (existing == null) "Add person" else "Edit ${existing.name}",
                "Someone you lend to, borrow from, or support"
            )

            FieldLabel("Name")
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )

            FieldLabel("Relationship (optional)")
            OutlinedTextField(
                value = relationship, onValueChange = { relationship = it },
                placeholder = { Text("Family, friend, colleague…", fontSize = 12.sp) },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )

            FieldLabel("Colour")
            ColorPicker(color) { color = it }

            FieldLabel("Recurring monthly support — leave blank if none")
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = support, onValueChange = { support = it },
                    placeholder = { Text("0.00", fontSize = 12.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true, modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(currencies) { c ->
                        FilterChip(supportCurrency == c, { supportCurrency = c },
                            { Text(c, fontSize = 10.sp, fontFamily = FontFamily.Monospace) })
                    }
                }
            }
            Text(
                "A regular amount you send. Advances you end up absorbing can be offset against it, so you never pay twice — even when the advance was in a different currency.",
                fontSize = 10.sp, lineHeight = 14.sp,
                modifier = Modifier.padding(top = 4.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            FieldLabel("Default category when a cost becomes yours")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(cats.filter { it.isExpense }, key = { it.id }) { c ->
                    FilterChip(absorbCat == c.id, { absorbCat = c.id },
                        { Text("${c.icon} ${c.name}", fontSize = 11.sp) })
                }
            }

            FieldLabel("Match this person in bank messages")
            SwitchRow(
                "Auto-match from SMS",
                "Only works if you've enabled SMS reading and approved a sender.",
                autoMatch
            ) { autoMatch = it }
            if (autoMatch) {
                OutlinedTextField(
                    value = aliases, onValueChange = { aliases = it },
                    placeholder = { Text("Other names, comma separated", fontSize = 12.sp) },
                    supportingText = { Text("Longest match wins.", fontSize = 10.sp) },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            }

            error?.let {
                Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 12.dp))
            }

            Spacer(Modifier.height(18.dp))
            Row {
                if (existing != null) {
                    OutlinedButton(
                        onClick = { scope.launch { dao.update(existing.copy(archived = true)); onDismiss() } },
                        modifier = Modifier.weight(1f)
                    ) { Text("Archive") }
                    Spacer(Modifier.width(8.dp))
                }
                Button(
                    onClick = {
                        if (name.isBlank()) { error = "Enter a name."; return@Button }
                        scope.launch {
                            val row = PersonEntity(
                                id = existing?.id ?: 0,
                                name = name.trim(),
                                relationship = relationship.trim(),
                                colorHex = color,
                                smsAliases = aliases.trim(),
                                autoMatchSms = autoMatch,
                                allowanceMinor = support.toMinor(supportCurrency) ?: 0,
                                allowanceCurrency = supportCurrency,
                                defaultAbsorbCategoryId = absorbCat
                            )
                            if (existing == null) dao.insert(row) else dao.update(row)
                            onDismiss()
                        }
                    },
                    modifier = Modifier.weight(1.4f)
                ) { Text("Save") }
            }
        }
    }
}
