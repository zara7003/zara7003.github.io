package com.securemoney.manager

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/**
 * Thin wrapper around BiometricPrompt. Kept separate from Crypto so that
 * file has no Activity/Fragment dependency and stays trivially unit
 * testable — this one, being UI-bound, isn't.
 */
object BiometricAuth {

    fun isAvailable(ctx: Context): Boolean {
        val mgr = BiometricManager.from(ctx)
        return mgr.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG
        ) == BiometricManager.BIOMETRIC_SUCCESS
    }

    fun prompt(
        activity: FragmentActivity,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(activity)
        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                onSuccess()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                onError(errString.toString())
            }
            override fun onAuthenticationFailed() {
                // A single rejected fingerprint isn't a final error — the
                // prompt itself stays open for another attempt.
            }
        }
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock Secure Money Manager")
            .setSubtitle("Confirm it's you")
            .setNegativeButtonText("Use passphrase instead")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build()
        BiometricPrompt(activity, executor, callback).authenticate(info)
    }
}
