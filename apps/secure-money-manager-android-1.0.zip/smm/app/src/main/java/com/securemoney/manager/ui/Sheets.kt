package com.securemoney.manager.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.securemoney.manager.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

// DatePicker / TimePicker (Material3) need opt-in on some compiler configs;
// the sheet-level @OptIn above already covers ExperimentalMaterial3Api.

/* ══════════════════════════════════════════════════════════════════
 *  ADD / EDIT TRANSACTION
 * ══════════════════════════════════════════════════════════════════ */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionSheet(dao: SmmDao, existing: TransactionEntity?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val groups by dao.observeGroups().collectAsStateWithLifecycle(emptyList())
    val accounts by dao.observeAccounts().collectAsStateWithLifecycle(emptyList())
    val cats by dao.observeCategories().collectAsStateWithLifecycle(emptyList())
    val people by dao.observePeople().collectAsStateWithLifecycle(emptyList())

    var isExpense by remember { mutableStateOf(existing?.kind != TxKind.INCOME) }
    var accountId by remember { mutableStateOf(existing?.accountId) }
    var amount by remember {
        mutableStateOf(existing?.let {
            it.amountMinor.format(it.currency, withCode = false).replace(",", "")
        } ?: "")
    }
    var merchant by remember { mutableStateOf(existing?.merchant ?: "") }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var categoryId by remember { mutableStateOf(existing?.categoryId) }
    var personId by remember { mutableStateOf(existing?.personId) }
    var photoUri by remember { mutableStateOf(existing?.photoUri) }
    var tagInput by remember { mutableStateOf("") }
    var tags by remember { mutableStateOf(listOf<String>()) }
    var error by remember { mutableStateOf<String?>(null) }

    // Date and time default to now, but are always adjustable — a receipt
    // from yesterday shouldn't have to be logged as if it happened now.
    val cal = remember {
        Calendar.getInstance().apply {
            timeInMillis = existing?.occurredAt ?: System.currentTimeMillis()
        }
    }
    var occurredAt by remember { mutableLongStateOf(cal.timeInMillis) }
    var showDatePicker by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }

    LaunchedEffect(existing?.id) {
        existing?.let { tags = dao.tagsFor(it.id).map { t -> t.name } }
    }
    LaunchedEffect(accounts) { if (accountId == null) accountId = accounts.firstOrNull()?.id }

    val account = accounts.firstOrNull { it.id == accountId }
    val currency = account?.currency ?: "USD"
    val group = account?.let { a -> groups.firstOrNull { it.id == a.groupId } }
    val visibleCats = cats.filter { it.isExpense == isExpense }

    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            // Persistable permission, so the photo survives a reboot.
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(
                    it, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            photoUri = it.toString()
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp).verticalScroll(rememberScrollState())) {
            SheetHeader(
                if (existing == null) "New entry" else "Edit entry",
                "Amount is always positive — the direction is set below"
            )

            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = isExpense,
                    onClick = { isExpense = true; categoryId = null },
                    shape = SegmentedButtonDefaults.itemShape(0, 2),
                    label = { Text("Money out", fontSize = 13.sp) }
                )
                SegmentedButton(
                    selected = !isExpense,
                    onClick = { isExpense = false; categoryId = null },
                    shape = SegmentedButtonDefaults.itemShape(1, 2),
                    label = { Text("Money in", fontSize = 13.sp) }
                )
            }

            FieldLabel("Account")
            // Grouped so you can see which country an account belongs to.
            groups.forEach { g ->
                val inGroup = accounts.filter { it.groupId == g.id }
                if (inGroup.isEmpty()) return@forEach
                Text("${g.icon} ${g.name}", fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp, bottom = 4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(inGroup, key = { it.id }) { a ->
                        FilterChip(
                            selected = accountId == a.id,
                            onClick = { accountId = a.id },
                            label = { Text("${a.name} · ${a.currency}", fontSize = 11.sp) }
                        )
                    }
                }
            }

            FieldLabel("Amount in $currency")
            OutlinedTextField(
                value = amount, onValueChange = { amount = it; error = null },
                placeholder = { Text("0.00") },
                prefix = { Text(currency, fontSize = 13.sp, fontFamily = FontFamily.Monospace) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                textStyle = MaterialTheme.typography.headlineSmall.copy(fontFamily = FontFamily.Monospace)
            )
            group?.let {
                Text("Recorded against ${it.name}", fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp))
            }

            FieldLabel("Merchant or description")
            OutlinedTextField(
                value = merchant, onValueChange = { merchant = it },
                placeholder = { Text("Where did it go?", fontSize = 13.sp) },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )

            FieldLabel("Category")
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.height(if (visibleCats.size > 8) 176.dp else 92.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(visibleCats, key = { it.id }) { c ->
                    val sel = categoryId == c.id
                    Column(
                        Modifier.clip(RoundedCornerShape(12.dp))
                            .background(
                                if (sel) c.colorHex.toColorOr().copy(alpha = 0.2f)
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .clickable { categoryId = c.id }
                            .padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(c.icon, fontSize = 17.sp)
                        Text(c.name, fontSize = 8.sp, maxLines = 1,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            FieldLabel("Tags")
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = tagInput, onValueChange = { tagInput = it },
                    placeholder = { Text("comma separated", fontSize = 12.sp) },
                    singleLine = true, modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(6.dp))
                TextButton({
                    tagInput.split(",").map { it.trim().removePrefix("#").lowercase() }
                        .filter { it.isNotBlank() }.forEach { if (it !in tags) tags = tags + it }
                    tagInput = ""
                }) { Text("Add") }
            }
            if (tags.isNotEmpty()) {
                LazyRow(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(tags) { t ->
                        InputChip(
                            selected = false, onClick = { tags = tags - t },
                            label = { Text("#$t", fontSize = 11.sp) },
                            trailingIcon = { Icon(Icons.Default.Close, null, Modifier.size(13.dp)) }
                        )
                    }
                }
            }

            FieldLabel("Receipt photo")
            if (photoUri != null) {
                Box {
                    AsyncImage(
                        model = photoUri, contentDescription = "Receipt",
                        modifier = Modifier.fillMaxWidth().height(130.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )
                    IconButton({ photoUri = null }, Modifier.align(Alignment.TopEnd)) {
                        Icon(Icons.Default.Close, "Remove")
                    }
                }
            } else {
                OutlinedButton({ pickPhoto.launch(arrayOf("image/*")) }, Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.AttachFile, null, Modifier.size(15.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Attach photo", fontSize = 13.sp)
                }
            }

            FieldLabel("For someone else?")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item {
                    FilterChip(personId == null, { personId = null },
                        { Text("Just me", fontSize = 11.sp) })
                }
                items(people, key = { it.id }) { p ->
                    FilterChip(personId == p.id, { personId = p.id },
                        { Text(p.name, fontSize = 11.sp) })
                }
            }
            if (personId != null) {
                Text(
                    "Kept out of your own spending until you resolve it on the People screen.",
                    fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp),
                    color = MaterialTheme.colorScheme.primary
                )
            }

            FieldLabel("Date & time")
            Row {
                OutlinedButton(
                    onClick = { showDatePicker = true },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.CalendarMonth, null, Modifier.size(15.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        SimpleDateFormat("d MMM yyyy", Locale.US)
                            .format(Date(occurredAt)),
                        fontSize = 12.sp
                    )
                }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(
                    onClick = { showTimePicker = true },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Schedule, null, Modifier.size(15.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        SimpleDateFormat("h:mm a", Locale.US).format(Date(occurredAt)),
                        fontSize = 12.sp
                    )
                }
            }
            Text(
                "Defaults to now — change it for a receipt from earlier or a bill you're logging late.",
                fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            FieldLabel("Note")
            OutlinedTextField(
                value = note, onValueChange = { note = it },
                minLines = 2, modifier = Modifier.fillMaxWidth()
            )

            error?.let {
                Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 12.dp))
            }

            Spacer(Modifier.height(18.dp))
            Row {
                if (existing != null) {
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                // Deleting half a transfer would corrupt both
                                // balances, so remove the pair together.
                                existing.transferPairId
                                    ?.let { dao.deleteTransfer(it) }
                                    ?: dao.delete(existing)
                                onDismiss()
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Delete") }
                    Spacer(Modifier.width(8.dp))
                }
                Button(
                    onClick = {
                        val minor = amount.toMinor(currency)
                        when {
                            minor == null -> error = "Enter an amount above zero."
                            account == null -> error = "Choose an account."
                            merchant.isBlank() -> error = "Add a description."
                            else -> scope.launch {
                                val row = TransactionEntity(
                                    id = existing?.id ?: 0,
                                    merchant = merchant.trim(),
                                    note = note.trim(),
                                    amountMinor = minor,
                                    currency = currency,
                                    kind = if (isExpense) TxKind.EXPENSE else TxKind.INCOME,
                                    accountId = account.id,
                                    categoryId = categoryId,
                                    personId = personId,
                                    personEntryType = personId?.let {
                                        if (isExpense) PersonEntryType.PAID_FOR
                                        else PersonEntryType.RECEIVED_FOR
                                    },
                                    photoUri = photoUri,
                                    occurredAt = occurredAt,
                                    source = existing?.source ?: "MANUAL",
                                    confirmed = true
                                )
                                val id = if (existing == null) dao.insert(row)
                                         else { dao.update(row); row.id }
                                dao.clearTags(id)
                                tags.forEach { dao.attachTag(id, it) }
                                categoryId?.let {
                                    dao.learn(LearnedRuleEntity.MERCHANT_CATEGORY, merchant.trim(), it)
                                }
                                onDismiss()
                            }
                        }
                    },
                    modifier = Modifier.weight(1.4f)
                ) { Text("Save") }
            }
        }
    }

    if (showDatePicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = occurredAt)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton({
                    state.selectedDateMillis?.let { picked ->
                        // Keep the existing time of day, only the date changes.
                        val old = Calendar.getInstance().apply { timeInMillis = occurredAt }
                        val new = Calendar.getInstance().apply {
                            timeInMillis = picked
                            set(Calendar.HOUR_OF_DAY, old.get(Calendar.HOUR_OF_DAY))
                            set(Calendar.MINUTE, old.get(Calendar.MINUTE))
                        }
                        occurredAt = new.timeInMillis
                    }
                    showDatePicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton({ showDatePicker = false }) { Text("Cancel") } }
        ) { DatePicker(state = state) }
    }

    if (showTimePicker) {
        val init = Calendar.getInstance().apply { timeInMillis = occurredAt }
        val state = rememberTimePickerState(
            initialHour = init.get(Calendar.HOUR_OF_DAY),
            initialMinute = init.get(Calendar.MINUTE)
        )
        AlertDialog(
            onDismissRequest = { showTimePicker = false },
            confirmButton = {
                TextButton({
                    val new = Calendar.getInstance().apply {
                        timeInMillis = occurredAt
                        set(Calendar.HOUR_OF_DAY, state.hour)
                        set(Calendar.MINUTE, state.minute)
                    }
                    occurredAt = new.timeInMillis
                    showTimePicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton({ showTimePicker = false }) { Text("Cancel") } },
            text = { TimePicker(state = state) }
        )
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  TRANSFER — including across currencies
 * ══════════════════════════════════════════════════════════════════ */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransferSheet(dao: SmmDao, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val groups by dao.observeGroups().collectAsStateWithLifecycle(emptyList())
    val accounts by dao.observeAccounts().collectAsStateWithLifecycle(emptyList())

    var fromId by remember { mutableStateOf<Long?>(null) }
    var toId by remember { mutableStateOf<Long?>(null) }
    var fromAmount by remember { mutableStateOf("") }
    var toAmount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var suggestedRate by remember { mutableStateOf<Pair<Double, Boolean>?>(null) }

    val from = accounts.firstOrNull { it.id == fromId }
    val to = accounts.firstOrNull { it.id == toId }
    val crossCurrency = from != null && to != null && from.currency != to.currency

    // Pre-fill the receiving amount from whatever rate we know, flagging
    // whether that rate was ever confirmed by the user.
    LaunchedEffect(fromId, toId, fromAmount) {
        if (from != null && to != null && from.currency != to.currency) {
            val r = dao.bestRate(from.currency, to.currency)
            suggestedRate = r
            val minor = fromAmount.toMinor(from.currency)
            if (r != null && minor != null && toAmount.isBlank()) {
                val converted = (minor / Math.pow(10.0, Currencies.decimals(from.currency).toDouble())) * r.first
                toAmount = String.format(Locale.US, "%.${Currencies.decimals(to.currency)}f", converted)
            }
        } else suggestedRate = null
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp).verticalScroll(rememberScrollState())) {
            SheetHeader("Transfer", "Moving your own money — never counted as spending")

            @Composable
            fun accountPicker(label: String, selected: Long?, onPick: (Long) -> Unit) {
                FieldLabel(label)
                groups.forEach { g ->
                    val inGroup = accounts.filter { it.groupId == g.id }
                    if (inGroup.isEmpty()) return@forEach
                    Text("${g.icon} ${g.name}", fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp, bottom = 3.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(inGroup, key = { it.id }) { a ->
                            FilterChip(
                                selected = selected == a.id,
                                onClick = { onPick(a.id) },
                                label = { Text("${a.name} · ${a.currency}", fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }

            accountPicker("From", fromId) { fromId = it; toAmount = "" }
            accountPicker("To", toId) { toId = it; toAmount = "" }

            if (from != null && to != null && from.id == to.id) {
                Text("Pick two different accounts.", fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 8.dp))
            }

            FieldLabel("Amount leaving ${from?.name ?: "source"}")
            OutlinedTextField(
                value = fromAmount,
                onValueChange = { fromAmount = it; if (!crossCurrency) toAmount = it; error = null },
                prefix = { Text(from?.currency ?: "", fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )

            if (crossCurrency) {
                FieldLabel("Amount arriving in ${to?.name}")
                OutlinedTextField(
                    value = toAmount, onValueChange = { toAmount = it; error = null },
                    prefix = { Text(to?.currency ?: "", fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )

                val fMinor = fromAmount.toMinor(from!!.currency)
                val tMinor = toAmount.toMinor(to!!.currency)
                if (fMinor != null && tMinor != null && fMinor > 0) {
                    val implied = (tMinor.toDouble() / Math.pow(10.0, Currencies.decimals(to.currency).toDouble())) /
                        (fMinor.toDouble() / Math.pow(10.0, Currencies.decimals(from.currency).toDouble()))
                    Text(
                        "Rate: 1 ${from.currency} = ${"%.4f".format(implied)} ${to.currency}",
                        fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(top = 6.dp),
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Spacer(Modifier.height(10.dp))
                InfoCard(
                    if (suggestedRate?.second == false)
                        "The pre-filled amount used an indicative rate that has never been confirmed. Enter what you actually received — that figure is stored on this record permanently and never recalculated."
                    else
                        "Enter what actually arrived, including any fees the bank took. The rate is worked out from your two figures and frozen onto this record.",
                    tone = if (suggestedRate?.second == false) "warn" else "neutral"
                )
            }

            FieldLabel("Note")
            OutlinedTextField(
                value = note, onValueChange = { note = it },
                placeholder = { Text("e.g. monthly remittance", fontSize = 12.sp) },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )

            error?.let {
                Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 12.dp))
            }

            Spacer(Modifier.height(18.dp))
            Button(
                onClick = {
                    val f = from; val t = to
                    val fMinor = fromAmount.toMinor(f?.currency ?: "USD")
                    val tMinor = if (crossCurrency) toAmount.toMinor(t?.currency ?: "USD") else fMinor
                    when {
                        f == null || t == null -> error = "Pick both accounts."
                        f.id == t.id -> error = "Pick two different accounts."
                        fMinor == null -> error = "Enter the amount leaving."
                        tMinor == null -> error = "Enter the amount arriving."
                        else -> scope.launch {
                            dao.insertTransfer(f, t, fMinor, tMinor, note.trim(), System.currentTimeMillis())
                            onDismiss()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Record transfer") }
        }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  GROUP EDITOR
 * ══════════════════════════════════════════════════════════════════ */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupEditorSheet(dao: SmmDao, existing: GroupEntity?, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var icon by remember { mutableStateOf(existing?.icon ?: "\uD83C\uDF10") }
    var color by remember { mutableStateOf(existing?.colorHex ?: COLOR_CHOICES[2]) }
    var currency by remember { mutableStateOf(existing?.defaultCurrency ?: "USD") }
    var error by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp).verticalScroll(rememberScrollState())) {
            SheetHeader(
                if (existing == null) "New group" else "Edit ${existing.name}",
                "A country, or anything else you sort accounts by"
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(50.dp).clip(RoundedCornerShape(14.dp))
                        .background(color.toColorOr().copy(alpha = 0.18f)),
                    Alignment.Center
                ) { Text(icon, fontSize = 24.sp) }
                Spacer(Modifier.width(12.dp))
                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    placeholder = { Text("Group name") },
                    singleLine = true, modifier = Modifier.weight(1f)
                )
            }

            FieldLabel("Icon")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(FLAG_CHOICES) { f ->
                    Box(
                        Modifier.size(42.dp).clip(RoundedCornerShape(10.dp))
                            .background(
                                if (icon == f) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .clickable { icon = f },
                        Alignment.Center
                    ) { Text(f, fontSize = 19.sp) }
                }
            }

            FieldLabel("Colour")
            ColorPicker(color) { color = it }

            FieldLabel("Default currency for new accounts here")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(Currencies.BUILT_IN) { c ->
                    FilterChip(
                        selected = currency == c.code,
                        onClick = { currency = c.code },
                        label = { Text(c.code, fontSize = 11.sp, fontFamily = FontFamily.Monospace) }
                    )
                }
            }
            Text(
                "Only a default. Accounts in this group can each use a different currency.",
                fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            error?.let {
                Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 12.dp))
            }

            Spacer(Modifier.height(18.dp))
            Row {
                if (existing != null) {
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                val accountsHere = dao.allAccountsOnce()
                                    .count { it.groupId == existing.id && !it.archived }
                                if (accountsHere > 0) {
                                    error = "Move or archive its $accountsHere accounts first."
                                } else {
                                    dao.update(existing.copy(archived = true)); onDismiss()
                                }
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Archive") }
                    Spacer(Modifier.width(8.dp))
                }
                Button(
                    onClick = {
                        if (name.isBlank()) { error = "Give the group a name."; return@Button }
                        scope.launch {
                            val row = GroupEntity(
                                id = existing?.id ?: 0, name = name.trim(), icon = icon,
                                colorHex = color, defaultCurrency = currency,
                                sortOrder = existing?.sortOrder ?: 99
                            )
                            if (existing == null) dao.insert(row) else dao.update(row)
                            onDismiss()
                        }
                    },
                    modifier = Modifier.weight(1.4f)
                ) { Text("Save") }
            }
        }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  ACCOUNT EDITOR
 * ══════════════════════════════════════════════════════════════════ */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountEditorSheet(
    dao: SmmDao,
    existing: AccountEntity?,
    presetGroupId: Long?,
    computedBalance: Long = 0,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val groups by dao.observeGroups().collectAsStateWithLifecycle(emptyList())

    var name by remember { mutableStateOf(existing?.name ?: "") }
    var groupId by remember { mutableStateOf(existing?.groupId ?: presetGroupId) }
    var currency by remember { mutableStateOf(existing?.currency ?: "") }
    var type by remember { mutableStateOf(existing?.type ?: "BANK") }
    var icon by remember { mutableStateOf(existing?.icon ?: "\uD83C\uDFE6") }
    var color by remember { mutableStateOf(existing?.colorHex ?: COLOR_CHOICES[2]) }
    var digits by remember { mutableStateOf(existing?.accountDigits ?: "") }
    var opening by remember {
        mutableStateOf(existing?.openingBalanceMinor?.takeIf { it != 0L }
            ?.let { it.format(existing.currency, withCode = false).replace(",", "") } ?: "")
    }
    var actual by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }

    // Default the currency from the group, once.
    LaunchedEffect(groupId, groups) {
        if (currency.isBlank()) {
            currency = groups.firstOrNull { it.id == groupId }?.defaultCurrency ?: "USD"
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp).verticalScroll(rememberScrollState())) {
            SheetHeader(
                if (existing == null) "New account" else "Edit ${existing.name}",
                "Balances carry forward automatically — this is the starting figure"
            )

            FieldLabel("Name")
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                placeholder = { Text("e.g. Savings, Cash, Visa") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )

            FieldLabel("Group")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(groups, key = { it.id }) { g ->
                    FilterChip(
                        selected = groupId == g.id,
                        onClick = { groupId = g.id },
                        label = { Text("${g.icon} ${g.name}", fontSize = 11.sp) }
                    )
                }
            }

            FieldLabel("Currency")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(Currencies.BUILT_IN) { c ->
                    FilterChip(
                        selected = currency == c.code,
                        onClick = { if (existing == null) currency = c.code },
                        enabled = existing == null,
                        label = { Text(c.code, fontSize = 11.sp, fontFamily = FontFamily.Monospace) }
                    )
                }
            }
            if (existing != null) {
                Text(
                    "Currency can't change after creation — its transactions are already recorded in ${existing.currency}. Create a new account instead.",
                    fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            FieldLabel("Type")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(AccountEntity.TYPES) { (t, ic) ->
                    FilterChip(
                        selected = type == t,
                        onClick = { type = t; icon = ic },
                        label = {
                            Text(t.lowercase().replaceFirstChar { it.uppercase() }, fontSize = 11.sp)
                        }
                    )
                }
            }
            if (AccountEntity.isLiability(type)) {
                Text("Enter what you owe as a negative opening balance.",
                    fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp),
                    color = MaterialTheme.colorScheme.primary)
            }

            FieldLabel("Opening balance")
            OutlinedTextField(
                value = opening, onValueChange = { opening = it },
                placeholder = { Text("0.00") },
                prefix = { Text(currency, fontSize = 13.sp, fontFamily = FontFamily.Monospace) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                supportingText = {
                    Text("What was in this account before you started tracking.", fontSize = 10.sp)
                }
            )

            FieldLabel("Last digits (helps match bank messages)")
            OutlinedTextField(
                value = digits, onValueChange = { digits = it.filter { c -> c.isDigit() }.take(4) },
                placeholder = { Text("e.g. 4821", fontSize = 12.sp) },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )

            if (existing != null) {
                FieldLabel("Reconcile against your bank")
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                            Text("This app says", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(computedBalance.format(existing.currency), fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace)
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = actual, onValueChange = { actual = it },
                            label = { Text("Balance your bank shows", fontSize = 12.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                val a = actual.trim().replace(",", "").toBigDecimalOrNull()
                                    ?.movePointRight(Currencies.decimals(existing.currency))
                                    ?.toLong()
                                if (a == null) { error = "Enter the bank's figure."; return@OutlinedButton }
                                val diff = a - computedBalance
                                if (diff == 0L) { info = "Already matches."; return@OutlinedButton }
                                scope.launch {
                                    dao.insert(TransactionEntity(
                                        merchant = "Balance adjustment",
                                        note = "Reconciled " + SimpleDateFormat("d MMM yyyy", Locale.US)
                                            .format(Date()),
                                        amountMinor = kotlin.math.abs(diff),
                                        currency = existing.currency,
                                        kind = TxKind.ADJUSTMENT,
                                        accountId = existing.id,
                                        source = "ADJUSTMENT",
                                        occurredAt = System.currentTimeMillis()
                                    ))
                                    info = "Recorded an adjustment of ${kotlin.math.abs(diff).format(existing.currency)}."
                                    actual = ""
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Record the difference", fontSize = 13.sp) }
                        Text(
                            "Adds a visible adjustment entry rather than quietly rewriting history.",
                            fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            FieldLabel("Colour")
            ColorPicker(color) { color = it }

            error?.let {
                Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 12.dp))
            }
            info?.let {
                Text(it, fontSize = 12.sp, color = inflow(),
                    modifier = Modifier.padding(top = 12.dp))
            }

            Spacer(Modifier.height(18.dp))
            Row {
                if (existing != null) {
                    OutlinedButton(
                        onClick = { scope.launch { dao.update(existing.copy(archived = true)); onDismiss() } },
                        modifier = Modifier.weight(1f)
                    ) { Text("Archive") }
                    Spacer(Modifier.width(8.dp))
                }
                Button(
                    onClick = {
                        val g = groupId
                        when {
                            name.isBlank() -> error = "Give the account a name."
                            g == null -> error = "Pick a group."
                            currency.isBlank() -> error = "Pick a currency."
                            else -> scope.launch {
                                val row = AccountEntity(
                                    id = existing?.id ?: 0, name = name.trim(), groupId = g,
                                    currency = currency, type = type,
                                    openingBalanceMinor = opening.trim().replace(",", "")
                                        .toBigDecimalOrNull()
                                        ?.movePointRight(Currencies.decimals(currency))
                                        ?.toLong() ?: 0,
                                    colorHex = color, icon = icon,
                                    accountDigits = digits,
                                    sortOrder = existing?.sortOrder ?: 99
                                )
                                if (existing == null) dao.insert(row) else dao.update(row)
                                onDismiss()
                            }
                        }
                    },
                    modifier = Modifier.weight(1.4f)
                ) { Text("Save") }
            }
        }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  CATEGORY EDITOR — with per-currency caps
 * ══════════════════════════════════════════════════════════════════ */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryEditorSheet(dao: SmmDao, existing: CategoryEntity?, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val accounts by dao.observeAccounts().collectAsStateWithLifecycle(emptyList())
    val budgets by dao.observeBudgets().collectAsStateWithLifecycle(emptyList())

    var name by remember { mutableStateOf(existing?.name ?: "") }
    var icon by remember { mutableStateOf(existing?.icon ?: "\u2754") }
    var color by remember { mutableStateOf(existing?.colorHex ?: COLOR_CHOICES[0]) }
    var isExpense by remember { mutableStateOf(existing?.isExpense ?: true) }
    var error by remember { mutableStateOf<String?>(null) }

    // A cap per currency you actually hold — no point offering EUR if you
    // have no EUR account.
    val currencies = accounts.map { it.currency }.distinct().sorted()
    val myBudgets = existing?.let { e -> budgets.filter { it.categoryId == e.id } } ?: emptyList()
    val capText = remember(myBudgets) {
        mutableStateMapOf<String, String>().apply {
            currencies.forEach { cur ->
                val b = myBudgets.firstOrNull { it.currency == cur }
                put(cur, b?.monthlyLimitMinor?.takeIf { it > 0 }
                    ?.format(cur, withCode = false)?.replace(",", "") ?: "")
            }
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp).verticalScroll(rememberScrollState())) {
            SheetHeader(
                if (existing == null) "New category" else "Edit ${existing.name}",
                "Caps are separate for each currency"
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(50.dp).clip(RoundedCornerShape(14.dp))
                        .background(color.toColorOr().copy(alpha = 0.18f)),
                    Alignment.Center
                ) { Text(icon, fontSize = 23.sp) }
                Spacer(Modifier.width(12.dp))
                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    placeholder = { Text("Category name") },
                    singleLine = true, modifier = Modifier.weight(1f)
                )
            }

            FieldLabel("Type")
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = isExpense, onClick = { isExpense = true },
                    shape = SegmentedButtonDefaults.itemShape(0, 2),
                    label = { Text("Expense", fontSize = 13.sp) }
                )
                SegmentedButton(
                    selected = !isExpense, onClick = { isExpense = false },
                    shape = SegmentedButtonDefaults.itemShape(1, 2),
                    label = { Text("Income", fontSize = 13.sp) }
                )
            }

            FieldLabel("Icon")
            EmojiPicker(icon) { icon = it }

            FieldLabel("Colour")
            ColorPicker(color) { color = it }

            if (isExpense && currencies.isNotEmpty()) {
                FieldLabel("Monthly caps — blank means no cap")
                currencies.forEach { cur ->
                    OutlinedTextField(
                        value = capText[cur] ?: "",
                        onValueChange = { capText[cur] = it },
                        prefix = { Text(cur, fontSize = 13.sp, fontFamily = FontFamily.Monospace) },
                        placeholder = { Text("no cap", fontSize = 12.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                    )
                }
                Text(
                    "Each cap is tracked on its own. A QAR limit and an INR limit never interact.",
                    fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            error?.let {
                Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 12.dp))
            }

            Spacer(Modifier.height(18.dp))
            Row {
                if (existing != null) {
                    OutlinedButton(
                        onClick = { scope.launch { dao.update(existing.copy(archived = true)); onDismiss() } },
                        modifier = Modifier.weight(1f)
                    ) { Text("Archive") }
                    Spacer(Modifier.width(8.dp))
                }
                Button(
                    onClick = {
                        if (name.isBlank()) { error = "Give the category a name."; return@Button }
                        scope.launch {
                            val row = CategoryEntity(
                                id = existing?.id ?: 0, name = name.trim(),
                                isExpense = isExpense, icon = icon, colorHex = color,
                                sortOrder = existing?.sortOrder ?: 99
                            )
                            val id = if (existing == null) dao.insert(row)
                                     else { dao.update(row); row.id }
                            if (isExpense) {
                                currencies.forEach { cur ->
                                    val minor = capText[cur]?.toMinor(cur)
                                    if (minor != null && minor > 0) {
                                        dao.insert(BudgetEntity(
                                            categoryId = id, currency = cur,
                                            monthlyLimitMinor = minor
                                        ))
                                    } else {
                                        dao.deleteBudget(id, cur)
                                    }
                                }
                            }
                            onDismiss()
                        }
                    },
                    modifier = Modifier.weight(1.4f)
                ) { Text("Save") }
            }
        }
    }
}
