package com.securemoney.manager.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.securemoney.manager.*
import com.securemoney.manager.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/* ══════════════════════════════════════════════════════════════════
 *  ENCRYPTION SETUP
 * ══════════════════════════════════════════════════════════════════ */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EncryptionSetupSheet(
    onEnabled: (ByteArray) -> Unit,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    var mode by remember { mutableStateOf(Crypto.LockMode.PASSPHRASE) }
    var secret by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var reveal by remember { mutableStateOf(false) }
    var alsoBiometric by remember { mutableStateOf(true) }
    var acknowledged by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val (strength, hint) = Crypto.assess(secret, mode)
    val strengthColor = when (strength) {
        0, 1 -> MaterialTheme.colorScheme.error
        2 -> MaterialTheme.colorScheme.primary
        else -> inflow()
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp).verticalScroll(rememberScrollState())) {
            SheetHeader("Encrypt your data", "AES-256 on the database file itself")

            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                )
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("There is no recovery", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Forget this and lose your fingerprint enrolment, and the data is gone for good. That is what encryption means. Export a backup and keep it somewhere safe before you continue.",
                        fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            FieldLabel("Lock type")
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = mode == Crypto.LockMode.PASSCODE,
                    onClick = { mode = Crypto.LockMode.PASSCODE; secret = ""; confirm = "" },
                    shape = SegmentedButtonDefaults.itemShape(0, 2),
                    label = { Text("Passcode", fontSize = 13.sp) }
                )
                SegmentedButton(
                    selected = mode == Crypto.LockMode.PASSPHRASE,
                    onClick = { mode = Crypto.LockMode.PASSPHRASE; secret = ""; confirm = "" },
                    shape = SegmentedButtonDefaults.itemShape(1, 2),
                    label = { Text("Passphrase", fontSize = 13.sp) }
                )
            }
            Text(
                if (mode == Crypto.LockMode.PASSCODE)
                    "Digits only. Quick to type, weaker against a determined attacker."
                else
                    "Words and symbols. Four unrelated words beat a short complicated password.",
                fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            FieldLabel(if (mode == Crypto.LockMode.PASSCODE) "Passcode" else "Passphrase")
            OutlinedTextField(
                value = secret, onValueChange = { secret = it },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (reveal) VisualTransformation.None
                                       else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = if (mode == Crypto.LockMode.PASSCODE)
                        KeyboardType.NumberPassword else KeyboardType.Password
                ),
                trailingIcon = {
                    IconButton({ reveal = !reveal }) {
                        Icon(if (reveal) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                    }
                }
            )
            if (secret.isNotEmpty()) {
                LinearProgressIndicator(
                    progress = { (strength + 1) / 4f },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                        .height(4.dp).clip(RoundedCornerShape(2.dp)),
                    color = strengthColor
                )
                Text(hint, fontSize = 10.sp, color = strengthColor,
                    modifier = Modifier.padding(top = 4.dp))
            }

            FieldLabel("Confirm")
            OutlinedTextField(
                value = confirm, onValueChange = { confirm = it },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (reveal) VisualTransformation.None
                                       else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = if (mode == Crypto.LockMode.PASSCODE)
                        KeyboardType.NumberPassword else KeyboardType.Password
                ),
                isError = confirm.isNotEmpty() && confirm != secret
            )

            FieldLabel("Convenience")
            ListItem(
                headlineContent = { Text("Also unlock with fingerprint", fontSize = 13.sp) },
                supportingContent = {
                    Text(
                        "Stores a second copy of the key in hardware, released only by your fingerprint. Adding or removing a fingerprint invalidates it, so someone can't enrol their own finger to get in. Your passphrase always still works.",
                        fontSize = 10.sp
                    )
                },
                trailingContent = { Switch(alsoBiometric, { alsoBiometric = it }) }
            )

            ListItem(
                headlineContent = {
                    Text("I have saved a backup and understand there is no recovery",
                        fontSize = 12.sp)
                },
                leadingContent = { Checkbox(acknowledged, { acknowledged = it }) }
            )

            error?.let {
                Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 8.dp))
            }

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    when {
                        strength == 0 -> error = hint
                        secret != confirm -> error = "The two entries don't match."
                        !acknowledged -> error = "Please confirm you've saved a backup."
                        else -> {
                            val key = Crypto.enableEncryption(
                                ctx, secret.toCharArray(), mode, alsoBiometric
                            )
                            onEnabled(key)
                        }
                    }
                },
                enabled = secret.isNotEmpty() && confirm.isNotEmpty(),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Encrypt now") }
        }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  UNLOCK
 * ══════════════════════════════════════════════════════════════════ */
@Composable
fun UnlockScreen(
    mode: Crypto.LockMode,
    biometricAvailable: Boolean,
    onSubmitSecret: (CharArray) -> Boolean,
    onBiometric: () -> Unit
) {
    val ctx = LocalContext.current
    var secret by remember { mutableStateOf("") }
    var reveal by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var waitUntil by remember { mutableLongStateOf(0L) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    // Tick so the countdown updates.
    LaunchedEffect(waitUntil) {
        while (waitUntil > System.currentTimeMillis()) {
            now = System.currentTimeMillis()
            kotlinx.coroutines.delay(500)
        }
        now = System.currentTimeMillis()
    }
    val locked = waitUntil > now
    val secondsLeft = ((waitUntil - now) / 1000).coerceAtLeast(0)

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            Arrangement.Center, Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.Lock, null, Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(16.dp))
            Text("Secure Money Manager is locked", style = MaterialTheme.typography.titleMedium)
            Text("Your data is encrypted on this device.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)

            Spacer(Modifier.height(28.dp))
            OutlinedTextField(
                value = secret, onValueChange = { secret = it; error = null },
                label = {
                    Text(if (mode == Crypto.LockMode.PASSCODE) "Passcode" else "Passphrase")
                },
                singleLine = true, enabled = !locked,
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (reveal) VisualTransformation.None
                                       else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = if (mode == Crypto.LockMode.PASSCODE)
                        KeyboardType.NumberPassword else KeyboardType.Password
                ),
                trailingIcon = {
                    IconButton({ reveal = !reveal }) {
                        Icon(if (reveal) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                    }
                },
                isError = error != null
            )
            error?.let {
                Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 8.dp))
            }
            if (locked) {
                Text("Too many attempts. Try again in ${secondsLeft}s.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 8.dp))
            }

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    if (onSubmitSecret(secret.toCharArray())) {
                        Crypto.clearFailures(ctx)
                    } else {
                        val n = Crypto.recordFailure(ctx)
                        error = "That's not right."
                        val back = Crypto.backoffMillis(n)
                        if (back > 0) waitUntil = System.currentTimeMillis() + back
                        secret = ""
                    }
                },
                enabled = secret.isNotEmpty() && !locked,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Unlock") }

            if (biometricAvailable) {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onBiometric, Modifier.fillMaxWidth(), enabled = !locked) {
                    Icon(Icons.Default.Fingerprint, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Use fingerprint")
                }
            }

            Spacer(Modifier.height(24.dp))
            Text(
                "There is no password reset. If you've lost your passphrase, reinstall the app and import your last export.",
                fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  CHANGE PASSPHRASE
 * ══════════════════════════════════════════════════════════════════ */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChangeSecretSheet(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var old by remember { mutableStateOf("") }
    var new by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(Crypto.lockMode(ctx)) }
    var msg by remember { mutableStateOf<String?>(null) }
    var ok by remember { mutableStateOf(false) }

    val (strength, hint) = Crypto.assess(new, mode)

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp).verticalScroll(rememberScrollState())) {
            SheetHeader("Change your lock",
                "Re-wraps the same key, so nothing is re-encrypted and it can't half-fail")

            FieldLabel("Current")
            OutlinedTextField(old, { old = it }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth())

            FieldLabel("New lock type")
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = mode == Crypto.LockMode.PASSCODE,
                    onClick = { mode = Crypto.LockMode.PASSCODE },
                    shape = SegmentedButtonDefaults.itemShape(0, 2),
                    label = { Text("Passcode", fontSize = 13.sp) }
                )
                SegmentedButton(
                    selected = mode == Crypto.LockMode.PASSPHRASE,
                    onClick = { mode = Crypto.LockMode.PASSPHRASE },
                    shape = SegmentedButtonDefaults.itemShape(1, 2),
                    label = { Text("Passphrase", fontSize = 13.sp) }
                )
            }

            FieldLabel("New")
            OutlinedTextField(new, { new = it }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth())
            if (new.isNotEmpty()) {
                Text(hint, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp),
                    color = if (strength <= 1) MaterialTheme.colorScheme.error
                            else MaterialTheme.colorScheme.onSurfaceVariant)
            }

            FieldLabel("Confirm new")
            OutlinedTextField(confirm, { confirm = it }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                isError = confirm.isNotEmpty() && confirm != new,
                modifier = Modifier.fillMaxWidth())

            msg?.let {
                Text(it, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp),
                    color = if (ok) inflow() else MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    when {
                        strength == 0 -> { ok = false; msg = hint }
                        new != confirm -> { ok = false; msg = "New entries don't match." }
                        else -> {
                            val done = Crypto.changeSecret(
                                ctx, old.toCharArray(), new.toCharArray(), mode
                            )
                            ok = done
                            msg = if (done) "Changed. Your fingerprint still works."
                                  else "Current passphrase is wrong."
                            if (done) { old = ""; new = ""; confirm = "" }
                        }
                    }
                },
                enabled = old.isNotEmpty() && new.isNotEmpty(),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Change lock") }
        }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  SMS SENDER ALLOWLIST
 * ══════════════════════════════════════════════════════════════════ */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmsSendersSheet(dao: SmmDao, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val senders by dao.observeSmsSenders().collectAsStateWithLifecycle(emptyList())
    val candidates by dao.observeCandidates().collectAsStateWithLifecycle(emptyList())
    val accounts by dao.observeAccounts().collectAsStateWithLifecycle(emptyList())
    val rules by dao.observeSmsRules().collectAsStateWithLifecycle(emptyList())
    var manual by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<SmsSenderEntity?>(null) }

    val smsCandidates = candidates.filter { it.source == "SMS" }
    val df = remember { SimpleDateFormat("d MMM HH:mm", Locale.US) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp)) {
            SheetHeader("Approved SMS senders",
                "Only these are read. An empty list means no messages are read at all.")

            LazyColumn(Modifier.heightIn(max = 460.dp)) {
                if (senders.isEmpty()) {
                    item {
                        Card(
                            Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        ) {
                            Text(
                                "Nothing approved yet, so nothing is being read. Add a sender below.",
                                Modifier.padding(14.dp), fontSize = 12.sp
                            )
                        }
                    }
                }

                items(senders, key = { it.id }) { s ->
                    ListItem(
                        modifier = Modifier.clickable { editing = s },
                        headlineContent = {
                            Text(s.label.ifBlank { s.sender }, fontSize = 14.sp)
                        },
                        supportingContent = {
                            Text(
                                buildString {
                                    append(s.sender)
                                    append(" · ${s.messageCount} read")
                                    s.defaultAccountId?.let { id ->
                                        accounts.firstOrNull { it.id == id }
                                            ?.let { append(" → ${it.name}") }
                                    }
                                },
                                fontSize = 10.sp, fontFamily = FontFamily.Monospace
                            )
                        },
                        trailingContent = {
                            Switch(s.enabled, { on ->
                                scope.launch { dao.update(s.copy(enabled = on)) }
                            })
                        }
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                }

                /* Candidates: seen, never read. Only the sender ID was kept. */
                if (smsCandidates.isNotEmpty()) {
                    item {
                        Text("SEEN BUT NOT READ", Modifier.padding(top = 16.dp, bottom = 4.dp),
                            fontSize = 10.sp, letterSpacing = 1.sp,
                            color = MaterialTheme.colorScheme.primary)
                    }
                    item {
                        Text(
                            "These senders messaged you. Their content was never opened or stored — only the sender ID and a count.",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    items(smsCandidates, key = { it.id }) { c ->
                        ListItem(
                            headlineContent = { Text(c.identifier, fontSize = 13.sp) },
                            supportingContent = {
                                Text("${c.seenCount} messages · last ${df.format(Date(c.lastSeenAt))}",
                                    fontSize = 10.sp)
                            },
                            trailingContent = {
                                Row {
                                    TextButton(onClick = {
                                        scope.launch {
                                            dao.insert(SmsSenderEntity(
                                                sender = c.identifier,
                                                label = c.identifier
                                            ))
                                            dao.delete(c)
                                        }
                                    }) { Text("Approve", fontSize = 12.sp) }
                                    IconButton(onClick = {
                                        scope.launch { dao.update(c.copy(dismissed = true)) }
                                    }) { Icon(Icons.Default.Close, "Ignore", Modifier.size(16.dp)) }
                                }
                            }
                        )
                    }
                }
            }

            FieldLabel("Add manually")
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = manual, onValueChange = { manual = it },
                    placeholder = { Text("Sender ID or number", fontSize = 13.sp) },
                    singleLine = true, modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                TextButton(
                    onClick = {
                        if (manual.isNotBlank()) {
                            scope.launch {
                                dao.insert(SmsSenderEntity(
                                    sender = manual.trim(), label = manual.trim()
                                ))
                                manual = ""
                            }
                        }
                    }
                ) { Text("Add") }
            }
        }
    }

    editing?.let { s ->
        SenderDetailSheet(dao, s, accounts, rules) { editing = null }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SenderDetailSheet(
    dao: SmmDao,
    sender: SmsSenderEntity,
    accounts: List<AccountEntity>,
    rules: List<SmsRuleEntity>,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var label by remember { mutableStateOf(sender.label) }
    var accountId by remember { mutableStateOf(sender.defaultAccountId) }
    var ruleId by remember { mutableStateOf(sender.smsRuleId) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp).verticalScroll(rememberScrollState())) {
            SheetHeader(sender.sender, "${sender.messageCount} messages read so far")

            FieldLabel("Label")
            OutlinedTextField(label, { label = it }, singleLine = true,
                placeholder = { Text("e.g. QNB credit card") },
                modifier = Modifier.fillMaxWidth())

            FieldLabel("Always use this account")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(accountId == null, { accountId = null },
                        { Text("Work it out", fontSize = 12.sp) })
                }
                items(accounts, key = { it.id }) { a ->
                    FilterChip(accountId == a.id, { accountId = a.id },
                        { Text("${a.name} · ${a.currency}", fontSize = 12.sp) })
                }
            }
            Text(
                "Pinning the account is more reliable than guessing from the card digits in the message.",
                fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            FieldLabel("Parsing rule")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(ruleId == null, { ruleId = null },
                        { Text("Best match", fontSize = 12.sp) })
                }
                items(rules, key = { it.id }) { r ->
                    FilterChip(ruleId == r.id, { ruleId = r.id },
                        { Text(r.label, fontSize = 12.sp) })
                }
            }

            Spacer(Modifier.height(20.dp))
            Row {
                OutlinedButton(
                    onClick = { scope.launch { dao.delete(sender); onDismiss() } },
                    modifier = Modifier.weight(1f)
                ) { Text("Remove") }
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = {
                        scope.launch {
                            dao.update(sender.copy(
                                label = label.trim(),
                                defaultAccountId = accountId,
                                smsRuleId = ruleId
                            ))
                            onDismiss()
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Save") }
            }
        }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  NOTIFICATION APP ALLOWLIST
 * ══════════════════════════════════════════════════════════════════ */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotifAppsSheet(dao: SmmDao, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val apps by dao.observeNotifApps().collectAsStateWithLifecycle(emptyList())
    val candidates by dao.observeCandidates().collectAsStateWithLifecycle(emptyList())
    val accounts by dao.observeAccounts().collectAsStateWithLifecycle(emptyList())
    val notifCandidates = candidates.filter { it.source == "NOTIFICATION" }
    val df = remember { SimpleDateFormat("d MMM HH:mm", Locale.US) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp)) {
            SheetHeader("Approved apps",
                "Only notifications from these apps are read. Empty means none.")

            LazyColumn(Modifier.heightIn(max = 460.dp)) {
                if (apps.isEmpty()) {
                    item {
                        Card(
                            Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        ) {
                            Text(
                                "No apps approved, so no notifications are read. Open your banking app once and it will appear below to approve.",
                                Modifier.padding(14.dp), fontSize = 12.sp
                            )
                        }
                    }
                }

                items(apps, key = { it.id }) { a ->
                    ListItem(
                        headlineContent = { Text(a.appLabel.ifBlank { a.packageName }, fontSize = 14.sp) },
                        supportingContent = {
                            Text("${a.packageName} · ${a.messageCount} read",
                                fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        },
                        trailingContent = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Switch(a.enabled, { on ->
                                    scope.launch { dao.update(a.copy(enabled = on)) }
                                })
                                IconButton({ scope.launch { dao.delete(a) } }) {
                                    Icon(Icons.Default.Delete, "Remove", Modifier.size(18.dp))
                                }
                            }
                        }
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                }

                if (notifCandidates.isNotEmpty()) {
                    item {
                        Text("APPS THAT NOTIFIED YOU", Modifier.padding(top = 16.dp, bottom = 4.dp),
                            fontSize = 10.sp, letterSpacing = 1.sp,
                            color = MaterialTheme.colorScheme.primary)
                    }
                    item {
                        Text(
                            "Their notification text was never read or stored — only the app name and a count.",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    items(notifCandidates, key = { it.id }) { c ->
                        ListItem(
                            headlineContent = {
                                Text(c.displayLabel.ifBlank { c.identifier }, fontSize = 13.sp)
                            },
                            supportingContent = {
                                Text("${c.seenCount} notifications · last ${df.format(Date(c.lastSeenAt))}",
                                    fontSize = 10.sp)
                            },
                            trailingContent = {
                                Row {
                                    TextButton(onClick = {
                                        scope.launch {
                                            dao.insert(NotifAppEntity(
                                                packageName = c.identifier,
                                                appLabel = c.displayLabel
                                            ))
                                            dao.delete(c)
                                        }
                                    }) { Text("Approve", fontSize = 12.sp) }
                                    IconButton(onClick = {
                                        scope.launch { dao.update(c.copy(dismissed = true)) }
                                    }) { Icon(Icons.Default.Close, "Ignore", Modifier.size(16.dp)) }
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  REMINDERS
 * ══════════════════════════════════════════════════════════════════ */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RemindersSheet(dao: SmmDao, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val reminders by dao.observeReminders().collectAsStateWithLifecycle(emptyList())
    var editing by remember { mutableStateOf<ReminderEntity?>(null) }
    var creating by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp)) {
            SheetHeader("Reminders", "All off until you switch one on")

            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(reminders, key = { it.id }) { r ->
                    ListItem(
                        modifier = Modifier.clickable { editing = r },
                        headlineContent = { Text(r.title, fontSize = 14.sp) },
                        supportingContent = {
                            Text(
                                ReminderEntity.FREQUENCIES.firstOrNull { it.first == r.frequency }
                                    ?.second + " at %02d:%02d".format(r.hour, r.minute),
                                fontSize = 11.sp
                            )
                        },
                        trailingContent = {
                            Switch(r.enabled, { on ->
                                scope.launch {
                                    val updated = r.copy(enabled = on)
                                    dao.update(updated)
                                    if (on) scheduleReminder(ctx, updated)
                                    else cancelReminder(ctx, r.id)
                                }
                            })
                        }
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                }
            }

            Spacer(Modifier.height(12.dp))
            OutlinedButton({ creating = true }, Modifier.fillMaxWidth()) {
                Text("Write your own reminder")
            }
            Text(
                "Reminders are local notifications from this app. Nothing is sent anywhere.",
                fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }

    val target = editing ?: if (creating) ReminderEntity(title = "", message = "") else null
    target?.let { r ->
        ReminderEditor(dao, r, isNew = editing == null) { editing = null; creating = false }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReminderEditor(dao: SmmDao, r: ReminderEntity, isNew: Boolean, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf(r.title) }
    var message by remember { mutableStateOf(r.message) }
    var frequency by remember { mutableStateOf(r.frequency) }
    var hour by remember { mutableIntStateOf(r.hour) }
    var minute by remember { mutableIntStateOf(r.minute) }
    var days by remember { mutableStateOf(r.daysOfWeek.split(",").mapNotNull { it.trim().toIntOrNull() }) }
    var dayOfMonth by remember { mutableIntStateOf(r.dayOfMonth) }
    var action by remember { mutableStateOf(r.action) }
    var error by remember { mutableStateOf<String?>(null) }

    val dayNames = listOf(1 to "Sun", 2 to "Mon", 3 to "Tue", 4 to "Wed",
        5 to "Thu", 6 to "Fri", 7 to "Sat")

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp).verticalScroll(rememberScrollState())) {
            SheetHeader(if (isNew) "New reminder" else "Edit reminder",
                "Your words, your schedule")

            FieldLabel("Title")
            OutlinedTextField(title, { title = it }, singleLine = true,
                placeholder = { Text("e.g. Log today's cash") },
                modifier = Modifier.fillMaxWidth())

            FieldLabel("Message")
            OutlinedTextField(message, { message = it }, minLines = 2,
                placeholder = { Text("What you want to be told") },
                modifier = Modifier.fillMaxWidth())

            FieldLabel("How often")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ReminderEntity.FREQUENCIES) { (key, lab) ->
                    FilterChip(frequency == key, { frequency = key },
                        { Text(lab, fontSize = 12.sp) })
                }
            }

            if (frequency == "WEEKLY" || frequency == "BIWEEKLY") {
                FieldLabel("Which days")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(dayNames) { (n, lab) ->
                        FilterChip(
                            selected = n in days,
                            onClick = { days = if (n in days) days - n else days + n },
                            label = { Text(lab, fontSize = 11.sp) }
                        )
                    }
                }
            }

            if (frequency == "MONTHLY") {
                FieldLabel("Day of month")
                OutlinedTextField(
                    value = if (dayOfMonth == -1) "last" else dayOfMonth.toString(),
                    onValueChange = {
                        dayOfMonth = if (it.trim().lowercase() == "last") -1
                                     else it.toIntOrNull()?.coerceIn(1, 28) ?: 1
                    },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    supportingText = { Text("1–28, or type \\"last\\"", fontSize = 10.sp) }
                )
            }

            FieldLabel("Time")
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = hour.toString(),
                    onValueChange = { hour = it.toIntOrNull()?.coerceIn(0, 23) ?: hour },
                    label = { Text("Hour", fontSize = 11.sp) },
                    singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Spacer(Modifier.width(8.dp))
                OutlinedTextField(
                    value = minute.toString(),
                    onValueChange = { minute = it.toIntOrNull()?.coerceIn(0, 59) ?: minute },
                    label = { Text("Minute", fontSize = 11.sp) },
                    singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }
            Text("Android may fire this a few minutes late to save battery.",
                fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant)

            FieldLabel("When tapped")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ReminderEntity.ACTIONS) { (key, lab) ->
                    FilterChip(action == key, { action = key }, { Text(lab, fontSize = 12.sp) })
                }
            }

            error?.let {
                Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 12.dp))
            }

            Spacer(Modifier.height(20.dp))
            Row {
                if (!isNew) {
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                cancelReminder(ctx, r.id); dao.delete(r); onDismiss()
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Delete") }
                    Spacer(Modifier.width(8.dp))
                }
                Button(
                    onClick = {
                        if (title.isBlank()) { error = "Give it a title."; return@Button }
                        if ((frequency == "WEEKLY" || frequency == "BIWEEKLY") && days.isEmpty()) {
                            error = "Pick at least one day."; return@Button
                        }
                        scope.launch {
                            val row = r.copy(
                                title = title.trim(),
                                message = message.trim().ifBlank { title.trim() },
                                frequency = frequency, hour = hour, minute = minute,
                                daysOfWeek = days.sorted().joinToString(","),
                                dayOfMonth = dayOfMonth, action = action
                            )
                            val id = if (isNew) dao.insert(row) else { dao.update(row); row.id }
                            dao.reminder(id)?.let { if (it.enabled) scheduleReminder(ctx, it) }
                            onDismiss()
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Save") }
            }
        }
    }
}
