package com.securemoney.manager.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.securemoney.manager.Settings
import com.securemoney.manager.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private val dayFmt = SimpleDateFormat("EEE d MMM", Locale.US)
private val fullFmt = SimpleDateFormat("d MMM yyyy", Locale.US)

/* ══════════════════════════════════════════════════════════════════
 *  RECORDS
 * ══════════════════════════════════════════════════════════════════ */
@Composable
fun RecordsScreen(dao: SmmDao, settings: Settings, onEdit: (TransactionEntity) -> Unit) {
    var query by remember { mutableStateOf("") }
    var period by remember { mutableStateOf(Period.THIS_MONTH) }
    val (from, to) = remember(period) { period.bounds() }

    val all by dao.observeConfirmed().collectAsStateWithLifecycle(emptyList())
    val found by remember(query) { dao.search(query) }.collectAsStateWithLifecycle(emptyList())
    val accounts by dao.observeAccounts().collectAsStateWithLifecycle(emptyList())
    val cats by dao.observeCategories().collectAsStateWithLifecycle(emptyList())
    val groups by dao.observeGroups().collectAsStateWithLifecycle(emptyList())
    val tags by dao.observeTags().collectAsStateWithLifecycle(emptyList())

    val accById = accounts.associateBy { it.id }
    val catById = cats.associateBy { it.id }

    // Active group filter — always visible, never hidden state.
    val activeGroup = groups.firstOrNull { it.id == settings.activeGroupId }
    val groupAccountIds = activeGroup?.let { g ->
        accounts.filter { it.groupId == g.id }.map { it.id }.toSet()
    }

    val base = (if (query.isBlank()) all else found)
        .filter { it.occurredAt in from..to }
        .filter { groupAccountIds == null || it.accountId in groupAccountIds }

    // Totals per currency — three separate bags, never combined.
    val inflowBag = base.filter { it.countsAsIncome }
        .toMoneyBag({ it.currency }, { it.amountMinor })
    val outflowBag = base.filter { it.countsAsSpend }
        .toMoneyBag({ it.currency }, { it.amountMinor })
    val lentBag = base.filter { it.personEntryType in PersonEntryType.OPEN_CLAIM }
        .toMoneyBag({ it.currency }, { it.amountMinor })

    val byDay = base.groupBy {
        Calendar.getInstance().apply {
            timeInMillis = it.occurredAt
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }.toSortedMap(reverseOrder())

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            ScreenTitle(
                "Records",
                activeGroup?.let { "Filtered to ${it.name}" } ?: "All groups"
            )
        }

        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                placeholder = { Text("Search merchant, note or tag", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) IconButton({ query = "" }) {
                        Icon(Icons.Default.Close, "Clear")
                    }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(20.dp, 0.dp)
            )
        }

        if (tags.isNotEmpty() && settings.showTags) {
            item {
                LazyRow(
                    Modifier.padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    contentPadding = PaddingValues(horizontal = 20.dp)
                ) {
                    items(tags, key = { it.id }) { t ->
                        FilterChip(
                            selected = query == t.name,
                            onClick = { query = if (query == t.name) "" else t.name },
                            label = { Text("#${t.name}", fontSize = 11.sp) }
                        )
                    }
                }
            }
        }

        item { Spacer(Modifier.height(10.dp)); PeriodChips(period) { period = it } }

        item {
            Card(Modifier.fillMaxWidth().padding(20.dp, 12.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text(period.label.uppercase(), fontSize = 9.sp, letterSpacing = 1.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text("IN", fontSize = 9.sp, letterSpacing = 1.sp, color = inflow())
                            Spacer(Modifier.height(3.dp))
                            inflowBag.entries().ifEmpty { listOf("" to 0L) }.forEach { (c, v) ->
                                Text(if (c.isEmpty()) "—" else v.format(c),
                                    fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                                    color = inflow())
                            }
                        }
                        Column(Modifier.weight(1f)) {
                            Text("OUT", fontSize = 9.sp, letterSpacing = 1.sp, color = outflow())
                            Spacer(Modifier.height(3.dp))
                            outflowBag.entries().ifEmpty { listOf("" to 0L) }.forEach { (c, v) ->
                                Text(if (c.isEmpty()) "—" else v.format(c),
                                    fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                                    color = outflow())
                            }
                        }
                        Column(Modifier.weight(1f)) {
                            Text("LENT", fontSize = 9.sp, letterSpacing = 1.sp,
                                color = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(3.dp))
                            lentBag.entries().ifEmpty { listOf("" to 0L) }.forEach { (c, v) ->
                                Text(if (c.isEmpty()) "—" else v.format(c),
                                    fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Transfers between your own accounts are excluded. Money you've lent stays out of OUT until you absorb it.",
                        fontSize = 10.sp, lineHeight = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (base.isEmpty()) {
            item {
                EmptyState(
                    if (query.isBlank()) "Nothing recorded for ${period.label.lowercase()} yet."
                    else "Nothing matches \"$query\"."
                )
            }
        }

        byDay.forEach { (day, rows) ->
            item {
                val dayBag = rows.toMoneyBag({ it.currency }, { it.signedMinor })
                Row(
                    Modifier.fillMaxWidth().padding(20.dp, 14.dp, 20.dp, 6.dp),
                    Arrangement.SpaceBetween, Alignment.Bottom
                ) {
                    Text(dayFmt.format(Date(day)).uppercase(), fontSize = 10.sp,
                        letterSpacing = 1.sp, color = MaterialTheme.colorScheme.primary)
                    Text(dayBag.display(separator = " · "), fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                HorizontalDivider(
                    Modifier.padding(horizontal = 20.dp),
                    color = MaterialTheme.colorScheme.outlineVariant
                )
            }
            items(rows, key = { it.id }) { tx ->
                TransactionRow(tx, catById[tx.categoryId], accById[tx.accountId]) { onEdit(tx) }
            }
        }

        item { Spacer(Modifier.height(90.dp)) }
    }
}

@Composable
fun TransactionRow(
    tx: TransactionEntity,
    cat: CategoryEntity?,
    account: AccountEntity?,
    onClick: () -> Unit
) {
    val isTransfer = tx.kind in TxKind.TRANSFERS
    ListItem(
        modifier = Modifier.clickable(onClick = onClick),
        leadingContent = {
            when {
                isTransfer -> IconBadge("\u21C4", "#8A93A6")
                tx.kind == TxKind.ADJUSTMENT -> IconBadge("\u2699", "#8A93A6")
                else -> IconBadge(cat?.icon ?: "\u2754", cat?.colorHex ?: "#8A93A6")
            }
        },
        headlineContent = { Text(tx.merchant, fontSize = 14.sp, maxLines = 1) },
        supportingContent = {
            Column {
                Text(
                    listOfNotNull(
                        account?.name,
                        if (isTransfer) "Transfer" else cat?.name,
                        tx.personEntryType?.let { PersonEntryType.label(it) },
                        tx.photoUri?.let { "\uD83D\uDCF7" }
                    ).joinToString(" · "),
                    fontSize = 11.sp
                )
                // Cross-currency rows show both sides and the rate used.
                if (tx.fxCounterMinor != null && tx.fxCounterCurrency != null) {
                    Text(
                        "↔ ${tx.fxCounterMinor.format(tx.fxCounterCurrency)}" +
                            (tx.fxRateUsed?.let { " @ ${"%.4f".format(it)}" } ?: ""),
                        fontSize = 10.sp, fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        },
        trailingContent = {
            Text(
                tx.amountMinor.formatSigned(tx.currency, TxKind.reducesAccount(tx.kind)),
                fontSize = 14.sp, fontFamily = FontFamily.Monospace,
                color = when {
                    isTransfer -> MaterialTheme.colorScheme.onSurfaceVariant
                    TxKind.reducesAccount(tx.kind) -> outflow()
                    else -> inflow()
                }
            )
        }
    )
}

/* ══════════════════════════════════════════════════════════════════
 *  REVIEW QUEUE — swipe-free, two taps per entry
 * ══════════════════════════════════════════════════════════════════ */
@Composable
fun ReviewScreen(dao: SmmDao, onEdit: (TransactionEntity) -> Unit) {
    val scope = rememberCoroutineScope()
    val pending by dao.observePending().collectAsStateWithLifecycle(emptyList())
    val accounts by dao.observeAccounts().collectAsStateWithLifecycle(emptyList())
    val cats by dao.observeCategories().collectAsStateWithLifecycle(emptyList())
    val accById = accounts.associateBy { it.id }

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            ScreenTitle(
                "Review",
                if (pending.isEmpty()) "Nothing waiting"
                else "${pending.size} ${if (pending.size == 1) "entry" else "entries"} to confirm"
            )
        }

        if (pending.isEmpty()) {
            item {
                EmptyState(
                    "Parsed entries land here first, so nothing reaches your ledger without your say-so.\n\nIf you haven't enabled SMS or notification reading, this will always be empty — which is fine."
                )
            }
        }

        items(pending, key = { it.id }) { tx ->
            val acc = accById[tx.accountId]
            Card(Modifier.fillMaxWidth().padding(20.dp, 6.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text(tx.merchant, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                            Text("${tx.source} · ${fullFmt.format(Date(tx.occurredAt))}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(
                            tx.amountMinor.formatSigned(tx.currency, TxKind.reducesAccount(tx.kind)),
                            fontSize = 17.sp, fontFamily = FontFamily.Monospace,
                            color = if (TxKind.reducesAccount(tx.kind)) outflow() else inflow()
                        )
                    }

                    Spacer(Modifier.height(12.dp))
                    Text("ACCOUNT", fontSize = 9.sp, letterSpacing = 1.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(4.dp))
                    // Only accounts in the matching currency — offering a QAR
                    // account for an INR message would create a wrong record.
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(accounts.filter { it.currency == tx.currency }, key = { it.id }) { a ->
                            FilterChip(
                                selected = tx.accountId == a.id,
                                onClick = {
                                    scope.launch {
                                        dao.update(tx.copy(accountId = a.id))
                                        // Learn it, so the queue shrinks over time.
                                        dao.learn(LearnedRuleEntity.MERCHANT_ACCOUNT,
                                            tx.merchant, a.id)
                                    }
                                },
                                label = { Text(a.name, fontSize = 11.sp) }
                            )
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Text("CATEGORY", fontSize = 9.sp, letterSpacing = 1.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(4.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(
                            cats.filter { it.isExpense == (tx.kind == TxKind.EXPENSE) },
                            key = { it.id }
                        ) { c ->
                            FilterChip(
                                selected = tx.categoryId == c.id,
                                onClick = {
                                    scope.launch {
                                        dao.update(tx.copy(categoryId = c.id))
                                        dao.learn(LearnedRuleEntity.MERCHANT_CATEGORY,
                                            tx.merchant, c.id)
                                    }
                                },
                                label = { Text("${c.icon} ${c.name}", fontSize = 11.sp) }
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    Row {
                        OutlinedButton(
                            onClick = { scope.launch { dao.delete(tx) } },
                            modifier = Modifier.weight(1f)
                        ) { Text("Discard", fontSize = 13.sp) }
                        Spacer(Modifier.width(8.dp))
                        OutlinedButton(
                            onClick = { onEdit(tx) },
                            modifier = Modifier.weight(1f)
                        ) { Text("Edit", fontSize = 13.sp) }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = { scope.launch { dao.update(tx.copy(confirmed = true)) } },
                            modifier = Modifier.weight(1.2f)
                        ) { Text("Confirm", fontSize = 13.sp) }
                    }
                }
            }
        }

        if (pending.size > 1) {
            item {
                OutlinedButton(
                    onClick = {
                        scope.launch { pending.forEach { dao.update(it.copy(confirmed = true)) } }
                    },
                    modifier = Modifier.fillMaxWidth().padding(20.dp, 12.dp)
                ) { Text("Confirm all ${pending.size}") }
            }
        }
        item { Spacer(Modifier.height(40.dp)) }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  ACCOUNTS — grouped, per-currency subtotals
 * ══════════════════════════════════════════════════════════════════ */
@Composable
fun AccountsScreen(
    dao: SmmDao,
    onEditAccount: (AccountEntity) -> Unit,
    onEditGroup: (GroupEntity?) -> Unit,
    onAddAccount: (Long) -> Unit,
    onTransfer: () -> Unit
) {
    val groups by dao.observeGroups().collectAsStateWithLifecycle(emptyList())
    val accounts by dao.observeAccounts().collectAsStateWithLifecycle(emptyList())
    val balances by dao.observeBalances().collectAsStateWithLifecycle(emptyList())
    val balById = balances.associateBy { it.accountId }

    // Grand total: one figure per currency, never one combined number.
    val grand = balances.toMoneyBag({ it.currency }, { it.balanceMinor })

    LazyColumn(Modifier.fillMaxSize()) {
        item { ScreenTitle("Accounts", "What you hold, kept separate by currency") }

        item {
            Card(Modifier.fillMaxWidth().padding(20.dp, 4.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("TOTAL HELD", fontSize = 9.sp, letterSpacing = 1.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    grand.entries().ifEmpty { listOf("" to 0L) }.forEach { (c, v) ->
                        if (c.isEmpty()) {
                            Text("—", fontSize = 20.sp, fontFamily = FontFamily.Monospace)
                        } else {
                            Text(v.format(c), fontSize = 20.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Medium,
                                color = if (v < 0) outflow() else MaterialTheme.colorScheme.onSurface)
                        }
                    }
                    if (grand.currencies.size > 1) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Shown separately on purpose. Combining them would need an exchange rate, and any figure produced that way is out of date the moment it's written.",
                            fontSize = 10.sp, lineHeight = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth().padding(20.dp, 12.dp)) {
                OutlinedButton(onTransfer, Modifier.weight(1f)) {
                    Icon(Icons.Default.SwapHoriz, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Transfer", fontSize = 13.sp)
                }
                Spacer(Modifier.width(8.dp))
                OutlinedButton({ onEditGroup(null) }, Modifier.weight(1f)) {
                    Icon(Icons.Default.Add, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("New group", fontSize = 13.sp)
                }
            }
        }

        if (groups.isEmpty()) {
            item {
                EmptyState("No groups yet.", "Create your first group") { onEditGroup(null) }
            }
        }

        groups.forEach { g ->
            val inGroup = accounts.filter { it.groupId == g.id }
            val groupBag = inGroup.toMoneyBag(
                { it.currency },
                { balById[it.id]?.balanceMinor ?: it.openingBalanceMinor }
            )

            item {
                Row(
                    Modifier.fillMaxWidth().padding(20.dp, 18.dp, 20.dp, 6.dp)
                        .clickable { onEditGroup(g) },
                    Arrangement.SpaceBetween, Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(g.icon, fontSize = 18.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(g.name, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        groupBag.entries().forEach { (c, v) ->
                            Text(v.format(c), fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (v < 0) outflow()
                                        else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                HorizontalDivider(
                    Modifier.padding(horizontal = 20.dp),
                    color = MaterialTheme.colorScheme.outlineVariant
                )
            }

            if (inGroup.isEmpty()) {
                item {
                    Text(
                        "No accounts here yet.",
                        Modifier.padding(20.dp, 10.dp),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Sub-grouped by currency inside the group, so QAR and INR
            // accounts never appear in one running list.
            inGroup.groupBy { it.currency }.forEach { (cur, list) ->
                if (inGroup.map { it.currency }.toSet().size > 1) {
                    item {
                        Text(
                            cur, Modifier.padding(24.dp, 10.dp, 20.dp, 2.dp),
                            fontSize = 9.sp, letterSpacing = 1.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                items(list, key = { it.id }) { a ->
                    val bal = balById[a.id]?.balanceMinor ?: a.openingBalanceMinor
                    ListItem(
                        modifier = Modifier.clickable { onEditAccount(a) },
                        leadingContent = { IconBadge(a.icon, a.colorHex, 40) },
                        headlineContent = { Text(a.name, fontSize = 14.sp) },
                        supportingContent = {
                            Text(
                                listOfNotNull(
                                    a.type.lowercase().replaceFirstChar { it.uppercase() },
                                    a.currency,
                                    a.accountDigits.takeIf { it.isNotBlank() }?.let { "••$it" }
                                ).joinToString(" · "),
                                fontSize = 11.sp
                            )
                        },
                        trailingContent = {
                            Text(bal.format(a.currency), fontSize = 15.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (bal < 0) outflow() else MaterialTheme.colorScheme.onSurface)
                        }
                    )
                }
            }

            item {
                TextButton(
                    onClick = { onAddAccount(g.id) },
                    modifier = Modifier.padding(16.dp, 0.dp)
                ) { Text("+ Add account to ${g.name}", fontSize = 12.sp) }
            }
        }

        item { Spacer(Modifier.height(60.dp)) }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  PEOPLE
 * ══════════════════════════════════════════════════════════════════ */
@Composable
fun PeopleScreen(dao: SmmDao, onOpen: (PersonEntity) -> Unit, onAdd: () -> Unit) {
    val people by dao.observePeople().collectAsStateWithLifecycle(emptyList())
    val nets by dao.observePersonNets().collectAsStateWithLifecycle(emptyList())

    val owedToYou = nets.filter { it.netMinor > 0 }
        .toMoneyBag({ it.currency }, { it.netMinor })
    val youOwe = nets.filter { it.netMinor < 0 }
        .toMoneyBag({ it.currency }, { -it.netMinor })

    LazyColumn(Modifier.fillMaxSize()) {
        item { ScreenTitle("People", "Money you've moved for someone else") }

        item {
            Row(Modifier.fillMaxWidth().padding(20.dp, 4.dp)) {
                Card(Modifier.weight(1f)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("OWED TO YOU", fontSize = 9.sp, letterSpacing = 1.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(4.dp))
                        owedToYou.entries().ifEmpty { listOf("" to 0L) }.forEach { (c, v) ->
                            Text(if (c.isEmpty()) "—" else v.format(c),
                                fontSize = 13.sp, fontFamily = FontFamily.Monospace,
                                color = inflow())
                        }
                    }
                }
                Spacer(Modifier.width(8.dp))
                Card(Modifier.weight(1f)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("YOU OWE", fontSize = 9.sp, letterSpacing = 1.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(4.dp))
                        youOwe.entries().ifEmpty { listOf("" to 0L) }.forEach { (c, v) ->
                            Text(if (c.isEmpty()) "—" else v.format(c),
                                fontSize = 13.sp, fontFamily = FontFamily.Monospace,
                                color = outflow())
                        }
                    }
                }
            }
        }

        if (people.isEmpty()) {
            item {
                EmptyState(
                    "Add someone you lend to, borrow from, or send money for.\n\nThe app tracks each currency separately, and knows the difference between money you expect back and money that's become your own cost.",
                    "Add a person", onAdd
                )
            }
        }

        items(people, key = { it.id }) { p ->
            val personNets = nets.filter { it.personId == p.id && it.netMinor != 0L }
            ListItem(
                modifier = Modifier.clickable { onOpen(p) },
                leadingContent = {
                    Box(
                        Modifier.size(40.dp).clip(RoundedCornerShape(20.dp))
                            .background(p.colorHex.toColorOr().copy(alpha = 0.2f)),
                        Alignment.Center
                    ) {
                        Text(p.name.take(2).uppercase(), fontSize = 12.sp,
                            color = p.colorHex.toColorOr())
                    }
                },
                headlineContent = { Text(p.name, fontSize = 14.sp) },
                supportingContent = {
                    Text(
                        listOfNotNull(
                            p.relationship.takeIf { it.isNotBlank() },
                            if (p.allowanceMinor > 0)
                                "${p.allowanceMinor.format(p.allowanceCurrency)}/month" else null,
                            if (p.autoMatchSms) "SMS matching on" else null
                        ).joinToString(" · ").ifBlank { "No activity yet" },
                        fontSize = 11.sp
                    )
                },
                trailingContent = {
                    Column(horizontalAlignment = Alignment.End) {
                        if (personNets.isEmpty()) {
                            Text("Settled", fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            personNets.forEach { n ->
                                Text(
                                    n.netMinor.format(n.currency),
                                    fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                                    color = if (n.netMinor > 0) inflow() else outflow()
                                )
                            }
                        }
                    }
                }
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        }

        if (people.isNotEmpty()) {
            item {
                OutlinedButton(onAdd, Modifier.fillMaxWidth().padding(20.dp, 14.dp)) {
                    Text("Add person")
                }
            }
        }
        item { Spacer(Modifier.height(40.dp)) }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  BUDGETS — per category per currency
 * ══════════════════════════════════════════════════════════════════ */
@Composable
fun BudgetsScreen(dao: SmmDao, onDrill: (CategoryEntity) -> Unit) {
    var period by remember { mutableStateOf(Period.THIS_MONTH) }
    val (from, to) = remember(period) { period.bounds() }

    val cats by dao.observeCategories().collectAsStateWithLifecycle(emptyList())
    val budgets by dao.observeBudgets().collectAsStateWithLifecycle(emptyList())
    val spend by remember(period) { dao.observeCategorySpend(from, to) }
        .collectAsStateWithLifecycle(emptyList())

    val catById = cats.associateBy { it.id }
    // Key on (category, currency) — a QAR cap and an INR cap coexist.
    val spendMap = spend.associate { (it.categoryId to it.currency) to it.spentMinor }

    val capped = budgets.filter { it.monthlyLimitMinor > 0 }
        .sortedBy { catById[it.categoryId]?.sortOrder ?: 99 }
    val cappedKeys = capped.map { it.categoryId to it.currency }.toSet()
    val uncapped = spend.filter { (it.categoryId to it.currency) !in cappedKeys && it.spentMinor > 0 }

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            ScreenTitle("Budgets", "Caps are set per currency, so nothing gets mixed")
        }
        item { PeriodChips(period) { period = it } }

        if (capped.isEmpty() && uncapped.isEmpty()) {
            item {
                EmptyState("No spending yet for ${period.label.lowercase()}.\n\nSet a cap from the Categories screen — you can give one category a separate limit in each currency.")
            }
        }

        if (capped.isNotEmpty()) item { SectionLabel("With a cap") }
        items(capped, key = { it.id }) { b ->
            val c = catById[b.categoryId] ?: return@items
            val spent = spendMap[b.categoryId to b.currency] ?: 0L
            val pct = (spent.toFloat() / b.monthlyLimitMinor).coerceIn(0f, 1f)
            val over = spent > b.monthlyLimitMinor

            Card(
                Modifier.fillMaxWidth().padding(20.dp, 5.dp).clickable { onDrill(c) }
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconBadge(c.icon, c.colorHex, 32)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(c.name, fontSize = 14.sp)
                                Text(b.currency, fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(spent.format(b.currency, withCode = false),
                                fontSize = 14.sp, fontFamily = FontFamily.Monospace,
                                color = if (over) outflow() else MaterialTheme.colorScheme.onSurface)
                            Text("of ${b.monthlyLimitMinor.format(b.currency, withCode = false)}",
                                fontSize = 10.sp, fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { pct },
                        modifier = Modifier.fillMaxWidth().height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = if (over) outflow() else c.colorHex.toColorOr(),
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                    if (over) {
                        Text(
                            "Over by ${(spent - b.monthlyLimitMinor).format(b.currency)}",
                            fontSize = 10.sp, color = outflow(),
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }
        }

        if (uncapped.isNotEmpty()) {
            item { SectionLabel("Spending with no cap") }
            items(uncapped) { row ->
                val c = row.categoryId?.let { catById[it] }
                ListItem(
                    modifier = Modifier.clickable { c?.let(onDrill) },
                    leadingContent = { IconBadge(c?.icon ?: "\u2754", c?.colorHex ?: "#8A93A6", 32) },
                    headlineContent = { Text(c?.name ?: "Uncategorised", fontSize = 14.sp) },
                    supportingContent = { Text(row.currency, fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace) },
                    trailingContent = {
                        Text(row.spentMinor.format(row.currency), fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace, color = outflow())
                    }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }

        item {
            InfoCard("Absorbed costs count here. Money still owed to you doesn't — and neither do transfers between your own accounts.")
        }
        item { Spacer(Modifier.height(40.dp)) }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  CATEGORIES / TAGS
 * ══════════════════════════════════════════════════════════════════ */
@Composable
fun CategoriesScreen(dao: SmmDao, onEdit: (CategoryEntity?) -> Unit) {
    val cats by dao.observeCategories().collectAsStateWithLifecycle(emptyList())
    val budgets by dao.observeBudgets().collectAsStateWithLifecycle(emptyList())
    val byCategory = budgets.groupBy { it.categoryId }

    LazyColumn(Modifier.fillMaxSize()) {
        item { ScreenTitle("Categories", "Tap to change the icon, colour or per-currency caps") }

        listOf(true to "Expense", false to "Income").forEach { (isExpense, label) ->
            val list = cats.filter { it.isExpense == isExpense }
            if (list.isNotEmpty()) item { SectionLabel(label) }
            items(list, key = { it.id }) { c ->
                val caps = byCategory[c.id]?.filter { it.monthlyLimitMinor > 0 } ?: emptyList()
                ListItem(
                    modifier = Modifier.clickable { onEdit(c) },
                    leadingContent = { IconBadge(c.icon, c.colorHex, 40) },
                    headlineContent = { Text(c.name, fontSize = 14.sp) },
                    supportingContent = {
                        Text(
                            if (caps.isEmpty()) "No cap"
                            else caps.joinToString(" · ") {
                                it.monthlyLimitMinor.format(it.currency)
                            },
                            fontSize = 11.sp, fontFamily = FontFamily.Monospace
                        )
                    },
                    trailingContent = { Icon(Icons.Default.ChevronRight, null) }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }

        item {
            OutlinedButton({ onEdit(null) }, Modifier.fillMaxWidth().padding(20.dp, 14.dp)) {
                Text("New category")
            }
        }
        item { Spacer(Modifier.height(40.dp)) }
    }
}

@Composable
fun TagsScreen(dao: SmmDao) {
    val tags by dao.observeTags().collectAsStateWithLifecycle(emptyList())
    val txs by dao.observeConfirmed().collectAsStateWithLifecycle(emptyList())
    var links by remember { mutableStateOf<Map<Long, List<Long>>>(emptyMap()) }

    LaunchedEffect(tags, txs) {
        links = dao.allTagLinksOnce().groupBy({ it.tagId }, { it.transactionId })
    }
    val txById = txs.associateBy { it.id }

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            ScreenTitle("Tags", "Labels that cut across categories — totals stay per currency")
        }
        if (tags.isEmpty()) {
            item {
                EmptyState("No tags yet.\n\nAdd one while creating an entry. A tag like \"reimbursable\" or \"dog\" can span any number of categories.")
            }
        }
        items(tags, key = { it.id }) { t ->
            val rows = (links[t.id] ?: emptyList()).mapNotNull { txById[it] }
            val bag = rows.filter { it.countsAsSpend }
                .toMoneyBag({ it.currency }, { it.amountMinor })
            ListItem(
                headlineContent = { Text("#${t.name}", fontSize = 14.sp) },
                supportingContent = {
                    Text("${rows.size} ${if (rows.size == 1) "entry" else "entries"}", fontSize = 11.sp)
                },
                trailingContent = {
                    Column(horizontalAlignment = Alignment.End) {
                        bag.entries().ifEmpty { listOf("" to 0L) }.forEach { (c, v) ->
                            Text(if (c.isEmpty()) "—" else v.format(c),
                                fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                                color = outflow())
                        }
                    }
                }
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        }
        item { Spacer(Modifier.height(40.dp)) }
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  CALENDAR
 * ══════════════════════════════════════════════════════════════════ */
@Composable
fun CalendarScreen(dao: SmmDao, onEdit: (TransactionEntity) -> Unit) {
    var monthOffset by remember { mutableIntStateOf(0) }
    val cal = remember(monthOffset) {
        Calendar.getInstance().apply { add(Calendar.MONTH, monthOffset) }
    }
    val (from, to) = remember(monthOffset) {
        val s = (cal.clone() as Calendar).apply {
            set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        s.timeInMillis to (s.clone() as Calendar).apply { add(Calendar.MONTH, 1) }.timeInMillis - 1
    }

    val txs by remember(from) { dao.observeBetween(from, to) }.collectAsStateWithLifecycle(emptyList())
    val cats by dao.observeCategories().collectAsStateWithLifecycle(emptyList())
    val accounts by dao.observeAccounts().collectAsStateWithLifecycle(emptyList())
    val catById = cats.associateBy { it.id }
    val accById = accounts.associateBy { it.id }

    var selectedDay by remember { mutableIntStateOf(Calendar.getInstance().get(Calendar.DAY_OF_MONTH)) }

    val byDay = txs.groupBy {
        Calendar.getInstance().apply { timeInMillis = it.occurredAt }.get(Calendar.DAY_OF_MONTH)
    }
    val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val firstDow = (cal.clone() as Calendar)
        .apply { set(Calendar.DAY_OF_MONTH, 1) }.get(Calendar.DAY_OF_WEEK) - 1

    val monthIn = txs.filter { it.countsAsIncome }.toMoneyBag({ it.currency }, { it.amountMinor })
    val monthOut = txs.filter { it.countsAsSpend }.toMoneyBag({ it.currency }, { it.amountMinor })

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            ScreenTitle(
                SimpleDateFormat("MMMM yyyy", Locale.US).format(cal.time),
                "Tap a day to see its entries"
            ) {
                Row {
                    IconButton({ monthOffset-- }) { Icon(Icons.Default.ChevronLeft, "Previous") }
                    IconButton({ monthOffset++ }) { Icon(Icons.Default.ChevronRight, "Next") }
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth().padding(20.dp, 4.dp)) {
                Card(Modifier.weight(1f)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("IN", fontSize = 9.sp, letterSpacing = 1.sp, color = inflow())
                        monthIn.entries().ifEmpty { listOf("" to 0L) }.forEach { (c, v) ->
                            Text(if (c.isEmpty()) "—" else v.format(c), fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace, color = inflow())
                        }
                    }
                }
                Spacer(Modifier.width(8.dp))
                Card(Modifier.weight(1f)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("OUT", fontSize = 9.sp, letterSpacing = 1.sp, color = outflow())
                        monthOut.entries().ifEmpty { listOf("" to 0L) }.forEach { (c, v) ->
                            Text(if (c.isEmpty()) "—" else v.format(c), fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace, color = outflow())
                        }
                    }
                }
            }
        }

        item {
            Column(Modifier.padding(16.dp, 12.dp)) {
                Row(Modifier.fillMaxWidth()) {
                    listOf("S", "M", "T", "W", "T", "F", "S").forEach {
                        Text(it, Modifier.weight(1f), fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
                Spacer(Modifier.height(6.dp))

                // Build a fixed 6x7 grid: no shared counter, so no edge case
                // where a month starting on Saturday breaks the layout.
                val cells = List(firstDow) { null } + (1..daysInMonth).toList()
                cells.chunked(7).forEach { week ->
                    Row(Modifier.fillMaxWidth()) {
                        (0..6).forEach { i ->
                            val day = week.getOrNull(i)
                            if (day == null) {
                                Spacer(Modifier.weight(1f).aspectRatio(1f))
                            } else {
                                val rows = byDay[day] ?: emptyList()
                                val net = rows.sumOf { it.signedMinor }
                                val selected = selectedDay == day
                                Box(
                                    Modifier.weight(1f).aspectRatio(1f).padding(2.dp)
                                        .clip(RoundedCornerShape(9.dp))
                                        .background(
                                            when {
                                                selected -> MaterialTheme.colorScheme.primary
                                                rows.isNotEmpty() -> MaterialTheme.colorScheme.surfaceVariant
                                                else -> androidx.compose.ui.graphics.Color.Transparent
                                            }
                                        )
                                        .clickable { selectedDay = day },
                                    Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("$day", fontSize = 11.sp,
                                            color = if (selected) MaterialTheme.colorScheme.onPrimary
                                                    else MaterialTheme.colorScheme.onSurface)
                                        if (rows.isNotEmpty()) {
                                            Box(
                                                Modifier.size(4.dp).clip(RoundedCornerShape(2.dp))
                                                    .background(
                                                        if (selected) MaterialTheme.colorScheme.onPrimary
                                                        else if (net < 0) outflow() else inflow()
                                                    )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item { SectionLabel("Day $selectedDay") }
        val dayRows = byDay[selectedDay] ?: emptyList()
        if (dayRows.isEmpty()) {
            item { EmptyState("Nothing on this day.") }
        }
        items(dayRows, key = { it.id }) { tx ->
            TransactionRow(tx, catById[tx.categoryId], accById[tx.accountId]) { onEdit(tx) }
        }
        item { Spacer(Modifier.height(90.dp)) }
    }
}
