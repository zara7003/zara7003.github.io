package com.securemoney.manager.parse

import com.securemoney.manager.data.*

data class ParseResult(
    val matchedRule: String?,
    val amountMinor: Long?,
    val currency: String,
    val currencyWasDetected: Boolean,
    val merchant: String?,
    val accountDigits: String?,
    val isExpense: Boolean,
    val personId: Long?,
    val personName: String?,
    val confidence: Float
) {
    val isUsable get() = amountMinor != null && amountMinor > 0
}

/**
 * Pure and dependency-free, which is what makes it unit-testable and what
 * powers the parser sandbox in developer settings.
 */
object TransactionParser {

    /** Symbols and informal codes mapped to ISO codes. Longest match wins. */
    private val CURRENCY_HINTS: List<Pair<String, String>> = listOf(
        "QAR" to "QAR", "Q.R" to "QAR", "QR." to "QAR", " QR" to "QAR",
        "INR" to "INR", "RS." to "INR", " RS" to "INR", "₹" to "INR",
        "AED" to "AED", "DHS" to "AED", "DH." to "AED",
        "SAR" to "SAR", "KWD" to "KWD", "BHD" to "BHD", "OMR" to "OMR",
        "USD" to "USD", "US$" to "USD",
        "EUR" to "EUR", "€" to "EUR",
        "GBP" to "GBP", "£" to "GBP",
        "PKR" to "PKR", "BDT" to "BDT", "৳" to "BDT",
        "LKR" to "LKR", "PHP" to "PHP", "₱" to "PHP",
        "EGP" to "EGP", "TRY" to "TRY", "₺" to "TRY",
        "CAD" to "CAD", "AUD" to "AUD", "CHF" to "CHF",
        "SGD" to "SGD", "MYR" to "MYR", "THB" to "THB", "฿" to "THB",
        "JPY" to "JPY", "CNY" to "CNY", "ZAR" to "ZAR",
        "NPR" to "NPR", "KES" to "KES", "NGN" to "NGN"
    ).sortedByDescending { it.first.length }

    private val CREDIT_WORDS = listOf(
        "credited", "credit of", "received", "deposit", "refund",
        "salary", "cashback", "reversed", "added to"
    )
    private val DEBIT_WORDS = listOf(
        "debited", "debit of", "spent", "purchase", "withdrawn",
        "paid", "charged", "txn", "transaction of", "deducted"
    )

    fun parse(
        body: String,
        sender: String,
        rules: List<SmsRuleEntity>,
        people: List<PersonEntity>,
        fallbackCurrency: String = "USD"
    ): ParseResult {
        val lower = body.lowercase()
        val upper = body.uppercase()

        // 1. First rule whose sender and keyword gates both pass.
        val rule = rules.firstOrNull { r ->
            val senderOk = runCatching {
                Regex(r.senderPattern, RegexOption.IGNORE_CASE).containsMatchIn(sender)
            }.getOrDefault(true)
            val bodyOk = r.bodyMustContain.isBlank() ||
                r.bodyMustContain.split(",").any { lower.contains(it.trim().lowercase()) }
            senderOk && bodyOk
        }

        // 2. Currency, before the amount — decimals depend on it.
        val detected = CURRENCY_HINTS.firstOrNull { upper.contains(it.first) }?.second
        val currency = detected ?: fallbackCurrency

        // 3. Amount.
        val amountRegex = rule?.amountRegex
            ?: """(?:[A-Z]{3}|Rs\.?|₹|\$|€|£)\s*([\d,]+(?:\.\d{1,3})?)"""
        val match = runCatching {
            Regex(amountRegex, RegexOption.IGNORE_CASE).find(body)
        }.getOrNull()
        val amountMinor = match?.groupValues?.drop(1)
            ?.firstOrNull { it.isNotBlank() }
            ?.toMinor(currency)

        // 4. Direction — keyword vote overrides the rule default.
        val credits = CREDIT_WORDS.count { lower.contains(it) }
        val debits = DEBIT_WORDS.count { lower.contains(it) }
        val isExpense = when {
            debits > credits -> true
            credits > debits -> false
            else -> rule?.treatAsExpense ?: true
        }

        // 5. Merchant.
        val merchant = rule?.merchantRegex
            ?.let { runCatching { Regex(it, RegexOption.IGNORE_CASE).find(body) }.getOrNull() }
            ?.groupValues?.getOrNull(1)?.trim()?.trim('.', ',', '-', ';')
            ?.takeIf { it.isNotBlank() && it.length in 2..40 }

        // 6. Account digits.
        val digits = rule?.accountHintRegex
            ?.let { runCatching { Regex(it, RegexOption.IGNORE_CASE).find(body) }.getOrNull() }
            ?.groupValues?.getOrNull(1)

        // 7. Person match — longest alias wins, so "Sam Khan" beats "Sam".
        var person: PersonEntity? = null
        var bestLen = 0
        for (p in people.filter { it.autoMatchSms }) {
            val aliases = (p.smsAliases.split(",") + p.name.split(" ").first())
                .map { it.trim().lowercase() }.filter { it.length >= 3 }
            for (a in aliases) {
                if (lower.contains(a) && a.length > bestLen) { person = p; bestLen = a.length }
            }
        }

        var confidence = 0f
        if (amountMinor != null) confidence += 0.40f
        if (detected != null) confidence += 0.15f
        if (merchant != null) confidence += 0.20f
        if (rule != null) confidence += 0.15f
        if (digits != null) confidence += 0.10f

        return ParseResult(
            matchedRule = rule?.label,
            amountMinor = amountMinor,
            currency = currency,
            currencyWasDetected = detected != null,
            merchant = merchant,
            accountDigits = digits,
            isExpense = isExpense,
            personId = person?.id,
            personName = person?.name,
            confidence = confidence
        )
    }

    /**
     * Generic starter rules. Deliberately not tied to any one country —
     * users add their own bank under Settings without rebuilding the app.
     */
    fun defaultRules(): List<SmsRuleEntity> = listOf(
        SmsRuleEntity(
            label = "Generic bank debit or credit",
            senderPattern = ".*",
            bodyMustContain = "debited,credited,spent,withdrawn,purchase,deposit,paid",
            priority = 10
        ),
        SmsRuleEntity(
            label = "Card transaction",
            senderPattern = ".*",
            bodyMustContain = "card,ending,xx",
            amountRegex = """(?:[A-Z]{3}|Rs\.?|₹|\$|€|£)\s*([\d,]+(?:\.\d{1,3})?)""",
            merchantRegex = """(?:at|to)\s+([A-Za-z0-9&'\-. ]{2,40})""",
            priority = 8
        ),
        SmsRuleEntity(
            label = "Instant transfer / UPI / wallet",
            senderPattern = ".*",
            bodyMustContain = "upi,vpa,transfer,sent to,received from,wallet",
            merchantRegex = """(?:to|from)\s+([A-Za-z0-9&'@\-. ]{2,40})""",
            priority = 8
        ),
        SmsRuleEntity(
            label = "ATM withdrawal",
            senderPattern = ".*",
            bodyMustContain = "atm,withdrawn,cash withdrawal",
            priority = 6
        ),
        SmsRuleEntity(
            label = "Catch-all (lowest priority)",
            senderPattern = ".*",
            bodyMustContain = "",
            priority = 0
        )
    )
}
