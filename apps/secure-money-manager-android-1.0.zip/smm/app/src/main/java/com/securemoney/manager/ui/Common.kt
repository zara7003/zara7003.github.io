package com.securemoney.manager.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.securemoney.manager.data.*
import java.text.SimpleDateFormat
import java.util.*

/* ══════════════════ PERIODS ══════════════════ */
enum class Period(val label: String) {
    THIS_MONTH("This month"),
    LAST_MONTH("Last month"),
    THIS_YEAR("This year"),
    ALL_TIME("All time");

    fun bounds(): Pair<Long, Long> {
        fun monthStart(offset: Int) = Calendar.getInstance().apply {
            add(Calendar.MONTH, offset)
            set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        return when (this) {
            THIS_MONTH -> monthStart(0).timeInMillis to monthStart(1).timeInMillis - 1
            LAST_MONTH -> monthStart(-1).timeInMillis to monthStart(0).timeInMillis - 1
            THIS_YEAR -> {
                val c = monthStart(0).apply { set(Calendar.MONTH, 0) }
                c.timeInMillis to (c.clone() as Calendar).apply {
                    add(Calendar.YEAR, 1)
                }.timeInMillis - 1
            }
            ALL_TIME -> 0L to Long.MAX_VALUE
        }
    }
}

fun currentPeriodKey(): String = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())

@Composable
fun PeriodChips(selected: Period, onSelect: (Period) -> Unit) {
    LazyRow(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(horizontal = 20.dp)
    ) {
        items(Period.entries.toList()) { p ->
            FilterChip(
                selected = selected == p,
                onClick = { onSelect(p) },
                label = { Text(p.label, fontSize = 12.sp) }
            )
        }
    }
}

/* ══════════════════ BUILDING BLOCKS ══════════════════ */
@Composable
fun ScreenTitle(title: String, sub: String? = null, trailing: @Composable (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(20.dp, 14.dp, 20.dp, 10.dp),
        Arrangement.SpaceBetween, Alignment.Top
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 23.sp, fontWeight = FontWeight.SemiBold)
            sub?.let {
                Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        trailing?.invoke()
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(), modifier.padding(20.dp, 18.dp, 20.dp, 6.dp),
        fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Medium,
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
fun FieldLabel(text: String) {
    Text(
        text.uppercase(),
        Modifier.padding(top = 16.dp, bottom = 6.dp),
        fontSize = 10.sp, letterSpacing = 1.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
fun SheetHeader(title: String, sub: String? = null) {
    Column(Modifier.padding(bottom = 8.dp)) {
        Box(Modifier.fillMaxWidth(), Alignment.Center) {
            Box(
                Modifier.width(36.dp).height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(MaterialTheme.colorScheme.outline)
            )
        }
        Spacer(Modifier.height(14.dp))
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        sub?.let {
            Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Category or account badge: emoji on a tinted plate. */
@Composable
fun IconBadge(icon: String, colorHex: String, size: Int = 38) {
    val c = colorHex.toColorOr()
    Box(
        Modifier.size(size.dp)
            .clip(RoundedCornerShape((size / 3.2).dp))
            .background(c.copy(alpha = 0.15f)),
        Alignment.Center
    ) { Text(icon, fontSize = (size * 0.44).sp) }
}

@Composable
fun ColorPicker(selected: String, onSelect: (String) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(COLOR_CHOICES) { c ->
            Box(
                Modifier.size(36.dp).clip(CircleShape).background(c.toColorOr())
                    .clickable { onSelect(c) },
                Alignment.Center
            ) {
                if (selected == c) Icon(Icons.Default.Check, null, Modifier.size(16.dp), tint = Color.White)
            }
        }
    }
}

@Composable
fun EmojiPicker(selected: String, onSelect: (String) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items(EMOJI_CHOICES) { e ->
            Box(
                Modifier.size(40.dp).clip(RoundedCornerShape(10.dp))
                    .background(
                        if (selected == e) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                    .clickable { onSelect(e) },
                Alignment.Center
            ) { Text(e, fontSize = 18.sp) }
        }
    }
}

/**
 * The multi-currency headline. Shows every currency separately —
 * deliberately never one combined number, because that number would
 * require a rate and would be stale the moment it was written.
 */
@Composable
fun CurrencyStrip(bag: MoneyBag, label: String? = null, emphasise: Boolean = false) {
    val entries = bag.entries()
    Column {
        label?.let {
            Text(
                it.uppercase(), fontSize = 9.sp, letterSpacing = 1.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(4.dp))
        }
        if (entries.isEmpty()) {
            Text("—", fontSize = if (emphasise) 22.sp else 15.sp,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            entries.forEach { (cur, minor) ->
                Text(
                    minor.format(cur),
                    fontSize = if (emphasise) 22.sp else 15.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (emphasise) FontWeight.Medium else FontWeight.Normal,
                    color = if (minor < 0) outflow() else MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

/** Compact inline version for list rows: "QAR 4,230 · INR 142,500" */
@Composable
fun CurrencyInline(bag: MoneyBag, fontSize: Int = 13) {
    Text(
        bag.display(),
        fontSize = fontSize.sp, fontFamily = FontFamily.Monospace,
        color = MaterialTheme.colorScheme.onSurface
    )
}

@Composable
fun TagChip(name: String) {
    Surface(shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Text(
            "#$name", Modifier.padding(6.dp, 2.dp), fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun InfoCard(text: String, tone: String = "neutral") {
    Card(
        Modifier.fillMaxWidth().padding(20.dp, 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = when (tone) {
                "warn" -> MaterialTheme.colorScheme.errorContainer
                "good" -> MaterialTheme.colorScheme.primaryContainer
                else -> MaterialTheme.colorScheme.surfaceVariant
            }
        )
    ) { Text(text, Modifier.padding(14.dp), fontSize = 11.sp, lineHeight = 16.sp) }
}

@Composable
fun SwitchRow(title: String, sub: String? = null, on: Boolean, onChange: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(title, fontSize = 14.sp) },
        supportingContent = sub?.let { { Text(it, fontSize = 11.sp, lineHeight = 15.sp) } },
        trailingContent = { Switch(checked = on, onCheckedChange = onChange) }
    )
}

@Composable
fun ActionRow(title: String, sub: String? = null, onClick: () -> Unit) {
    ListItem(
        modifier = Modifier.clickable(onClick = onClick),
        headlineContent = { Text(title, fontSize = 14.sp) },
        supportingContent = sub?.let { { Text(it, fontSize = 11.sp, lineHeight = 15.sp) } },
        trailingContent = {
            Icon(
                androidx.compose.material.icons.Icons.Default.ChevronRight, null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    )
}

@Composable
fun EmptyState(text: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Column(
        Modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text, fontSize = 13.sp, lineHeight = 19.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        if (action != null && onAction != null) {
            Spacer(Modifier.height(14.dp))
            Button(onAction) { Text(action) }
        }
    }
}

val EMOJI_CHOICES = listOf(
    "\uD83C\uDF7D", "\uD83D\uDED2", "\uD83D\uDE97", "\uD83D\uDC15", "\uD83D\uDC08",
    "\uD83D\uDC8A", "\uD83C\uDFE0", "\uD83D\uDCB0", "\u2708\uFE0F", "\uD83C\uDFAC",
    "\uD83D\uDCF1", "\uD83D\uDC55", "\u26A1", "\uD83C\uDF93", "\uD83C\uDF81",
    "\u2615", "\u26FD", "\uD83C\uDFCB", "\uD83D\uDCA1", "\uD83E\uDDFE",
    "\uD83D\uDD27", "\u2702\uFE0F", "\uD83D\uDE8C", "\uD83D\uDE95", "\uD83C\uDF54",
    "\uD83C\uDF55", "\uD83C\uDF7A", "\uD83E\uDDF4", "\uD83D\uDC76", "\uD83D\uDC90",
    "\uD83D\uDCDA", "\uD83C\uDFA7", "\uD83E\uDE7A", "\uD83E\uDDB7", "\uD83D\uDC53",
    "\uD83C\uDFE5", "\uD83D\uDCBC", "\uD83D\uDEE0", "\uD83C\uDF10", "\uD83D\uDCF6",
    "\uD83D\uDEBF", "\uD83E\uDDF9", "\uD83E\uDEB4", "\uD83C\uDFAE", "\u231A",
    "\uD83D\uDCB5", "\uD83C\uDFE6", "\uD83D\uDCC9", "\uD83D\uDCB3", "\uD83E\uDD1D"
)

val COLOR_CHOICES = listOf(
    "#E07A5F", "#81B29A", "#5B8CB8", "#C9A661", "#B07AA1", "#8D6E63",
    "#6FBF8E", "#D9707D", "#E3C25F", "#8A93A6", "#7B9E87", "#A45C40",
    "#4F6D8C", "#9C6B9E", "#C08552", "#5E8B7E"
)

val FLAG_CHOICES = listOf(
    "\uD83C\uDF10", "\uD83C\uDDF6\uD83C\uDDE6", "\uD83C\uDDEE\uD83C\uDDF3",
    "\uD83C\uDDE6\uD83C\uDDEA", "\uD83C\uDDF8\uD83C\uDDE6", "\uD83C\uDDF0\uD83C\uDDFC",
    "\uD83C\uDDE7\uD83C\uDDED", "\uD83C\uDDF4\uD83C\uDDF2", "\uD83C\uDDFA\uD83C\uDDF8",
    "\uD83C\uDDEC\uD83C\uDDE7", "\uD83C\uDDEB\uD83C\uDDF7", "\uD83C\uDDE9\uD83C\uDDEA",
    "\uD83C\uDDF5\uD83C\uDDF0", "\uD83C\uDDE7\uD83C\uDDE9", "\uD83C\uDDF1\uD83C\uDDF0",
    "\uD83C\uDDF5\uD83C\uDDED", "\uD83C\uDDEA\uD83C\uDDEC", "\uD83C\uDDF9\uD83C\uDDF7",
    "\uD83C\uDDE8\uD83C\uDDE6", "\uD83C\uDDE6\uD83C\uDDFA", "\uD83C\uDDF8\uD83C\uDDEC",
    "\uD83C\uDDF2\uD83C\uDDFE", "\uD83C\uDDF9\uD83C\uDDED", "\uD83C\uDDEF\uD83C\uDDF5",
    "\uD83D\uDCBC", "\uD83C\uDFE0", "\u2708\uFE0F"
)
