package com.securemoney.manager.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import java.util.UUID

/* Projections — all carry currency, so nothing can be summed across it. */
data class BalanceRow(val accountId: Long, val currency: String, val balanceMinor: Long)
data class CurrencyTotal(val currency: String, val totalMinor: Long)
data class CategorySpendRow(val categoryId: Long?, val currency: String, val spentMinor: Long)
data class PersonNetRow(val personId: Long, val currency: String, val netMinor: Long)
data class GroupTotalRow(val groupId: Long, val currency: String, val totalMinor: Long)

@Dao
interface SmmDao {

    /* ══════════════════ GROUPS ══════════════════ */
    @Query("SELECT * FROM groups WHERE archived = 0 ORDER BY sortOrder, name")
    fun observeGroups(): Flow<List<GroupEntity>>
    @Query("SELECT * FROM groups") suspend fun allGroupsOnce(): List<GroupEntity>
    @Insert suspend fun insert(g: GroupEntity): Long
    @Update suspend fun update(g: GroupEntity)
    @Delete suspend fun delete(g: GroupEntity)

    /* ══════════════════ ACCOUNTS ══════════════════ */
    @Query("SELECT * FROM accounts WHERE archived = 0 ORDER BY sortOrder, name")
    fun observeAccounts(): Flow<List<AccountEntity>>
    @Query("SELECT * FROM accounts WHERE groupId = :groupId AND archived = 0 ORDER BY sortOrder, name")
    fun observeAccountsInGroup(groupId: Long): Flow<List<AccountEntity>>
    @Query("SELECT * FROM accounts WHERE id = :id") suspend fun account(id: Long): AccountEntity?
    @Query("SELECT * FROM accounts") suspend fun allAccountsOnce(): List<AccountEntity>
    @Insert suspend fun insert(a: AccountEntity): Long
    @Update suspend fun update(a: AccountEntity)

    /**
     * Balance per account: opening + every confirmed movement.
     * Derived, never stored, so it cannot drift from its transactions.
     */
    @Query("""
        SELECT a.id AS accountId, a.currency AS currency,
               a.openingBalanceMinor + COALESCE((
                   SELECT SUM(CASE WHEN t.kind IN ('EXPENSE','TRANSFER_OUT')
                                   THEN -t.amountMinor ELSE t.amountMinor END)
                   FROM transactions t
                   WHERE t.accountId = a.id AND t.confirmed = 1
               ), 0) AS balanceMinor
        FROM accounts a WHERE a.archived = 0
    """)
    fun observeBalances(): Flow<List<BalanceRow>>

    /* ══════════════════ TRANSACTIONS ══════════════════ */
    @Query("SELECT * FROM transactions WHERE confirmed = 1 ORDER BY occurredAt DESC, id DESC")
    fun observeConfirmed(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE confirmed = 0 ORDER BY occurredAt DESC")
    fun observePending(): Flow<List<TransactionEntity>>

    @Query("SELECT COUNT(*) FROM transactions WHERE confirmed = 0")
    fun observePendingCount(): Flow<Int>

    @Query("""SELECT * FROM transactions
              WHERE confirmed = 1 AND occurredAt BETWEEN :from AND :to
              ORDER BY occurredAt DESC""")
    fun observeBetween(from: Long, to: Long): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE id = :id")
    suspend fun transaction(id: Long): TransactionEntity?

    @Query("SELECT * FROM transactions WHERE personId = :personId AND confirmed = 1 ORDER BY occurredAt DESC")
    fun observeForPerson(personId: Long): Flow<List<TransactionEntity>>

    @Query("""SELECT * FROM transactions
              WHERE personId = :personId AND confirmed = 1
                AND personEntryType IN ('paid_for','received_for')
              ORDER BY occurredAt DESC""")
    fun observeOpenAdvances(personId: Long): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE transferPairId = :pairId")
    suspend fun transferPair(pairId: String): List<TransactionEntity>

    @Query("""
        SELECT DISTINCT t.* FROM transactions t
        LEFT JOIN transaction_tags tt ON tt.transactionId = t.id
        LEFT JOIN tags g ON g.id = tt.tagId
        WHERE t.confirmed = 1 AND (
              t.merchant LIKE '%' || :q || '%'
           OR t.note     LIKE '%' || :q || '%'
           OR g.name     LIKE '%' || :q || '%')
        ORDER BY t.occurredAt DESC
    """)
    fun search(q: String): Flow<List<TransactionEntity>>

    @Insert suspend fun insert(t: TransactionEntity): Long
    @Update suspend fun update(t: TransactionEntity)
    @Delete suspend fun delete(t: TransactionEntity)
    @Query("SELECT * FROM transactions") suspend fun allTransactionsOnce(): List<TransactionEntity>
    @Query("DELETE FROM transactions") suspend fun wipeTransactions()

    /**
     * Record a transfer as two linked rows sharing a pair id.
     * Cross-currency transfers store the counter amount and the rate the
     * user confirmed, frozen onto both rows.
     */
    @Transaction
    suspend fun insertTransfer(
        fromAccount: AccountEntity,
        toAccount: AccountEntity,
        fromMinor: Long,
        toMinor: Long,
        note: String,
        occurredAt: Long
    ): String {
        val pair = UUID.randomUUID().toString()
        val crossCurrency = fromAccount.currency != toAccount.currency
        val rate = if (crossCurrency && fromMinor != 0L)
            toMinor.toDouble() / fromMinor.toDouble() else null

        insert(TransactionEntity(
            merchant = "Transfer to ${toAccount.name}",
            note = note,
            amountMinor = fromMinor,
            currency = fromAccount.currency,
            kind = TxKind.TRANSFER_OUT,
            accountId = fromAccount.id,
            transferPairId = pair,
            fxCounterCurrency = if (crossCurrency) toAccount.currency else null,
            fxCounterMinor = if (crossCurrency) toMinor else null,
            fxRateUsed = rate,
            occurredAt = occurredAt
        ))
        insert(TransactionEntity(
            merchant = "Transfer from ${fromAccount.name}",
            note = note,
            amountMinor = toMinor,
            currency = toAccount.currency,
            kind = TxKind.TRANSFER_IN,
            accountId = toAccount.id,
            transferPairId = pair,
            fxCounterCurrency = if (crossCurrency) fromAccount.currency else null,
            fxCounterMinor = if (crossCurrency) fromMinor else null,
            fxRateUsed = rate?.let { 1.0 / it },
            occurredAt = occurredAt
        ))
        return pair
    }

    /** Delete both halves of a transfer together — never leave one orphaned. */
    @Transaction
    suspend fun deleteTransfer(pairId: String) {
        transferPair(pairId).forEach { delete(it) }
    }

    /* ══════════════════ TOTALS (per currency, always) ══════════════════ */

    /**
     * Category spend, split by currency.
     * Counts plain expenses plus person entries that became your own cost.
     * Excludes transfers, adjustments and open advances.
     */
    @Query("""
        SELECT categoryId AS categoryId, currency AS currency,
               SUM(amountMinor) AS spentMinor
        FROM transactions
        WHERE kind = 'EXPENSE' AND confirmed = 1
          AND occurredAt BETWEEN :from AND :to
          AND (personId IS NULL OR personEntryType IN
               ('absorbed','offset_support','support_paid'))
        GROUP BY categoryId, currency
    """)
    fun observeCategorySpend(from: Long, to: Long): Flow<List<CategorySpendRow>>

    @Query("""
        SELECT currency AS currency, SUM(amountMinor) AS totalMinor
        FROM transactions
        WHERE kind = 'EXPENSE' AND confirmed = 1
          AND occurredAt BETWEEN :from AND :to
          AND (personId IS NULL OR personEntryType IN
               ('absorbed','offset_support','support_paid'))
        GROUP BY currency
    """)
    fun observeOutflowByCurrency(from: Long, to: Long): Flow<List<CurrencyTotal>>

    @Query("""
        SELECT currency AS currency, SUM(amountMinor) AS totalMinor
        FROM transactions
        WHERE kind = 'INCOME' AND confirmed = 1 AND personId IS NULL
          AND occurredAt BETWEEN :from AND :to
        GROUP BY currency
    """)
    fun observeInflowByCurrency(from: Long, to: Long): Flow<List<CurrencyTotal>>

    /** Money lent out and still open, per currency. */
    @Query("""
        SELECT currency AS currency, SUM(amountMinor) AS totalMinor
        FROM transactions
        WHERE confirmed = 1 AND personEntryType IN ('paid_for','received_for')
          AND occurredAt BETWEEN :from AND :to
        GROUP BY currency
    """)
    fun observeLentByCurrency(from: Long, to: Long): Flow<List<CurrencyTotal>>

    @Query("""
        SELECT a.groupId AS groupId, a.currency AS currency,
               SUM(a.openingBalanceMinor + COALESCE((
                   SELECT SUM(CASE WHEN t.kind IN ('EXPENSE','TRANSFER_OUT')
                                   THEN -t.amountMinor ELSE t.amountMinor END)
                   FROM transactions t WHERE t.accountId = a.id AND t.confirmed = 1
               ), 0)) AS totalMinor
        FROM accounts a WHERE a.archived = 0
        GROUP BY a.groupId, a.currency
    """)
    fun observeGroupTotals(): Flow<List<GroupTotalRow>>

    /* ══════════════════ BUDGETS ══════════════════ */
    @Query("SELECT * FROM budgets") fun observeBudgets(): Flow<List<BudgetEntity>>
    @Query("SELECT * FROM budgets WHERE categoryId = :categoryId")
    fun observeBudgetsFor(categoryId: Long): Flow<List<BudgetEntity>>
    @Query("SELECT * FROM budgets") suspend fun allBudgetsOnce(): List<BudgetEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(b: BudgetEntity): Long
    @Update suspend fun update(b: BudgetEntity)
    @Delete suspend fun delete(b: BudgetEntity)
    @Query("DELETE FROM budgets WHERE categoryId = :categoryId AND currency = :currency")
    suspend fun deleteBudget(categoryId: Long, currency: String)

    /* ══════════════════ CATEGORIES ══════════════════ */
    @Query("SELECT * FROM categories WHERE archived = 0 ORDER BY sortOrder, name")
    fun observeCategories(): Flow<List<CategoryEntity>>
    @Query("SELECT * FROM categories") suspend fun allCategoriesOnce(): List<CategoryEntity>
    @Insert suspend fun insert(c: CategoryEntity): Long
    @Update suspend fun update(c: CategoryEntity)

    /* ══════════════════ TAGS ══════════════════ */
    @Query("SELECT * FROM tags ORDER BY name") fun observeTags(): Flow<List<TagEntity>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(t: TagEntity): Long
    @Query("SELECT * FROM tags WHERE LOWER(name) = LOWER(:name) LIMIT 1")
    suspend fun findTag(name: String): TagEntity?
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun link(r: TransactionTagCrossRef)
    @Query("DELETE FROM transaction_tags WHERE transactionId = :txId")
    suspend fun clearTags(txId: Long)
    @Query("""SELECT g.* FROM tags g JOIN transaction_tags tt ON tt.tagId = g.id
              WHERE tt.transactionId = :txId""")
    suspend fun tagsFor(txId: Long): List<TagEntity>
    @Query("SELECT * FROM transaction_tags") suspend fun allTagLinksOnce(): List<TransactionTagCrossRef>
    @Query("SELECT * FROM tags") suspend fun allTagsOnce(): List<TagEntity>

    @Transaction
    suspend fun attachTag(txId: Long, name: String) {
        val clean = name.trim().removePrefix("#").lowercase()
        if (clean.isBlank()) return
        val tag = findTag(clean) ?: run { insert(TagEntity(name = clean)); findTag(clean) }
        tag?.let { link(TransactionTagCrossRef(txId, it.id)) }
    }

    /* ══════════════════ PEOPLE ══════════════════ */
    @Query("SELECT * FROM people WHERE archived = 0 ORDER BY name")
    fun observePeople(): Flow<List<PersonEntity>>
    @Query("SELECT * FROM people WHERE id = :id") suspend fun person(id: Long): PersonEntity?
    @Query("SELECT * FROM people") suspend fun allPeopleOnce(): List<PersonEntity>
    @Query("SELECT * FROM people WHERE autoMatchSms = 1") suspend fun autoMatchPeople(): List<PersonEntity>
    @Insert suspend fun insert(p: PersonEntity): Long
    @Update suspend fun update(p: PersonEntity)

    /**
     * Outstanding position per person PER CURRENCY.
     * Positive = they owe you. Negative = you owe them.
     *
     * absorbed / offset_support / support_paid are deliberately excluded:
     * they are your own costs, so they must not linger as a claim.
     */
    @Query("""
        SELECT personId AS personId, currency AS currency, SUM(
            CASE personEntryType
                WHEN 'paid_for'     THEN  amountMinor
                WHEN 'settle_out'   THEN  amountMinor
                WHEN 'received_for' THEN -amountMinor
                WHEN 'settle_in'    THEN -amountMinor
                ELSE 0 END
        ) AS netMinor
        FROM transactions
        WHERE personId IS NOT NULL AND confirmed = 1
        GROUP BY personId, currency
    """)
    fun observePersonNets(): Flow<List<PersonNetRow>>

    /** Lifetime cost of a person to you, per currency. */
    @Query("""
        SELECT personId AS personId, currency AS currency,
               SUM(amountMinor) AS netMinor
        FROM transactions
        WHERE personId IS NOT NULL AND confirmed = 1
          AND personEntryType IN ('absorbed','offset_support','support_paid')
        GROUP BY personId, currency
    """)
    fun observePersonCosts(): Flow<List<PersonNetRow>>

    @Query("""
        SELECT COALESCE(SUM(amountMinor), 0) FROM transactions
        WHERE personId = :personId AND confirmed = 1 AND supportPeriod = :period
          AND personEntryType IN ('support_paid','offset_support')
    """)
    fun observeSupportPaid(personId: Long, period: String): Flow<Long>

    /* ══════════════════ FX RATES ══════════════════ */
    @Query("SELECT * FROM fx_rates ORDER BY fromCurrency, toCurrency")
    fun observeRates(): Flow<List<FxRateEntity>>
    @Query("SELECT * FROM fx_rates") suspend fun allRatesOnce(): List<FxRateEntity>
    @Query("""SELECT * FROM fx_rates WHERE fromCurrency = :from AND toCurrency = :to LIMIT 1""")
    suspend fun rate(from: String, to: String): FxRateEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(r: FxRateEntity): Long
    @Update suspend fun update(r: FxRateEntity)
    @Delete suspend fun delete(r: FxRateEntity)

    /**
     * Best available rate, trying the direct pair then the inverse.
     * Returns null when nothing is known — the UI then asks outright
     * rather than inventing a number.
     */
    @Transaction
    suspend fun bestRate(from: String, to: String): Pair<Double, Boolean>? {
        if (from == to) return 1.0 to true
        rate(from, to)?.let { return it.rate to !it.isIndicative }
        rate(to, from)?.let { if (it.rate != 0.0) return (1.0 / it.rate) to !it.isIndicative }
        return null
    }

    /* ══════════════════ CAPTURE ══════════════════ */
    @Query("SELECT * FROM sms_senders ORDER BY sender") fun observeSmsSenders(): Flow<List<SmsSenderEntity>>
    @Query("SELECT * FROM sms_senders WHERE enabled = 1") suspend fun approvedSenders(): List<SmsSenderEntity>
    @Query("SELECT * FROM sms_senders") suspend fun allSendersOnce(): List<SmsSenderEntity>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(s: SmsSenderEntity): Long
    @Update suspend fun update(s: SmsSenderEntity)
    @Delete suspend fun delete(s: SmsSenderEntity)
    @Query("UPDATE sms_senders SET messageCount = messageCount + 1, lastSeenAt = :at WHERE id = :id")
    suspend fun touchSender(id: Long, at: Long)

    @Query("SELECT * FROM notif_apps ORDER BY appLabel") fun observeNotifApps(): Flow<List<NotifAppEntity>>
    @Query("SELECT * FROM notif_apps WHERE enabled = 1") suspend fun approvedApps(): List<NotifAppEntity>
    @Query("SELECT * FROM notif_apps") suspend fun allAppsOnce(): List<NotifAppEntity>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(a: NotifAppEntity): Long
    @Update suspend fun update(a: NotifAppEntity)
    @Delete suspend fun delete(a: NotifAppEntity)
    @Query("UPDATE notif_apps SET messageCount = messageCount + 1, lastSeenAt = :at WHERE id = :id")
    suspend fun touchApp(id: Long, at: Long)

    @Query("SELECT * FROM capture_candidates WHERE dismissed = 0 ORDER BY lastSeenAt DESC")
    fun observeCandidates(): Flow<List<CaptureCandidateEntity>>
    @Query("SELECT * FROM capture_candidates WHERE source = :src AND identifier = :ident LIMIT 1")
    suspend fun candidate(src: String, ident: String): CaptureCandidateEntity?
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(c: CaptureCandidateEntity): Long
    @Update suspend fun update(c: CaptureCandidateEntity)
    @Delete suspend fun delete(c: CaptureCandidateEntity)

    /** Note an unapproved sender. The message body is never stored. */
    @Transaction
    suspend fun noteCandidate(source: String, identifier: String, label: String) {
        val existing = candidate(source, identifier)
        if (existing == null) {
            insert(CaptureCandidateEntity(source = source, identifier = identifier, displayLabel = label))
        } else {
            update(existing.copy(
                seenCount = existing.seenCount + 1,
                lastSeenAt = System.currentTimeMillis()
            ))
        }
    }

    /* ══════════════════ RULES ══════════════════ */
    @Query("SELECT * FROM sms_rules WHERE enabled = 1 ORDER BY priority DESC, id")
    suspend fun activeSmsRules(): List<SmsRuleEntity>
    @Query("SELECT * FROM sms_rules ORDER BY priority DESC") fun observeSmsRules(): Flow<List<SmsRuleEntity>>
    @Insert suspend fun insert(r: SmsRuleEntity): Long
    @Update suspend fun update(r: SmsRuleEntity)
    @Delete suspend fun delete(r: SmsRuleEntity)

    @Query("SELECT * FROM learned_rules WHERE scope = :scope AND matchKey = :key LIMIT 1")
    suspend fun learned(scope: String, key: String): LearnedRuleEntity?
    @Query("SELECT * FROM learned_rules ORDER BY hitCount DESC") fun observeLearned(): Flow<List<LearnedRuleEntity>>
    @Query("SELECT * FROM learned_rules") suspend fun allLearnedOnce(): List<LearnedRuleEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(r: LearnedRuleEntity): Long
    @Update suspend fun update(r: LearnedRuleEntity)
    @Delete suspend fun delete(r: LearnedRuleEntity)

    /**
     * Remember a correction. Second time the same correction sticks, the
     * app starts applying it on its own and stops asking.
     */
    @Transaction
    suspend fun learn(scope: String, key: String, targetId: Long) {
        val clean = key.trim().lowercase()
        if (clean.isBlank()) return
        val existing = learned(scope, clean)
        if (existing == null) {
            insert(LearnedRuleEntity(scope = scope, matchKey = clean, targetId = targetId))
        } else if (existing.targetId == targetId) {
            update(existing.copy(
                hitCount = existing.hitCount + 1,
                lastUsedAt = System.currentTimeMillis()
            ))
        } else {
            // Changed their mind — reset the count rather than fighting the user.
            update(existing.copy(
                targetId = targetId, hitCount = 1,
                lastUsedAt = System.currentTimeMillis()
            ))
        }
    }

    /* ══════════════════ REMINDERS ══════════════════ */
    @Query("SELECT * FROM reminders ORDER BY hour, minute") fun observeReminders(): Flow<List<ReminderEntity>>
    @Query("SELECT * FROM reminders WHERE enabled = 1") suspend fun activeReminders(): List<ReminderEntity>
    @Query("SELECT * FROM reminders") suspend fun allRemindersOnce(): List<ReminderEntity>
    @Query("SELECT * FROM reminders WHERE id = :id") suspend fun reminder(id: Long): ReminderEntity?
    @Insert suspend fun insert(r: ReminderEntity): Long
    @Update suspend fun update(r: ReminderEntity)
    @Delete suspend fun delete(r: ReminderEntity)

    /* ══════════════════ LOG & MAINTENANCE ══════════════════ */
    @Insert suspend fun log(e: EventLogEntity)
    @Query("SELECT * FROM event_log ORDER BY id DESC LIMIT 300") fun observeLog(): Flow<List<EventLogEntity>>
    @Query("DELETE FROM event_log WHERE id NOT IN (SELECT id FROM event_log ORDER BY id DESC LIMIT 300)")
    suspend fun trimLog()
    @Query("PRAGMA integrity_check") suspend fun integrityCheck(): List<String>
    @Query("SELECT COUNT(*) FROM transactions") suspend fun txCount(): Int
}

@Database(
    entities = [
        GroupEntity::class, AccountEntity::class, CategoryEntity::class,
        BudgetEntity::class, TagEntity::class, TransactionTagCrossRef::class,
        PersonEntity::class, TransactionEntity::class, FxRateEntity::class,
        SmsSenderEntity::class, NotifAppEntity::class, CaptureCandidateEntity::class,
        SmsRuleEntity::class, LearnedRuleEntity::class, ReminderEntity::class,
        EventLogEntity::class
    ],
    version = AppDatabase.DB_VERSION,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): SmmDao

    companion object {
        /** ── BUMP on any entity change, and add a migration below. ── */
        const val DB_VERSION = 1

        /**
         * Template for the first schema change:
         *
         * val MIGRATION_1_2 = object : Migration(1, 2) {
         *     override fun migrate(db: SupportSQLiteDatabase) {
         *         db.execSQL("ALTER TABLE transactions ADD COLUMN location TEXT")
         *     }
         * }
         */
        private val ALL_MIGRATIONS: Array<Migration> = arrayOf()

        @Volatile private var INSTANCE: AppDatabase? = null

        /**
         * [key] non-null opens the file encrypted with SQLCipher.
         * null opens plaintext — the state before encryption is enabled.
         */
        /**
         * Open (or return) the database.
         *
         * NOTE: if an instance already exists this returns it and IGNORES
         * [key]. That is intentional — but it means callers must never rely
         * on this to switch a plaintext handle to an encrypted one. Call
         * [close] first. Use [requireOpen] when you know it should already
         * be open, so a bug surfaces as a crash rather than as a plaintext
         * handle quietly opened over an encrypted file.
         */
        fun get(context: Context, key: ByteArray? = null): AppDatabase =
            INSTANCE ?: synchronized(this) { INSTANCE ?: build(context, key).also { INSTANCE = it } }

        /**
         * The already-open database. Throws if it isn't open.
         * Used by UI that renders only after unlock has succeeded: a crash
         * there is a loud bug report, whereas silently building a second,
         * plaintext handle over an encrypted file would risk the data.
         */
        fun requireOpen(): AppDatabase = INSTANCE
            ?: throw IllegalStateException(
                "Database is not open. Unlock must complete before the UI reads it."
            )

        private fun build(context: Context, key: ByteArray?): AppDatabase {
            val b = Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "smm.db"
            ).addMigrations(*ALL_MIGRATIONS)
            // Destructive migration intentionally NOT enabled.

            if (key != null) {
                b.openHelperFactory(net.zetetic.database.sqlcipher.SupportOpenHelperFactory(key.copyOf()))
            }
            return b.build()
        }

        fun close() = synchronized(this) {
            runCatching { INSTANCE?.close() }
            INSTANCE = null
        }

        fun isOpen(): Boolean = INSTANCE != null
    }
}
