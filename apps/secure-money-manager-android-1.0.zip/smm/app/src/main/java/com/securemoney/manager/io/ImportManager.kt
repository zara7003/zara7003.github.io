package com.securemoney.manager.io

import com.securemoney.manager.data.*
import org.json.JSONObject

/**
 * Import remaps every old id to a new one, so foreign keys survive a
 * round trip even if the numbering differs. Reference data is matched by
 * name, which means importing into a database you have since added
 * categories to won't create duplicates.
 */
object ImportManager {

    enum class Mode { MERGE, REPLACE }

    data class Report(
        val groups: Int, val accounts: Int, val categories: Int, val budgets: Int,
        val people: Int, val tags: Int, val transactions: Int, val skipped: Int,
        val rates: Int, val warnings: List<String>
    )

    suspend fun importJson(json: String, dao: SmmDao, mode: Mode): Report {
        val warnings = mutableListOf<String>()
        val root = JSONObject(json)

        val schema = root.optInt("schema", 0)
        if (schema > ExportManager.SCHEMA) {
            warnings += "This backup was written by a newer version (schema $schema). Unknown fields were ignored."
        }

        if (mode == Mode.REPLACE) dao.wipeTransactions()

        /* ── Groups ── */
        val groupMap = HashMap<Long, Long>()
        val existingGroups = dao.allGroupsOnce()
        root.optJSONArray("groups")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val name = o.getString("name")
                val hit = existingGroups.firstOrNull { it.name.equals(name, true) }
                groupMap[o.getLong("id")] = hit?.id ?: dao.insert(GroupEntity(
                    name = name,
                    icon = o.optString("icon", "\uD83C\uDF10"),
                    colorHex = o.optString("colorHex", "#5B8CB8"),
                    defaultCurrency = o.optString("defaultCurrency", "USD"),
                    sortOrder = o.optInt("sortOrder", 0)
                ))
            }
        }

        /* ── Accounts ── */
        val accountMap = HashMap<Long, Long>()
        val existingAccounts = dao.allAccountsOnce()
        root.optJSONArray("accounts")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val name = o.getString("name")
                val currency = o.optString("currency", "USD")
                // Match on name AND currency: "Cash" in QAR and "Cash" in INR
                // are genuinely different accounts.
                val hit = existingAccounts.firstOrNull {
                    it.name.equals(name, true) && it.currency == currency
                }
                val groupId = groupMap[o.optLong("groupId")]
                    ?: dao.allGroupsOnce().firstOrNull()?.id
                    ?: dao.insert(GroupEntity(name = "Imported", defaultCurrency = currency))
                accountMap[o.getLong("id")] = hit?.id ?: dao.insert(AccountEntity(
                    name = name, groupId = groupId, currency = currency,
                    type = o.optString("type", "BANK"),
                    openingBalanceMinor = o.optLong("openingBalanceMinor", 0),
                    colorHex = o.optString("colorHex", "#5B8CB8"),
                    icon = o.optString("icon", "\uD83C\uDFE6"),
                    accountDigits = o.optString("accountDigits", ""),
                    note = o.optString("note", ""),
                    sortOrder = o.optInt("sortOrder", 0)
                ))
            }
        }

        /* ── Categories ── */
        val catMap = HashMap<Long, Long>()
        val existingCats = dao.allCategoriesOnce()
        root.optJSONArray("categories")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val name = o.getString("name")
                val hit = existingCats.firstOrNull { it.name.equals(name, true) }
                catMap[o.getLong("id")] = hit?.id ?: dao.insert(CategoryEntity(
                    name = name,
                    isExpense = o.optBoolean("isExpense", true),
                    icon = o.optString("icon", "\u2754"),
                    colorHex = o.optString("colorHex", "#8A93A6"),
                    sortOrder = o.optInt("sortOrder", 0)
                ))
            }
        }

        /* ── Budgets (per category per currency) ── */
        var budgetCount = 0
        root.optJSONArray("budgets")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val cat = catMap[o.optLong("categoryId")] ?: continue
                dao.insert(BudgetEntity(
                    categoryId = cat,
                    currency = o.optString("currency", "USD"),
                    monthlyLimitMinor = o.optLong("monthlyLimitMinor", 0),
                    rollover = o.optBoolean("rollover", false)
                ))
                budgetCount++
            }
        }

        /* ── People ── */
        val personMap = HashMap<Long, Long>()
        val existingPeople = dao.allPeopleOnce()
        root.optJSONArray("people")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val name = o.getString("name")
                val hit = existingPeople.firstOrNull { it.name.equals(name, true) }
                personMap[o.getLong("id")] = hit?.id ?: dao.insert(PersonEntity(
                    name = name,
                    colorHex = o.optString("colorHex", "#B07AA1"),
                    relationship = o.optString("relationship", ""),
                    smsAliases = o.optString("smsAliases", ""),
                    autoMatchSms = o.optBoolean("autoMatchSms", false),
                    allowanceMinor = o.optLong("allowanceMinor", 0),
                    allowanceCurrency = o.optString("allowanceCurrency", "USD"),
                    allowanceDayOfMonth = o.optInt("allowanceDayOfMonth", 1),
                    defaultAbsorbCategoryId = o.optLongOrNull("defaultAbsorbCategoryId")
                        ?.let { catMap[it] }
                ))
            }
        }

        /* ── Tags ── */
        val tagMap = HashMap<Long, Long>()
        root.optJSONArray("tags")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val name = o.getString("name")
                val existing = dao.findTag(name)
                tagMap[o.getLong("id")] = existing?.id ?: run {
                    dao.insert(TagEntity(name = name, colorHex = o.optString("colorHex", "#8A93A6")))
                    dao.findTag(name)?.id ?: -1L
                }
            }
        }

        /* ── Transactions ── */
        val existingTx = dao.allTransactionsOnce()
        fun fp(m: String, amt: Long, cur: String, at: Long) = "$m|$amt|$cur|$at"
        val seen = existingTx.map { fp(it.merchant, it.amountMinor, it.currency, it.occurredAt) }
            .toMutableSet()

        val txMap = HashMap<Long, Long>()
        var imported = 0; var skipped = 0
        root.optJSONArray("transactions")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val merchant = o.getString("merchant")
                val amt = o.getLong("amountMinor")
                val cur = o.optString("currency", "USD")
                val at = o.getLong("occurredAt")
                val key = fp(merchant, amt, cur, at)
                if (key in seen) { skipped++; continue }

                val acc = accountMap[o.optLong("accountId")]
                if (acc == null) {
                    warnings += "\"$merchant\" refers to an account that isn't in this backup; skipped."
                    skipped++; continue
                }

                val newId = dao.insert(TransactionEntity(
                    merchant = merchant,
                    note = o.optString("note", ""),
                    amountMinor = amt,
                    currency = cur,
                    kind = o.optString("kind", TxKind.EXPENSE),
                    accountId = acc,
                    categoryId = o.optLongOrNull("categoryId")?.let { catMap[it] },
                    transferPairId = o.optStringOrNull("transferPairId"),
                    personId = o.optLongOrNull("personId")?.let { personMap[it] },
                    personEntryType = o.optStringOrNull("personEntryType"),
                    supportPeriod = o.optStringOrNull("supportPeriod"),
                    fxCounterCurrency = o.optStringOrNull("fxCounterCurrency"),
                    fxCounterMinor = o.optLongOrNull("fxCounterMinor"),
                    fxRateUsed = if (o.isNull("fxRateUsed")) null else o.optDouble("fxRateUsed"),
                    source = o.optString("source", "IMPORT"),
                    photoUri = o.optStringOrNull("photoUri"),
                    occurredAt = at,
                    createdAt = o.optLong("createdAt", at),
                    confirmed = o.optBoolean("confirmed", true)
                ))
                txMap[o.getLong("id")] = newId
                seen += key
                imported++
            }
        }

        // Second pass for settlesTransactionId, which can point at a row
        // imported after it.
        root.optJSONArray("transactions")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val oldSettles = o.optLongOrNull("settlesTransactionId") ?: continue
                val newSelf = txMap[o.getLong("id")] ?: continue
                val newTarget = txMap[oldSettles] ?: continue
                dao.transaction(newSelf)?.let {
                    dao.update(it.copy(settlesTransactionId = newTarget))
                }
            }
        }

        root.optJSONArray("transactionTags")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val tx = txMap[o.getLong("transactionId")]
                val tg = tagMap[o.getLong("tagId")]
                if (tx != null && tg != null && tg > 0) {
                    dao.link(TransactionTagCrossRef(tx, tg))
                }
            }
        }

        /* ── FX rates ── */
        var rateCount = 0
        root.optJSONArray("fxRates")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                dao.insert(FxRateEntity(
                    fromCurrency = o.getString("fromCurrency"),
                    toCurrency = o.getString("toCurrency"),
                    rate = o.optDouble("rate", 1.0),
                    setByUserAt = o.optLongOrNull("setByUserAt"),
                    note = o.optString("note", "")
                ))
                rateCount++
            }
        }

        root.optJSONArray("learnedRules")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val scope = o.getString("scope")
                val target = o.optLong("targetId")
                // Remap the target to whichever table this scope refers to.
                val mapped = when (scope) {
                    LearnedRuleEntity.MERCHANT_CATEGORY -> catMap[target]
                    LearnedRuleEntity.SENDER_ACCOUNT,
                    LearnedRuleEntity.MERCHANT_ACCOUNT -> accountMap[target]
                    LearnedRuleEntity.MERCHANT_PERSON -> personMap[target]
                    else -> null
                } ?: continue
                dao.insert(LearnedRuleEntity(
                    scope = scope,
                    matchKey = o.getString("matchKey"),
                    targetId = mapped,
                    hitCount = o.optInt("hitCount", 1)
                ))
            }
        }

        root.optJSONArray("reminders")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                dao.insert(ReminderEntity(
                    title = o.getString("title"),
                    message = o.optString("message", ""),
                    frequency = o.optString("frequency", "WEEKLY"),
                    hour = o.optInt("hour", 20), minute = o.optInt("minute", 0),
                    daysOfWeek = o.optString("daysOfWeek", ""),
                    dayOfMonth = o.optInt("dayOfMonth", 1),
                    action = o.optString("action", "NONE"),
                    // Imported reminders arrive disabled — importing a backup
                    // should never start firing notifications by surprise.
                    enabled = false
                ))
            }
        }

        dao.log(EventLogEntity(
            tag = "IMPORT",
            message = "$mode: $imported in, $skipped skipped"
        ))

        return Report(
            groups = groupMap.size, accounts = accountMap.size, categories = catMap.size,
            budgets = budgetCount, people = personMap.size, tags = tagMap.size,
            transactions = imported, skipped = skipped, rates = rateCount, warnings = warnings
        )
    }
}

private fun JSONObject.optLongOrNull(k: String): Long? =
    if (!has(k) || isNull(k)) null else optLong(k)

private fun JSONObject.optStringOrNull(k: String): String? =
    if (!has(k) || isNull(k)) null else optString(k).takeIf { it.isNotBlank() }
