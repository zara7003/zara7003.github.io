package com.securemoney.manager

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.fragment.app.FragmentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.securemoney.manager.data.AppDatabase
import com.securemoney.manager.data.Crypto
import com.securemoney.manager.data.CategoryEntity
import com.securemoney.manager.data.GroupEntity
import com.securemoney.manager.data.PersonEntity
import com.securemoney.manager.data.TransactionEntity
import com.securemoney.manager.io.ExportManager
import com.securemoney.manager.ui.*
import kotlinx.coroutines.launch

/**
 * ══════════════════════════════════════════════════════════════════
 *  APP FLOW
 * ══════════════════════════════════════════════════════════════════
 *  Onboarding (once) → Unlock (if encryption is on) → Main
 *
 *  The DAO is nullable until the database is actually open, which for an
 *  encrypted database means "until the user has entered their passphrase
 *  this launch". Nothing in the UI tree below Main ever sees a null DAO.
 */
class MainActivity : FragmentActivity() {

    private var pendingRoute: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Content is sensitive: block screenshots and the app-switcher
        // preview by default. Settings lets you turn this off.
        window.setFlags(
            android.view.WindowManager.LayoutParams.FLAG_SECURE,
            android.view.WindowManager.LayoutParams.FLAG_SECURE
        )
        WindowCompat.setDecorFitsSystemWindows(window, false)
        pendingRoute = intent?.getStringExtra("route")

        val app = application as SmmApp
        setContent {
            val settings by app.settings.flow.collectAsStateWithLifecycle(Settings())
            SmmTheme(settings.theme) {
                Surface(Modifier.fillMaxSize()) {
                    AppRoot(app, settings, pendingRoute) { pendingRoute = null }
                }
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        pendingRoute = intent.getStringExtra("route")
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppRoot(
    app: SmmApp,
    settings: Settings,
    initialRoute: String?,
    onRouteConsumed: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var dbOpen by remember { mutableStateOf(AppDatabase.isOpen()) }
    var route by remember(initialRoute) {
        mutableStateOf(initialRoute ?: settings.navTabs.firstOrNull() ?: "records")
    }
    var sheet by remember { mutableStateOf<String?>(null) }
    var editingTx by remember { mutableStateOf<TransactionEntity?>(null) }
    var editingGroup by remember { mutableStateOf<GroupEntity?>(null) }
    var editingCategory by remember { mutableStateOf<CategoryEntity?>(null) }
    var openPerson by remember { mutableStateOf<PersonEntity?>(null) }
    var addAccountGroupId by remember { mutableStateOf<Long?>(null) }
    var showMore by remember { mutableStateOf(false) }
    // Bumped whenever the database handle is replaced (e.g. after enabling
    // encryption), so every `remember`ed dao is re-derived rather than left
    // pointing at a closed database.
    var dbGeneration by remember { mutableIntStateOf(0) }

    val notifPermission = rememberLauncherIfAvailable()

    when {
        !settings.onboarded -> {
            Onboarding { baseCurrency, groups, _ ->
                scope.launch {
                    app.settings.set(Keys.BASE_CURRENCY, baseCurrency)
                    app.settings.set(Keys.ONBOARDED, true)
                    app.settings.set(Keys.TERMS_ACCEPTED, TERMS_VERSION)
                    val dao = AppDatabase.get(ctx).dao()
                    Seed.run(dao, baseCurrency, groups)
                    Seed.seedIndicativeRates(dao, baseCurrency)
                    dbOpen = true
                }
            }
        }

        settings.needsTerms -> {
            // Terms changed since this person last accepted — re-show,
            // not silently carry the old acceptance forward.
            ReacceptTerms { scope.launch { app.settings.set(Keys.TERMS_ACCEPTED, TERMS_VERSION) } }
        }

        !dbOpen -> {
            val lockMode = remember { Crypto.lockMode(ctx) }
            if (lockMode == Crypto.LockMode.NONE) {
                // No encryption set up — open immediately, no prompt.
                LaunchedEffect(Unit) { AppDatabase.get(ctx); dbOpen = true }
            } else {
                UnlockScreen(
                    mode = lockMode,
                    biometricAvailable = Crypto.hasBiometricWrap(ctx) &&
                        BiometricAuth.isAvailable(ctx),
                    onSubmitSecret = { secret ->
                        val key = Crypto.unlockWithSecret(ctx, secret)
                        secret.fill('\u0000')
                        if (key != null) {
                            AppDatabase.get(ctx, key)
                            dbOpen = true
                            true
                        } else false
                    },
                    onBiometric = {
                        val activity = ctx as? androidx.fragment.app.FragmentActivity
                        if (activity != null) {
                            BiometricAuth.prompt(
                                activity = activity,
                                onSuccess = {
                                    val key = Crypto.unlockWithBiometric(ctx)
                                    if (key != null) { AppDatabase.get(ctx, key); dbOpen = true }
                                },
                                onError = { /* User cancelled or hardware unavailable — they can still type the passphrase. */ }
                            )
                        }
                    }
                )
            }
        }

        else -> {
            val dao = remember(dbGeneration) { AppDatabase.requireOpen().dao() }

            Scaffold(
                bottomBar = {
                    NavigationBar {
                        settings.navTabs.take(settings.navCount).forEach { key ->
                            val label = ALL_NAV.firstOrNull { it.first == key }?.second ?: key
                            NavigationBarItem(
                                selected = route == key,
                                onClick = { route = key },
                                icon = { Icon(navIcon(key), label) },
                                label = { Text(label, fontSize = 10.sp) }
                            )
                        }
                        NavigationBarItem(
                            selected = showMore,
                            onClick = { showMore = true },
                            icon = { Icon(Icons.Default.MoreHoriz, "More") },
                            label = { Text("More", fontSize = 10.sp) }
                        )
                    }
                },
                floatingActionButton = {
                    if (route in setOf("records", "calendar")) {
                        FloatingActionButton({ editingTx = null; sheet = "add" }) {
                            Icon(Icons.Default.Add, "Add entry")
                        }
                    }
                }
            ) { padding ->
                Box(Modifier.padding(padding)) {
                    when (route) {
                        "records" -> RecordsScreen(dao, settings) { editingTx = it; sheet = "add" }
                        "calendar" -> CalendarScreen(dao) { editingTx = it; sheet = "add" }
                        "accounts" -> AccountsScreen(
                            dao,
                            onEditAccount = { sheet = "account:${it.id}" },
                            onEditGroup = { editingGroup = it; sheet = "group" },
                            onAddAccount = { addAccountGroupId = it; sheet = "account:0" },
                            onTransfer = { sheet = "transfer" }
                        )
                        "people" -> PeopleScreen(dao, onOpen = { openPerson = it },
                            onAdd = { sheet = "person" })
                        "budgets" -> BudgetsScreen(dao) { editingCategory = it; sheet = "category" }
                        "categories" -> CategoriesScreen(dao) { editingCategory = it; sheet = "category" }
                        "tags" -> TagsScreen(dao)
                        "review" -> ReviewScreen(dao) { editingTx = it; sheet = "add" }
                        "settings" -> SettingsScreen(
                            ctx, app, dao, settings, notifPermission,
                            onDatabaseReopened = { dbGeneration++ }
                        )
                        "export" -> ExportScreen(ctx, dao)
                        else -> RecordsScreen(dao, settings) { editingTx = it; sheet = "add" }
                    }
                }
            }

            if (showMore) {
                MoreSheet(settings, currentRoute = route,
                    onPick = { route = it; showMore = false },
                    onDismiss = { showMore = false })
            }

            when {
                sheet == "add" -> {
                    // Calculator-style full-screen entry (the fast path).
                    // Shown as a dialog-style overlay so it covers the nav bar.
                    androidx.compose.ui.window.Dialog(
                        onDismissRequest = { sheet = null; editingTx = null },
                        properties = androidx.compose.ui.window.DialogProperties(
                            usePlatformDefaultWidth = false
                        )
                    ) {
                        CalculatorEntryScreen(
                            dao = dao,
                            existing = editingTx,
                            defaultAccountId = null,
                            onDone = { sheet = null; editingTx = null },
                            onCancel = { sheet = null; editingTx = null },
                            onMoreOptions = { sheet = "add_detailed" }
                        )
                    }
                }
                sheet == "add_detailed" -> AddTransactionSheet(dao, editingTx) { sheet = null; editingTx = null }
                sheet == "transfer" -> TransferSheet(dao) { sheet = null }
                sheet == "group" -> GroupEditorSheet(dao, editingGroup) { sheet = null; editingGroup = null }
                sheet == "category" -> CategoryEditorSheet(dao, editingCategory) { sheet = null; editingCategory = null }
                sheet == "person" -> PersonEditorSheet(dao, null) { sheet = null }
                sheet?.startsWith("account:") == true -> {
                    val id = sheet!!.removePrefix("account:").toLongOrNull() ?: 0L
                    var acc by remember { mutableStateOf<com.securemoney.manager.data.AccountEntity?>(null) }
                    var bal by remember { mutableStateOf(0L) }
                    LaunchedEffect(id) {
                        if (id != 0L) {
                            acc = dao.account(id)
                            bal = dao.allTransactionsOnce()
                                .filter { it.accountId == id && it.confirmed }
                                .sumOf { it.signedMinor } + (acc?.openingBalanceMinor ?: 0)
                        }
                    }
                    AccountEditorSheet(dao, acc, addAccountGroupId, bal) {
                        sheet = null; addAccountGroupId = null
                    }
                }
            }

            openPerson?.let { p ->
                PersonSheet(dao, p) { openPerson = null }
            }
        }
    }

    LaunchedEffect(initialRoute, dbOpen) {
        if (dbOpen && initialRoute != null) { route = initialRoute; onRouteConsumed() }
    }
}

private fun navIcon(key: String) = when (key) {
    "records" -> Icons.Default.Receipt
    "calendar" -> Icons.Default.CalendarMonth
    "accounts" -> Icons.Default.AccountBalance
    "people" -> Icons.Default.People
    "budgets" -> Icons.Default.PieChart
    "categories" -> Icons.Default.Label
    "tags" -> Icons.Default.Tag
    "review" -> Icons.Default.RateReview
    "settings" -> Icons.Default.Settings
    else -> Icons.Default.Circle
}

@Composable
private fun rememberLauncherIfAvailable() =
    androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

@Composable
private fun MoreSheet(
    settings: Settings, currentRoute: String,
    onPick: (String) -> Unit, onDismiss: () -> Unit
) {
    val extra = ALL_NAV.map { it.first }.filter { it !in settings.navTabs.take(settings.navCount) }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp, 0.dp, 20.dp, 32.dp)) {
            SheetHeader("More")
            extra.forEach { key ->
                val label = ALL_NAV.firstOrNull { it.first == key }?.second ?: key
                ActionRow(label) { onPick(key) }
            }
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            ActionRow("Settings") { onPick("settings") }
            ActionRow("Export") { onPick("export") }
        }
    }
}

@Composable
private fun ReacceptTerms(onAccept: () -> Unit) {
    var accepted by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Updated terms", fontSize = 20.sp)
        Spacer(Modifier.height(12.dp))
        Box(Modifier.weight(1f)) {
            androidx.compose.foundation.lazy.LazyColumn {
                item { Text(TERMS_TEXT, fontSize = 11.sp, lineHeight = 16.sp) }
            }
        }
        Row(Modifier.padding(top = 8.dp)) {
            Checkbox(accepted, { accepted = it })
            Text("I accept the updated terms", fontSize = 13.sp,
                modifier = Modifier.padding(top = 12.dp))
        }
        Button(onClick = onAccept, enabled = accepted, modifier = Modifier.fillMaxWidth()) {
            Text("Continue")
        }
    }
}
