package com.securemoney.manager.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.securemoney.manager.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * ══════════════════════════════════════════════════════════════════
 *  CALCULATOR ENTRY — fast manual add/edit, full screen
 * ══════════════════════════════════════════════════════════════════
 *
 * Mirrors a plain calculator: type digits and operators, hit "=" to
 * settle on a figure, then Save. This is deliberately a SEPARATE screen
 * from AddTransactionSheet (the sheet still handles tags/photo/person
 * for people who want those); this one is for "I spent 45 and 2.50 more,
 * just log it" without opening a keyboard.
 *
 * The expression engine is a tiny, self-contained one — no eval(), no
 * external library touching money math. It supports + − × ÷ with normal
 * left-to-right evaluation (no operator precedence, like a physical
 * calculator) and a single pending operator at a time, which is exactly
 * what the reference UI implies (press an operator, see the next number
 * start fresh, no parentheses).
 */

/** A tiny four-function calculator, decimal-string based (never Double). */
private class CalcState {
    var display by mutableStateOf("0")
    var accumulator: java.math.BigDecimal? = null
    var pendingOp: Char? = null
    var freshEntry = true
    var maxDecimals = 2

    fun setDecimals(d: Int) { maxDecimals = d }

    fun digit(d: String) {
        if (freshEntry) { display = if (d == ".") "0." else d; freshEntry = false }
        else {
            if (d == "." && display.contains(".")) return
            // Cap decimal places to the currency's own precision.
            val dotIdx = display.indexOf(".")
            if (dotIdx >= 0 && display.length - dotIdx - 1 >= maxDecimals && d != ".") return
            display = if (display == "0" && d != ".") d else display + d
        }
    }

    fun backspace() {
        display = if (display.length <= 1) "0" else display.dropLast(1)
        if (display.isEmpty()) display = "0"
    }

    fun clear() { display = "0"; accumulator = null; pendingOp = null; freshEntry = true }

    private fun currentValue(): java.math.BigDecimal =
        display.toBigDecimalOrNull() ?: java.math.BigDecimal.ZERO

    fun operator(op: Char) {
        val cur = currentValue()
        accumulator = when {
            accumulator == null -> cur
            !freshEntry -> applyPending(accumulator!!, cur)
            else -> accumulator // operator pressed twice in a row: just swap it
        }
        pendingOp = op
        freshEntry = true
    }

    private fun applyPending(a: java.math.BigDecimal, b: java.math.BigDecimal): java.math.BigDecimal =
        when (pendingOp) {
            '+' -> a + b
            '-' -> a - b
            '×' -> a * b
            '÷' -> if (b.signum() == 0) a else a.divide(b, maxDecimals, java.math.RoundingMode.HALF_UP)
            else -> b
        }

    fun equals() {
        val cur = currentValue()
        val result = if (accumulator != null && pendingOp != null) applyPending(accumulator!!, cur) else cur
        display = result.setScale(maxDecimals, java.math.RoundingMode.HALF_UP)
            .stripTrailingZerosSafe().toPlainString()
        accumulator = null; pendingOp = null; freshEntry = true
    }

    /** Result as minor units in the given currency, running "=" first if an operator is pending. */
    fun resultMinor(currency: String): Long? {
        if (pendingOp != null && !freshEntry) equals()
        return display.toMinor(currency)
    }
}

private fun java.math.BigDecimal.stripTrailingZerosSafe(): java.math.BigDecimal =
    if (this.compareTo(java.math.BigDecimal.ZERO) == 0) java.math.BigDecimal.ZERO else this

@Composable
fun CalculatorEntryScreen(
    dao: SmmDao,
    existing: TransactionEntity?,
    defaultAccountId: Long?,
    onDone: () -> Unit,
    onCancel: () -> Unit,
    onMoreOptions: (() -> Unit)? = null
) {
    val scope = rememberCoroutineScope()
    val accounts by dao.observeAccounts().collectAsStateWithLifecycle(emptyList())
    val cats by dao.observeCategories().collectAsStateWithLifecycle(emptyList())
    val groups by dao.observeGroups().collectAsStateWithLifecycle(emptyList())

    var kind by remember {
        mutableStateOf(
            when (existing?.kind) {
                TxKind.INCOME -> "INCOME"
                TxKind.TRANSFER_OUT, TxKind.TRANSFER_IN -> "TRANSFER"
                else -> "EXPENSE"
            }
        )
    }
    var accountId by remember { mutableStateOf(existing?.accountId ?: defaultAccountId) }
    var toAccountId by remember { mutableStateOf<Long?>(null) }   // only used for TRANSFER
    var categoryId by remember { mutableStateOf(existing?.categoryId) }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var occurredAt by remember { mutableLongStateOf(existing?.occurredAt ?: System.currentTimeMillis()) }
    var error by remember { mutableStateOf<String?>(null) }
    var showAccountPicker by remember { mutableStateOf(false) }
    var showCategoryPicker by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }
    var toPickerOpen by remember { mutableStateOf(false) }

    val account = accounts.firstOrNull { it.id == accountId }
    val currency = account?.currency ?: "USD"

    val calc = remember { CalcState() }
    LaunchedEffect(currency) { calc.setDecimals(Currencies.decimals(currency)) }
    // Seed the calculator with the existing amount when editing.
    LaunchedEffect(existing?.id) {
        existing?.let {
            calc.display = it.amountMinor.format(it.currency, withCode = false).replace(",", "")
        }
    }

    val dateFmt = remember { SimpleDateFormat("MMM dd, yyyy", Locale.US) }
    val timeFmt = remember { SimpleDateFormat("h:mm a", Locale.US) }

    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {

            /* ── Top bar: cancel / save ── */
            Row(
                Modifier.fillMaxWidth().padding(20.dp, 16.dp, 20.dp, 6.dp),
                Arrangement.SpaceBetween, Alignment.CenterVertically
            ) {
                TextButton(onCancel) {
                    Icon(Icons.Default.Close, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Cancel", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                }
                TextButton(onClick = {
                    val minor = calc.resultMinor(currency)
                    when {
                        minor == null || minor <= 0L -> error = "Enter an amount above zero."
                        accountId == null -> error = "Choose an account."
                        kind == "TRANSFER" && toAccountId == null -> error = "Choose the destination account."
                        kind == "TRANSFER" && toAccountId == accountId -> error = "Pick two different accounts."
                        else -> scope.launch {
                            val acc = accounts.first { it.id == accountId }
                            when (kind) {
                                "TRANSFER" -> {
                                    val to = accounts.first { it.id == toAccountId }
                                    // Cross-currency transfer here uses the same
                                    // typed figure on both sides only when the
                                    // currencies match; otherwise send the user
                                    // to the dedicated Transfer sheet, which asks
                                    // for both amounts properly.
                                    if (acc.currency == to.currency) {
                                        dao.insertTransfer(acc, to, minor, minor, note.trim(), occurredAt)
                                        onDone()
                                    } else {
                                        error = "Cross-currency transfers need both amounts — use Transfer from Accounts instead."
                                    }
                                }
                                else -> {
                                    val row = TransactionEntity(
                                        id = existing?.id ?: 0,
                                        merchant = note.trim().ifBlank {
                                            if (kind == "INCOME") "Income" else "Expense"
                                        },
                                        note = "",
                                        amountMinor = minor,
                                        currency = acc.currency,
                                        kind = if (kind == "INCOME") TxKind.INCOME else TxKind.EXPENSE,
                                        accountId = acc.id,
                                        categoryId = categoryId,
                                        occurredAt = occurredAt,
                                        source = existing?.source ?: "MANUAL",
                                        confirmed = true
                                    )
                                    if (existing == null) dao.insert(row) else dao.update(row)
                                    onDone()
                                }
                            }
                        }
                    }
                }) {
                    Icon(Icons.Default.Check, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Save", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                }
            }

            /* ── Kind switch ── */
            Row(
                Modifier.fillMaxWidth().padding(20.dp, 4.dp, 20.dp, 10.dp),
                Arrangement.Center
            ) {
                listOf("INCOME" to "Income", "EXPENSE" to "Expense", "TRANSFER" to "Transfer")
                    .forEachIndexed { i, (key, label) ->
                        if (i > 0) Text(" | ", color = MaterialTheme.colorScheme.outline)
                        Row(
                            Modifier.clickable { kind = key; categoryId = null },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (kind == key) {
                                Icon(Icons.Default.CheckCircle, null, Modifier.size(16.dp),
                                    tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(4.dp))
                            }
                            Text(
                                label.uppercase(), fontSize = 13.sp,
                                fontWeight = if (kind == key) FontWeight.Bold else FontWeight.Normal,
                                color = if (kind == key) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
            }

            /* ── Account / Category (or Account / To-account for transfer) ── */
            Row(Modifier.fillMaxWidth().padding(20.dp, 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PickerField(
                    label = "Account",
                    value = account?.let { "${it.name} · ${it.currency}" },
                    icon = Icons.Default.AccountBalanceWallet,
                    modifier = Modifier.weight(1f)
                ) { showAccountPicker = true }

                if (kind == "TRANSFER") {
                    val to = accounts.firstOrNull { it.id == toAccountId }
                    PickerField(
                        label = "To account",
                        value = to?.let { "${it.name} · ${it.currency}" },
                        icon = Icons.Default.SwapHoriz,
                        modifier = Modifier.weight(1f)
                    ) { showAccountPicker = false; showCategoryPicker = false
                        // Reuse the account picker in "to" mode via a flag stored in state below.
                        toPickerOpen = true
                    }
                } else {
                    val c = cats.firstOrNull { it.id == categoryId }
                    PickerField(
                        label = "Category",
                        value = c?.let { "${it.icon} ${it.name}" },
                        icon = Icons.Default.Sell,
                        modifier = Modifier.weight(1f)
                    ) { showCategoryPicker = true }
                }
            }

            /* ── Note ── */
            OutlinedTextField(
                value = note, onValueChange = { note = it },
                placeholder = { Text("Add notes", fontSize = 13.sp) },
                modifier = Modifier.fillMaxWidth().weight(1f, fill = false)
                    .padding(20.dp, 10.dp).heightIn(min = 90.dp)
            )

            error?.let {
                Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(20.dp, 0.dp))
            }

            /* ── Amount display ── */
            Surface(
                Modifier.fillMaxWidth().padding(20.dp, 8.dp),
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(20.dp, 22.dp),
                    Arrangement.End, Alignment.CenterVertically
                ) {
                    Text(
                        calc.display, fontSize = 44.sp, fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Light, maxLines = 1,
                        modifier = Modifier.weight(1f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.End
                    )
                    Spacer(Modifier.width(14.dp))
                    IconButton({ calc.backspace() }) {
                        Icon(Icons.Default.Backspace, "Backspace")
                    }
                }
            }

            /* ── Keypad ── */
            CalculatorKeypad(
                onDigit = { calc.digit(it) },
                onOp = { calc.operator(it) },
                onEquals = { calc.equals() }
            )

            /* ── Date / time ── */
            Row(
                Modifier.fillMaxWidth().padding(20.dp, 12.dp, 20.dp, 8.dp),
                Arrangement.Center, Alignment.CenterVertically
            ) {
                TextButton({ showDatePicker = true }) {
                    Text(dateFmt.format(Date(occurredAt)), fontSize = 14.sp)
                }
                Text(" | ", color = MaterialTheme.colorScheme.outline)
                TextButton({ showTimePicker = true }) {
                    Text(timeFmt.format(Date(occurredAt)), fontSize = 14.sp)
                }
            }

            // Tags, receipt photo and lending-to-a-person live in the detailed
            // sheet — kept off this screen so fast entry stays fast.
            onMoreOptions?.let { more ->
                TextButton(
                    onClick = more,
                    modifier = Modifier.fillMaxWidth().padding(20.dp, 0.dp, 20.dp, 20.dp)
                ) {
                    Text("Tags, photo, or lending to someone…", fontSize = 12.sp)
                }
            }
            if (onMoreOptions == null) Spacer(Modifier.height(20.dp))
        }
    }

    /* ── Account picker (shared for "from" and "to") ── */
    if (showAccountPicker || toPickerOpen) {
        ModalBottomSheet(onDismissRequest = { showAccountPicker = false; toPickerOpen = false }) {
            Column(Modifier.padding(20.dp, 0.dp, 20.dp, 24.dp)) {
                SheetHeader(if (toPickerOpen) "Transfer to" else "Choose account")
                groups.forEach { g ->
                    val inGroup = accounts.filter { it.groupId == g.id }
                    if (inGroup.isEmpty()) return@forEach
                    Text("${g.icon} ${g.name}", fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
                    inGroup.forEach { a ->
                        ListItem(
                            modifier = Modifier.clickable {
                                if (toPickerOpen) toAccountId = a.id else accountId = a.id
                                showAccountPicker = false; toPickerOpen = false
                            },
                            leadingContent = { IconBadge(a.icon, a.colorHex, 36) },
                            headlineContent = { Text(a.name, fontSize = 14.sp) },
                            supportingContent = { Text(a.currency, fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace) }
                        )
                    }
                }
            }
        }
    }

    /* ── Category picker ── */
    if (showCategoryPicker) {
        ModalBottomSheet(onDismissRequest = { showCategoryPicker = false }) {
            Column(Modifier.padding(20.dp, 0.dp, 20.dp, 24.dp)) {
                SheetHeader("Choose category")
                cats.filter { it.isExpense == (kind == "EXPENSE") }.forEach { c ->
                    ListItem(
                        modifier = Modifier.clickable { categoryId = c.id; showCategoryPicker = false },
                        leadingContent = { IconBadge(c.icon, c.colorHex, 36) },
                        headlineContent = { Text(c.name, fontSize = 14.sp) }
                    )
                }
            }
        }
    }

    /* ── Date picker ── */
    if (showDatePicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = occurredAt)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton({
                    state.selectedDateMillis?.let { pickedUtcMidnight ->
                        // Keep the existing time-of-day, only replace the date part.
                        val old = Calendar.getInstance().apply { timeInMillis = occurredAt }
                        val picked = Calendar.getInstance().apply {
                            timeInMillis = pickedUtcMidnight
                            set(Calendar.HOUR_OF_DAY, old.get(Calendar.HOUR_OF_DAY))
                            set(Calendar.MINUTE, old.get(Calendar.MINUTE))
                        }
                        occurredAt = picked.timeInMillis
                    }
                    showDatePicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton({ showDatePicker = false }) { Text("Cancel") } }
        ) { DatePicker(state = state) }
    }

    /* ── Time picker ── */
    if (showTimePicker) {
        val cal = Calendar.getInstance().apply { timeInMillis = occurredAt }
        val state = rememberTimePickerState(
            initialHour = cal.get(Calendar.HOUR_OF_DAY),
            initialMinute = cal.get(Calendar.MINUTE)
        )
        AlertDialog(
            onDismissRequest = { showTimePicker = false },
            confirmButton = {
                TextButton({
                    val picked = Calendar.getInstance().apply {
                        timeInMillis = occurredAt
                        set(Calendar.HOUR_OF_DAY, state.hour)
                        set(Calendar.MINUTE, state.minute)
                    }
                    occurredAt = picked.timeInMillis
                    showTimePicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton({ showTimePicker = false }) { Text("Cancel") } },
            text = { TimePicker(state = state) }
        )
    }
}

@Composable
private fun PickerField(
    label: String,
    value: String?,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(modifier) {
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 4.dp))
        OutlinedButton(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(12.dp)
        ) {
            Icon(icon, null, Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                value ?: label, fontSize = 13.sp, maxLines = 1,
                color = if (value == null) MaterialTheme.colorScheme.onSurfaceVariant
                        else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun CalculatorKeypad(
    onDigit: (String) -> Unit,
    onOp: (Char) -> Unit,
    onEquals: () -> Unit
) {
    val rows = listOf(
        listOf("+" to Op.OPERATOR, "7" to Op.DIGIT, "8" to Op.DIGIT, "9" to Op.DIGIT),
        listOf("-" to Op.OPERATOR, "4" to Op.DIGIT, "5" to Op.DIGIT, "6" to Op.DIGIT),
        listOf("×" to Op.OPERATOR, "1" to Op.DIGIT, "2" to Op.DIGIT, "3" to Op.DIGIT),
        listOf("÷" to Op.OPERATOR, "0" to Op.DIGIT, "." to Op.DIGIT, "=" to Op.EQUALS)
    )
    Column(Modifier.fillMaxWidth().padding(2.dp)) {
        rows.forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { (label, type) ->
                    val bg = when (type) {
                        Op.OPERATOR, Op.EQUALS -> MaterialTheme.colorScheme.primaryContainer
                        Op.DIGIT -> MaterialTheme.colorScheme.surfaceVariant
                    }
                    Box(
                        Modifier.weight(1f).aspectRatio(1.6f).padding(3.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(bg)
                            .clickable {
                                when (type) {
                                    Op.DIGIT -> onDigit(label)
                                    Op.OPERATOR -> onOp(label[0])
                                    Op.EQUALS -> onEquals()
                                }
                            },
                        Alignment.Center
                    ) {
                        Text(label, fontSize = 22.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

private enum class Op { DIGIT, OPERATOR, EQUALS }
