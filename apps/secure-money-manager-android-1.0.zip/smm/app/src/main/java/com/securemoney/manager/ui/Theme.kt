package com.securemoney.manager.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/* ── EDIT COLOURS HERE. Nothing is hardcoded in the screens. ── */
val Brass        = Color(0xFFC9A661)
val BrassLight   = Color(0xFF8A6D2F)
val InflowDark   = Color(0xFF6FBF8E)   // green — money in
val InflowLight  = Color(0xFF2A7D50)
val OutflowDark  = Color(0xFFD9707D)   // red — money out
val OutflowLight = Color(0xFFB03D4E)
val CashDark     = Color(0xFFE3C25F)   // yellow — cash
val CashLight    = Color(0xFF9A7B1E)
val NeutralDark  = Color(0xFF8A93A6)
val NeutralLight = Color(0xFF6E6759)

private val DarkScheme = darkColorScheme(
    primary = Brass, onPrimary = Color(0xFF14161C),
    primaryContainer = Color(0xFF2A2416), onPrimaryContainer = Brass,
    secondary = Color(0xFF8A93A6),
    background = Color(0xFF0F1116), onBackground = Color(0xFFEDEFF4),
    surface = Color(0xFF191C24), onSurface = Color(0xFFEDEFF4),
    surfaceVariant = Color(0xFF20242E), onSurfaceVariant = Color(0xFF9AA3B4),
    outline = Color(0xFF343A48), outlineVariant = Color(0xFF262B36),
    error = OutflowDark, onError = Color(0xFF14161C),
    errorContainer = Color(0xFF3A1F24), onErrorContainer = Color(0xFFFFD8DD)
)

private val LightScheme = lightColorScheme(
    primary = BrassLight, onPrimary = Color.White,
    primaryContainer = Color(0xFFF2E8D2), onPrimaryContainer = Color(0xFF4A3A12),
    secondary = Color(0xFF6E6759),
    background = Color(0xFFF7F5F0), onBackground = Color(0xFF1C1A16),
    surface = Color.White, onSurface = Color(0xFF1C1A16),
    surfaceVariant = Color(0xFFEDE8DE), onSurfaceVariant = Color(0xFF6E6759),
    outline = Color(0xFFD6CFC1), outlineVariant = Color(0xFFE6E0D4),
    error = OutflowLight, onError = Color.White,
    errorContainer = Color(0xFFFBE3E6), onErrorContainer = Color(0xFF5C1A24)
)

/** True when the active scheme is dark. Lets money colours pick a variant. */
val LocalIsDark = staticCompositionLocalOf { true }

/** [mode] is "dark", "light" or "system". Changed only in Settings. */
@Composable
fun SmmTheme(mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    CompositionLocalProvider(LocalIsDark provides dark) {
        MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, content = content)
    }
}

@Composable fun inflow(): Color = if (LocalIsDark.current) InflowDark else InflowLight
@Composable fun outflow(): Color = if (LocalIsDark.current) OutflowDark else OutflowLight
@Composable fun cash(): Color = if (LocalIsDark.current) CashDark else CashLight
@Composable fun neutral(): Color = if (LocalIsDark.current) NeutralDark else NeutralLight

/** Parse "#RRGGBB" safely — a bad stored value must not crash a list row. */
fun String.toColorOr(fallback: Color = Brass): Color = runCatching {
    Color(android.graphics.Color.parseColor(this))
}.getOrDefault(fallback)
