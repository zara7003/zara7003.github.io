package com.securemoney.manager.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * ── ADDING A FIELD ──────────────────────────────────────────────────
 * 1. Add it here WITH A DEFAULT VALUE.
 * 2. Bump DB_VERSION in AppDatabase.kt.
 * 3. Add a Migration with the ALTER TABLE.
 * Destructive migration is deliberately disabled, so a forgotten
 * migration crashes loudly instead of deleting anyone's history.
 */

/* ══════════════════════════════════════════════════════════════════
 *  GROUPS — organisational, not arithmetic
 * ══════════════════════════════════════════════════════════════════
 *  A group is however you want accounts sorted: "Qatar", "India",
 *  "France", "Business", "Travel". It is NOT the same axis as currency.
 *  A group may hold accounts in several currencies — a USD account at a
 *  Qatari bank belongs to Qatar but sums with USD.
 */
@Entity(tableName = "groups")
data class GroupEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    /** Emoji flag or icon. Purely cosmetic. */
    val icon: String = "\uD83C\uDF10",
    val colorHex: String = "#5B8CB8",
    /** Pre-selected when adding an account here. Accounts may differ. */
    val defaultCurrency: String = "USD",
    val sortOrder: Int = 0,
    val archived: Boolean = false
)

@Entity(tableName = "accounts", indices = [Index("groupId"), Index("currency")])
data class AccountEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val groupId: Long,
    /** The arithmetic axis. Never mixed with another currency. */
    val currency: String,
    val type: String = "BANK",       // BANK | CASH | CARD | CREDIT | SAVINGS | WALLET | LOAN
    val openingBalanceMinor: Long = 0,
    val colorHex: String = "#5B8CB8",
    val icon: String = "\uD83C\uDFE6",
    /** Optional last 3–4 digits, used to match bank SMS to this account. */
    val accountDigits: String = "",
    val note: String = "",
    val archived: Boolean = false,
    val sortOrder: Int = 0
) {
    companion object {
        val TYPES = listOf(
            "BANK" to "\uD83C\uDFE6", "CASH" to "\uD83D\uDCB5",
            "CARD" to "\uD83D\uDCB3", "CREDIT" to "\uD83D\uDCC9",
            "SAVINGS" to "\uD83D\uDC8E", "WALLET" to "\uD83D\uDCF1",
            "LOAN" to "\uD83E\uDDFE"
        )
        /** Credit and loan accounts normally carry a negative balance. */
        fun isLiability(type: String) = type == "CREDIT" || type == "LOAN"
    }
}

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val isExpense: Boolean = true,
    val icon: String = "\u2754",
    val colorHex: String = "#8A93A6",
    val parentId: Long? = null,
    val archived: Boolean = false,
    val sortOrder: Int = 0
)

/**
 * Budgets are PER CATEGORY PER CURRENCY.
 * "Groceries" can hold a QAR 800 cap and an INR 15,000 cap at once,
 * tracked entirely separately, with no interaction between them.
 */
@Entity(
    tableName = "budgets",
    indices = [Index(value = ["categoryId", "currency"], unique = true)]
)
data class BudgetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val categoryId: Long,
    val currency: String,
    val monthlyLimitMinor: Long,
    val rollover: Boolean = false
)

@Entity(tableName = "tags", indices = [Index(value = ["name"], unique = true)])
data class TagEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val colorHex: String = "#8A93A6"
)

@Entity(
    tableName = "transaction_tags",
    primaryKeys = ["transactionId", "tagId"],
    indices = [Index("tagId")]
)
data class TransactionTagCrossRef(val transactionId: Long, val tagId: Long)

/* ══════════════════════════════════════════════════════════════════
 *  PEOPLE
 * ══════════════════════════════════════════════════════════════════ */
@Entity(tableName = "people")
data class PersonEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val colorHex: String = "#B07AA1",
    val relationship: String = "",
    val smsAliases: String = "",
    val autoMatchSms: Boolean = false,
    /** Recurring support amount, 0 = none. Has its own currency. */
    val allowanceMinor: Long = 0,
    val allowanceCurrency: String = "USD",
    val allowanceDayOfMonth: Int = 1,
    val defaultAbsorbCategoryId: Long? = null,
    val archived: Boolean = false
)

/**
 * ══════════════════════════════════════════════════════════════════
 *  TRANSACTION KINDS
 * ══════════════════════════════════════════════════════════════════
 *  EXPENSE / INCOME   ordinary money out / in
 *  TRANSFER_OUT       leaves one account, paired with a TRANSFER_IN
 *  TRANSFER_IN        arrives in the other account
 *  ADJUSTMENT         reconciliation against the real bank balance
 *
 *  Transfers are budget-neutral: moving your own money between your own
 *  accounts is not spending, and must never appear as such.
 */
object TxKind {
    const val EXPENSE = "EXPENSE"
    const val INCOME = "INCOME"
    const val TRANSFER_OUT = "TRANSFER_OUT"
    const val TRANSFER_IN = "TRANSFER_IN"
    const val ADJUSTMENT = "ADJUSTMENT"

    val TRANSFERS = setOf(TRANSFER_OUT, TRANSFER_IN)
    fun reducesAccount(kind: String) = kind == EXPENSE || kind == TRANSFER_OUT
}

/**
 * ══════════════════════════════════════════════════════════════════
 *  PERSON ENTRY TYPES
 * ══════════════════════════════════════════════════════════════════
 *  ADVANCE          paid_for       spent on their behalf → they owe you
 *                   received_for   holding their money   → you owe them
 *  CASH SETTLEMENT  settle_in      they repaid you
 *                   settle_out     you repaid them
 *  NON-CASH         absorbed       you gave up on it; becomes YOUR expense
 *                   offset_support cancels against the recurring support you
 *                                  owe them, so you skip that transfer
 *  OBLIGATION       support_paid   the recurring payment itself
 */
object PersonEntryType {
    const val PAID_FOR = "paid_for"
    const val RECEIVED_FOR = "received_for"
    const val SETTLE_IN = "settle_in"
    const val SETTLE_OUT = "settle_out"
    const val ABSORBED = "absorbed"
    const val OFFSET_SUPPORT = "offset_support"
    const val SUPPORT_PAID = "support_paid"

    /** Your own money, not a claim on anyone. */
    val PERSONAL_COST = setOf(ABSORBED, OFFSET_SUPPORT, SUPPORT_PAID)
    /** Satisfies a recurring support obligation. */
    val SATISFIES_SUPPORT = setOf(SUPPORT_PAID, OFFSET_SUPPORT)
    /** Still awaiting resolution. */
    val OPEN_CLAIM = setOf(PAID_FOR, RECEIVED_FOR)

    fun label(t: String?): String = when (t) {
        PAID_FOR -> "I paid for them"
        RECEIVED_FOR -> "I'm holding their money"
        SETTLE_IN -> "They paid me back"
        SETTLE_OUT -> "I paid them back"
        ABSORBED -> "Absorbed as my own cost"
        OFFSET_SUPPORT -> "Offset against support"
        SUPPORT_PAID -> "Support paid"
        else -> "—"
    }
}

@Entity(
    tableName = "transactions",
    indices = [Index("accountId"), Index("categoryId"), Index("personId"),
               Index("occurredAt"), Index("transferPairId"), Index("supportPeriod"),
               Index("confirmed")]
)
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val merchant: String,
    val note: String = "",

    /** POSITIVE minor units, in [currency]. Direction comes from [kind]. */
    val amountMinor: Long,
    /** Denormalised from the account so a currency change can't rewrite history. */
    val currency: String,

    val kind: String = TxKind.EXPENSE,
    val accountId: Long,
    val categoryId: Long? = null,

    /** Links the two halves of a transfer. Same value on both rows. */
    val transferPairId: String? = null,

    val personId: Long? = null,
    val personEntryType: String? = null,
    val settlesTransactionId: Long? = null,
    /** "2026-08" on support_paid / offset_support rows. */
    val supportPeriod: String? = null,

    /* ── Frozen cross-currency rate ────────────────────────────────
     * Set ONLY when a settlement crosses currencies (an INR advance
     * offset against a QAR obligation, or a QAR→INR remittance).
     * Stores what the user decided at that moment, permanently. It is
     * never recalculated, so it cannot drift.
     */
    val fxCounterCurrency: String? = null,
    val fxCounterMinor: Long? = null,
    val fxRateUsed: Double? = null,

    val source: String = "MANUAL",   // MANUAL | SMS | NOTIFICATION | IMPORT | ADJUSTMENT
    val rawMessage: String? = null,
    val photoUri: String? = null,
    val occurredAt: Long,
    val createdAt: Long = System.currentTimeMillis(),
    /** false = parsed, sitting in the Review queue awaiting your OK. */
    val confirmed: Boolean = true
) {
    /**
     * Does this count as YOUR spending?
     * No for transfers (your own money moving), no for adjustments, no for
     * an OPEN advance (you expect it back). Yes for a plain expense, and
     * yes once an advance is absorbed.
     */
    val countsAsSpend: Boolean
        get() = kind == TxKind.EXPENSE && confirmed &&
            (personId == null || personEntryType in PersonEntryType.PERSONAL_COST)

    val countsAsIncome: Boolean
        get() = kind == TxKind.INCOME && confirmed && personId == null

    /** Signed effect on the account balance. */
    val signedMinor: Long
        get() = if (TxKind.reducesAccount(kind)) -amountMinor else amountMinor
}

/* ══════════════════════════════════════════════════════════════════
 *  EXCHANGE RATES — owned by the user, never fetched
 * ══════════════════════════════════════════════════════════════════
 *  The app has no INTERNET permission and cannot look a rate up. These
 *  are only ever a convenience: a starting number pre-filled when a
 *  cross-currency settlement asks you to confirm one. Nothing in the
 *  app converts balances or totals using them.
 *
 *  Seeded values are INDICATIVE and marked as never user-set, so the UI
 *  can nag until you replace them with a real one.
 */
@Entity(
    tableName = "fx_rates",
    indices = [Index(value = ["fromCurrency", "toCurrency"], unique = true)]
)
data class FxRateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fromCurrency: String,
    val toCurrency: String,
    /** 1 unit of `from` equals this many `to`. */
    val rate: Double,
    /** null = shipped placeholder, never confirmed by the user. */
    val setByUserAt: Long? = null,
    val note: String = ""
) {
    val isIndicative: Boolean get() = setByUserAt == null
}

/* ══════════════════════════════════════════════════════════════════
 *  CAPTURE ALLOWLISTS — nothing is read unless it is listed here
 * ══════════════════════════════════════════════════════════════════ */
@Entity(tableName = "sms_senders", indices = [Index(value = ["sender"], unique = true)])
data class SmsSenderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String,
    val label: String = "",
    val defaultAccountId: Long? = null,
    val smsRuleId: Long? = null,
    val enabled: Boolean = true,
    val lastSeenAt: Long? = null,
    val messageCount: Int = 0
)

@Entity(tableName = "notif_apps", indices = [Index(value = ["packageName"], unique = true)])
data class NotifAppEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val appLabel: String = "",
    val defaultAccountId: Long? = null,
    val enabled: Boolean = true,
    val lastSeenAt: Long? = null,
    val messageCount: Int = 0
)

/**
 * A sender the app noticed but you have not approved.
 * Only the identifier and a count are kept — message bodies from
 * unapproved senders are never opened or stored.
 */
@Entity(
    tableName = "capture_candidates",
    indices = [Index(value = ["source", "identifier"], unique = true)]
)
data class CaptureCandidateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val source: String,
    val identifier: String,
    val displayLabel: String = "",
    val seenCount: Int = 1,
    val firstSeenAt: Long = System.currentTimeMillis(),
    val lastSeenAt: Long = System.currentTimeMillis(),
    val dismissed: Boolean = false
)

@Entity(tableName = "sms_rules")
data class SmsRuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val label: String,
    val senderPattern: String = ".*",
    val bodyMustContain: String = "",
    val amountRegex: String = """(?:[A-Z]{3}|Rs\.?|₹|\$|€|£)\s*([\d,]+(?:\.\d{1,3})?)""",
    val merchantRegex: String = """(?:at|to|from|via)\s+([A-Za-z0-9&'\-. ]{2,40})""",
    val accountHintRegex: String = """(?:a/c|card|acct|account)[^\d]{0,8}(\d{3,4})""",
    val treatAsExpense: Boolean = true,
    val enabled: Boolean = true,
    val priority: Int = 0
)

/**
 * Learned corrections. When you fix the account or category on a parsed
 * entry, the app remembers, so the Review queue shrinks over time instead
 * of asking the same question forever.
 */
@Entity(
    tableName = "learned_rules",
    indices = [Index(value = ["scope", "matchKey"], unique = true)]
)
data class LearnedRuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** MERCHANT_CATEGORY | SENDER_ACCOUNT | MERCHANT_ACCOUNT | MERCHANT_PERSON */
    val scope: String,
    val matchKey: String,
    val targetId: Long,
    val hitCount: Int = 1,
    val lastUsedAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val MERCHANT_CATEGORY = "MERCHANT_CATEGORY"
        const val SENDER_ACCOUNT = "SENDER_ACCOUNT"
        const val MERCHANT_ACCOUNT = "MERCHANT_ACCOUNT"
        const val MERCHANT_PERSON = "MERCHANT_PERSON"
        /** Stop asking once a correction has held this many times. */
        const val AUTO_APPLY_THRESHOLD = 2
    }
}

/* ══════════════════════════════════════════════════════════════════
 *  REMINDERS — opt-in, user-authored
 * ══════════════════════════════════════════════════════════════════ */
@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val message: String,
    val frequency: String = "WEEKLY",
    val hour: Int = 20,
    val minute: Int = 0,
    val daysOfWeek: String = "",
    val dayOfMonth: Int = 1,
    /** NONE | RECORDS | ACCOUNTS | PEOPLE | REVIEW | EXPORT */
    val action: String = "NONE",
    val enabled: Boolean = false,
    val lastFiredAt: Long? = null
) {
    companion object {
        val FREQUENCIES = listOf(
            "DAILY" to "Every day",
            "EVERY_2_DAYS" to "Every two days",
            "WEEKLY" to "Weekly",
            "BIWEEKLY" to "Every two weeks",
            "MONTHLY" to "Monthly"
        )
        val ACTIONS = listOf(
            "NONE" to "Just the reminder",
            "RECORDS" to "Open Records",
            "REVIEW" to "Open Review queue",
            "ACCOUNTS" to "Open Accounts",
            "PEOPLE" to "Open People",
            "EXPORT" to "Open Export screen"
        )
        /** Offered on first run, all disabled. Nothing fires unless switched on. */
        fun templates() = listOf(
            ReminderEntity(
                title = "Log today's spending",
                message = "Any cash spends to add before the day closes?",
                frequency = "DAILY", hour = 21, action = "RECORDS"
            ),
            ReminderEntity(
                title = "Review pending entries",
                message = "Confirm anything waiting in your Review queue.",
                frequency = "EVERY_2_DAYS", hour = 19, action = "REVIEW"
            ),
            ReminderEntity(
                title = "Check account balances",
                message = "Compare against your bank and reconcile any difference.",
                frequency = "WEEKLY", hour = 10, daysOfWeek = "7", action = "ACCOUNTS"
            ),
            ReminderEntity(
                title = "Export a backup",
                message = "Save a copy of your ledger somewhere safe.",
                frequency = "WEEKLY", hour = 22, daysOfWeek = "1", action = "EXPORT"
            ),
            ReminderEntity(
                title = "Settle up with people",
                message = "Review who owes you and what you owe.",
                frequency = "MONTHLY", hour = 19, dayOfMonth = 28, action = "PEOPLE"
            )
        )
    }
}

@Entity(tableName = "event_log")
data class EventLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val at: Long = System.currentTimeMillis(),
    val level: String = "INFO",
    val tag: String,
    val message: String
)
