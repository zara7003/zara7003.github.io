package com.securemoney.manager.io

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.securemoney.manager.data.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * ══════════════════════════════════════════════════════════════════
 *  EXPORT — always manual, always to a file you then hand somewhere
 * ══════════════════════════════════════════════════════════════════
 *
 * The app has NO INTERNET permission, so it cannot upload, email or sync
 * anything itself. Export writes a file into the app's own directory and
 * offers it to the Android share sheet. Whatever you pick from there —
 * Gmail, WhatsApp, Drive, Nextcloud — does the sending, under its own
 * permissions, not ours.
 *
 * Formats:
 *   .json  full fidelity, the only one that can be imported back
 *   .csv   for Excel, Sheets, Numbers
 *   .xlsx  a real multi-sheet workbook, written without any library
 *   .smmz  encrypted archive (AES-256-GCM, PBKDF2 210k)
 */
object ExportManager {

    const val SCHEMA = 1
    private const val AUTHORITY_SUFFIX = ".fileprovider"

    /** App-private, no storage permission needed on any Android version. */
    fun exportDir(ctx: Context): File =
        File(ctx.filesDir, "exports").apply { if (!exists()) mkdirs() }

    private fun stamp() = SimpleDateFormat("yyyy-MM-dd-HHmm", Locale.US).format(Date())

    /** Atomic write: .tmp then rename, so a killed process leaves no half file. */
    private fun writeAtomic(target: File, body: (File) -> Unit): File {
        val tmp = File(target.absolutePath + ".tmp")
        body(tmp)
        if (target.exists()) target.delete()
        tmp.renameTo(target)
        return target
    }

    /* ══════════════════ JSON (full fidelity) ══════════════════ */
    suspend fun buildJson(dao: SmmDao): String {
        val root = JSONObject().apply {
            put("app", "Secure Money Manager")
            put("schema", SCHEMA)
            put("exportedAt", System.currentTimeMillis())

            put("groups", JSONArray().also { arr ->
                dao.allGroupsOnce().forEach { g ->
                    arr.put(JSONObject().apply {
                        put("id", g.id); put("name", g.name); put("icon", g.icon)
                        put("colorHex", g.colorHex); put("defaultCurrency", g.defaultCurrency)
                        put("sortOrder", g.sortOrder); put("archived", g.archived)
                    })
                }
            })

            put("accounts", JSONArray().also { arr ->
                dao.allAccountsOnce().forEach { a ->
                    arr.put(JSONObject().apply {
                        put("id", a.id); put("name", a.name); put("groupId", a.groupId)
                        put("currency", a.currency); put("type", a.type)
                        put("openingBalanceMinor", a.openingBalanceMinor)
                        put("colorHex", a.colorHex); put("icon", a.icon)
                        put("accountDigits", a.accountDigits); put("note", a.note)
                        put("archived", a.archived); put("sortOrder", a.sortOrder)
                    })
                }
            })

            put("categories", JSONArray().also { arr ->
                dao.allCategoriesOnce().forEach { c ->
                    arr.put(JSONObject().apply {
                        put("id", c.id); put("name", c.name); put("isExpense", c.isExpense)
                        put("icon", c.icon); put("colorHex", c.colorHex)
                        put("parentId", c.parentId ?: JSONObject.NULL)
                        put("archived", c.archived); put("sortOrder", c.sortOrder)
                    })
                }
            })

            put("budgets", JSONArray().also { arr ->
                dao.allBudgetsOnce().forEach { b ->
                    arr.put(JSONObject().apply {
                        put("categoryId", b.categoryId); put("currency", b.currency)
                        put("monthlyLimitMinor", b.monthlyLimitMinor); put("rollover", b.rollover)
                    })
                }
            })

            put("people", JSONArray().also { arr ->
                dao.allPeopleOnce().forEach { p ->
                    arr.put(JSONObject().apply {
                        put("id", p.id); put("name", p.name); put("colorHex", p.colorHex)
                        put("relationship", p.relationship); put("smsAliases", p.smsAliases)
                        put("autoMatchSms", p.autoMatchSms)
                        put("allowanceMinor", p.allowanceMinor)
                        put("allowanceCurrency", p.allowanceCurrency)
                        put("allowanceDayOfMonth", p.allowanceDayOfMonth)
                        put("defaultAbsorbCategoryId", p.defaultAbsorbCategoryId ?: JSONObject.NULL)
                        put("archived", p.archived)
                    })
                }
            })

            put("tags", JSONArray().also { arr ->
                dao.allTagsOnce().forEach { t ->
                    arr.put(JSONObject().apply {
                        put("id", t.id); put("name", t.name); put("colorHex", t.colorHex)
                    })
                }
            })

            put("transactions", JSONArray().also { arr ->
                dao.allTransactionsOnce().forEach { t ->
                    arr.put(JSONObject().apply {
                        put("id", t.id); put("merchant", t.merchant); put("note", t.note)
                        put("amountMinor", t.amountMinor); put("currency", t.currency)
                        put("kind", t.kind); put("accountId", t.accountId)
                        put("categoryId", t.categoryId ?: JSONObject.NULL)
                        put("transferPairId", t.transferPairId ?: JSONObject.NULL)
                        put("personId", t.personId ?: JSONObject.NULL)
                        put("personEntryType", t.personEntryType ?: JSONObject.NULL)
                        put("settlesTransactionId", t.settlesTransactionId ?: JSONObject.NULL)
                        put("supportPeriod", t.supportPeriod ?: JSONObject.NULL)
                        put("fxCounterCurrency", t.fxCounterCurrency ?: JSONObject.NULL)
                        put("fxCounterMinor", t.fxCounterMinor ?: JSONObject.NULL)
                        put("fxRateUsed", t.fxRateUsed ?: JSONObject.NULL)
                        put("source", t.source); put("photoUri", t.photoUri ?: JSONObject.NULL)
                        put("occurredAt", t.occurredAt); put("createdAt", t.createdAt)
                        put("confirmed", t.confirmed)
                    })
                }
            })

            put("transactionTags", JSONArray().also { arr ->
                dao.allTagLinksOnce().forEach { r ->
                    arr.put(JSONObject().apply {
                        put("transactionId", r.transactionId); put("tagId", r.tagId)
                    })
                }
            })

            put("fxRates", JSONArray().also { arr ->
                dao.allRatesOnce().forEach { r ->
                    arr.put(JSONObject().apply {
                        put("fromCurrency", r.fromCurrency); put("toCurrency", r.toCurrency)
                        put("rate", r.rate); put("setByUserAt", r.setByUserAt ?: JSONObject.NULL)
                        put("note", r.note)
                    })
                }
            })

            put("learnedRules", JSONArray().also { arr ->
                dao.allLearnedOnce().forEach { r ->
                    arr.put(JSONObject().apply {
                        put("scope", r.scope); put("matchKey", r.matchKey)
                        put("targetId", r.targetId); put("hitCount", r.hitCount)
                    })
                }
            })

            put("smsSenders", JSONArray().also { arr ->
                dao.allSendersOnce().forEach { s ->
                    arr.put(JSONObject().apply {
                        put("sender", s.sender); put("label", s.label)
                        put("defaultAccountId", s.defaultAccountId ?: JSONObject.NULL)
                        put("enabled", s.enabled)
                    })
                }
            })

            put("reminders", JSONArray().also { arr ->
                dao.allRemindersOnce().forEach { r ->
                    arr.put(JSONObject().apply {
                        put("title", r.title); put("message", r.message)
                        put("frequency", r.frequency); put("hour", r.hour); put("minute", r.minute)
                        put("daysOfWeek", r.daysOfWeek); put("dayOfMonth", r.dayOfMonth)
                        put("action", r.action); put("enabled", r.enabled)
                    })
                }
            })
        }
        return root.toString(2)
    }

    suspend fun exportJson(ctx: Context, dao: SmmDao): File {
        val f = File(exportDir(ctx), "smm-backup-${stamp()}.json")
        val json = buildJson(dao)
        return writeAtomic(f) { it.writeText(json) }
            .also { dao.log(EventLogEntity(tag = "EXPORT", message = "JSON ${it.name}")) }
    }

    /* ══════════════════ CSV ══════════════════ */
    private fun esc(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

    suspend fun buildCsv(dao: SmmDao): String {
        val groups = dao.allGroupsOnce().associateBy { it.id }
        val accounts = dao.allAccountsOnce().associateBy { it.id }
        val cats = dao.allCategoriesOnce().associateBy { it.id }
        val people = dao.allPeopleOnce().associateBy { it.id }
        val df = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

        val sb = StringBuilder(
            "Date,Kind,Merchant,Note,Amount,Currency,Group,Account,Category," +
            "Person,PersonEntryType,CounterAmount,CounterCurrency,RateUsed,Source,Tags\n"
        )
        dao.allTransactionsOnce().sortedByDescending { it.occurredAt }.forEach { t ->
            val acc = accounts[t.accountId]
            val grp = acc?.let { groups[it.groupId] }
            val tags = dao.tagsFor(t.id).joinToString(" ") { "#" + it.name }
            val decimals = Currencies.decimals(t.currency)
            sb.append(esc(df.format(Date(t.occurredAt)))).append(',')
              .append(t.kind).append(',')
              .append(esc(t.merchant)).append(',')
              .append(esc(t.note)).append(',')
              // Plain decimal so spreadsheets treat it as a number.
              .append(java.math.BigDecimal(t.amountMinor).movePointLeft(decimals).toPlainString()).append(',')
              .append(t.currency).append(',')
              .append(esc(grp?.name ?: "")).append(',')
              .append(esc(acc?.name ?: "")).append(',')
              .append(esc(t.categoryId?.let { cats[it]?.name } ?: "")).append(',')
              .append(esc(t.personId?.let { people[it]?.name } ?: "")).append(',')
              .append(t.personEntryType ?: "").append(',')
              .append(t.fxCounterMinor?.let {
                  java.math.BigDecimal(it)
                      .movePointLeft(Currencies.decimals(t.fxCounterCurrency ?: t.currency))
                      .toPlainString()
              } ?: "").append(',')
              .append(t.fxCounterCurrency ?: "").append(',')
              .append(t.fxRateUsed?.toString() ?: "").append(',')
              .append(t.source).append(',')
              .append(esc(tags)).append('\n')
        }
        return sb.toString()
    }

    suspend fun exportCsv(ctx: Context, dao: SmmDao): File {
        val f = File(exportDir(ctx), "smm-transactions-${stamp()}.csv")
        val csv = buildCsv(dao)
        // BOM so Excel opens UTF-8 currency symbols correctly.
        return writeAtomic(f) { it.writeText("\uFEFF" + csv) }
            .also { dao.log(EventLogEntity(tag = "EXPORT", message = "CSV ${it.name}")) }
    }

    /* ══════════════════ XLSX ══════════════════
     * A real workbook, written by hand. xlsx is just a zip of XML, so this
     * needs no library — which matters when the goal is a small APK with
     * no third-party code touching your financial data.
     */
    private fun xmlEscape(s: String) = s
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&apos;")

    private fun colName(i: Int): String {
        var n = i; val sb = StringBuilder()
        while (n >= 0) { sb.insert(0, ('A' + n % 26)); n = n / 26 - 1 }
        return sb.toString()
    }

    private data class Sheet(val name: String, val rows: List<List<Any?>>)

    private fun sheetXml(rows: List<List<Any?>>): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>""")
        rows.forEachIndexed { r, row ->
            sb.append("<row r=\"${r + 1}\">")
            row.forEachIndexed { c, cell ->
                val ref = "${colName(c)}${r + 1}"
                when (cell) {
                    null -> {}
                    is Number -> sb.append("<c r=\"$ref\"><v>$cell</v></c>")
                    else -> sb.append(
                        "<c r=\"$ref\" t=\"inlineStr\"><is><t>${xmlEscape(cell.toString())}</t></is></c>"
                    )
                }
            }
            sb.append("</row>")
        }
        sb.append("</sheetData></worksheet>")
        return sb.toString()
    }

    suspend fun exportXlsx(ctx: Context, dao: SmmDao): File {
        val groups = dao.allGroupsOnce().associateBy { it.id }
        val accounts = dao.allAccountsOnce()
        val accById = accounts.associateBy { it.id }
        val cats = dao.allCategoriesOnce().associateBy { it.id }
        val people = dao.allPeopleOnce().associateBy { it.id }
        val txs = dao.allTransactionsOnce().sortedByDescending { it.occurredAt }
        val df = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

        fun dec(minor: Long, cur: String): Double =
            java.math.BigDecimal(minor).movePointLeft(Currencies.decimals(cur)).toDouble()

        val txRows = mutableListOf<List<Any?>>(
            listOf("Date", "Kind", "Merchant", "Note", "Amount", "Currency",
                   "Group", "Account", "Category", "Person", "Entry type",
                   "Counter amount", "Counter currency", "Rate used", "Source")
        )
        txs.forEach { t ->
            val acc = accById[t.accountId]
            txRows.add(listOf(
                df.format(Date(t.occurredAt)), t.kind, t.merchant, t.note,
                dec(t.amountMinor, t.currency), t.currency,
                acc?.let { groups[it.groupId]?.name } ?: "", acc?.name ?: "",
                t.categoryId?.let { cats[it]?.name } ?: "",
                t.personId?.let { people[it]?.name } ?: "",
                t.personEntryType ?: "",
                t.fxCounterMinor?.let { dec(it, t.fxCounterCurrency ?: t.currency) },
                t.fxCounterCurrency ?: "", t.fxRateUsed, t.source
            ))
        }

        // Balances per account — the figure you actually want to check.
        val balRows = mutableListOf<List<Any?>>(
            listOf("Group", "Account", "Type", "Currency", "Opening", "Movements", "Balance")
        )
        accounts.forEach { a ->
            val movements = txs.filter { it.accountId == a.id && it.confirmed }
                .sumOf { it.signedMinor }
            balRows.add(listOf(
                groups[a.groupId]?.name ?: "", a.name, a.type, a.currency,
                dec(a.openingBalanceMinor, a.currency),
                dec(movements, a.currency),
                dec(a.openingBalanceMinor + movements, a.currency)
            ))
        }

        // Totals per currency — never combined into one number.
        val curRows = mutableListOf<List<Any?>>(
            listOf("Currency", "Total held", "Spent", "Received")
        )
        val allCurrencies = accounts.map { it.currency }.toSet() + txs.map { it.currency }.toSet()
        allCurrencies.sorted().forEach { cur ->
            val held = accounts.filter { it.currency == cur }.sumOf { a ->
                a.openingBalanceMinor + txs.filter { it.accountId == a.id && it.confirmed }
                    .sumOf { it.signedMinor }
            }
            curRows.add(listOf(
                cur, dec(held, cur),
                dec(txs.filter { it.currency == cur && it.countsAsSpend }.sumOf { it.amountMinor }, cur),
                dec(txs.filter { it.currency == cur && it.countsAsIncome }.sumOf { it.amountMinor }, cur)
            ))
        }

        // Who owes whom, per currency.
        val peopleRows = mutableListOf<List<Any?>>(
            listOf("Person", "Currency", "Outstanding (+they owe / −you owe)", "Lifetime cost to you")
        )
        people.values.forEach { p ->
            val rows = txs.filter { it.personId == p.id && it.confirmed }
            rows.map { it.currency }.toSet().sorted().forEach { cur ->
                val inCur = rows.filter { it.currency == cur }
                val net = inCur.sumOf {
                    when (it.personEntryType) {
                        PersonEntryType.PAID_FOR, PersonEntryType.SETTLE_OUT -> it.amountMinor
                        PersonEntryType.RECEIVED_FOR, PersonEntryType.SETTLE_IN -> -it.amountMinor
                        else -> 0L
                    }
                }
                val cost = inCur.filter { it.personEntryType in PersonEntryType.PERSONAL_COST }
                    .sumOf { it.amountMinor }
                peopleRows.add(listOf(p.name, cur, dec(net, cur), dec(cost, cur)))
            }
        }

        val sheets = listOf(
            Sheet("Transactions", txRows),
            Sheet("Balances", balRows),
            Sheet("By currency", curRows),
            Sheet("People", peopleRows)
        )

        val f = File(exportDir(ctx), "smm-workbook-${stamp()}.xlsx")
        return writeAtomic(f) { tmp ->
            ZipOutputStream(FileOutputStream(tmp)).use { zip ->
                fun put(name: String, content: String) {
                    zip.putNextEntry(ZipEntry(name))
                    zip.write(content.toByteArray())
                    zip.closeEntry()
                }

                put("[Content_Types].xml", buildString {
                    append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
                    append("""<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""")
                    append("""<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""")
                    append("""<Default Extension="xml" ContentType="application/xml"/>""")
                    append("""<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>""")
                    sheets.indices.forEach {
                        append("""<Override PartName="/xl/worksheets/sheet${it + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""")
                    }
                    append("</Types>")
                })

                put("_rels/.rels",
                    """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
                    """<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""" +
                    """<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>""" +
                    "</Relationships>")

                put("xl/workbook.xml", buildString {
                    append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
                    append("""<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>""")
                    sheets.forEachIndexed { i, s ->
                        append("""<sheet name="${xmlEscape(s.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>""")
                    }
                    append("</sheets></workbook>")
                })

                put("xl/_rels/workbook.xml.rels", buildString {
                    append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
                    append("""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
                    sheets.indices.forEach {
                        append("""<Relationship Id="rId${it + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${it + 1}.xml"/>""")
                    }
                    append("</Relationships>")
                })

                sheets.forEachIndexed { i, s ->
                    put("xl/worksheets/sheet${i + 1}.xml", sheetXml(s.rows))
                }
            }
        }.also { dao.log(EventLogEntity(tag = "EXPORT", message = "XLSX ${it.name}")) }
    }

    /* ══════════════════ ENCRYPTED ARCHIVE ══════════════════ */

    /**
     * AES-256-GCM over the JSON, key from PBKDF2-HMAC-SHA256 (210k).
     * Layout: "SMMZ1" | salt(16) | iv(12) | ciphertext+tag
     * Self-describing, so a future version can still read it.
     */
    suspend fun exportEncrypted(ctx: Context, dao: SmmDao, passphrase: CharArray): File {
        val json = buildJson(dao).toByteArray()
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val spec = PBEKeySpec(passphrase, salt, 210_000, 256)
        val key = SecretKeySpec(
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded,
            "AES"
        )
        spec.clearPassword()

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val iv = cipher.iv
        val ct = cipher.doFinal(json)

        val f = File(exportDir(ctx), "smm-encrypted-${stamp()}.smmz")
        return writeAtomic(f) {
            it.outputStream().use { os ->
                os.write("SMMZ1".toByteArray()); os.write(salt); os.write(iv); os.write(ct)
            }
        }.also { dao.log(EventLogEntity(tag = "EXPORT", message = "Encrypted ${it.name}")) }
    }

    /** Decrypt a .smmz back to JSON. Returns null if the passphrase is wrong. */
    fun decryptArchive(file: File, passphrase: CharArray): String? = runCatching {
        val all = file.readBytes()
        val magic = String(all.copyOfRange(0, 5))
        require(magic == "SMMZ1") { "Not a Secure Money Manager archive" }
        val salt = all.copyOfRange(5, 21)
        val iv = all.copyOfRange(21, 33)
        val ct = all.copyOfRange(33, all.size)

        val spec = PBEKeySpec(passphrase, salt, 210_000, 256)
        val key = SecretKeySpec(
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded,
            "AES"
        )
        spec.clearPassword()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        String(cipher.doFinal(ct))
    }.getOrNull()

    /* ══════════════════ SHARE ══════════════════ */

    /**
     * Hand a file to the Android share sheet. The receiving app does the
     * sending — this app has no network access of its own.
     */
    fun shareIntent(ctx: Context, file: File): Intent {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + AUTHORITY_SUFFIX, file)
        val mime = when (file.extension.lowercase()) {
            "csv" -> "text/csv"
            "json" -> "application/json"
            "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            else -> "application/octet-stream"
        }
        return Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, file.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun listExports(ctx: Context): List<File> =
        exportDir(ctx).listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun prune(ctx: Context, keep: Int = 20) {
        listExports(ctx).drop(keep).forEach { it.delete() }
    }
}
