package com.securemoney.manager.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * ══════════════════════════════════════════════════════════════════
 *  HOW THE ENCRYPTION WORKS
 * ══════════════════════════════════════════════════════════════════
 *
 * The database is encrypted with SQLCipher (AES-256). The 32-byte
 * database key is generated once, at random, and never derived directly
 * from what you type. Instead it is stored TWICE, wrapped two ways:
 *
 *   1. Wrapped by a key derived from your passphrase or passcode
 *      (PBKDF2-HMAC-SHA256, 210,000 iterations, random 16-byte salt).
 *      This is the recovery path — it works on any device, after a
 *      factory reset, from a restored backup.
 *
 *   2. Wrapped by an AES key held in the Android Keystore, which is
 *      backed by hardware (StrongBox / TEE) and gated on biometric.
 *      This is the convenience path — fingerprint, no typing.
 *
 * Why two wrappers instead of deriving the key from the passphrase?
 * Because it lets you CHANGE your passphrase without re-encrypting the
 * whole database — you just re-wrap the same key. And it means losing
 * your fingerprint enrolment doesn't lose your data.
 *
 * What this protects against: someone with your unlocked phone poking
 * around, ADB backup extraction, a stolen device, a leaked Nextcloud
 * backup file (exports can be encrypted separately).
 *
 * What it does NOT protect against: malware running as root while the
 * database is already open. Nothing on Android does.
 *
 * ⚠️  THERE IS NO PASSPHRASE RECOVERY. If you forget it and lose your
 * biometric enrolment, the data is unrecoverable by design. That is the
 * point of encryption. Keep an exported backup somewhere safe.
 */
object Crypto {

    private const val PREFS = "docket_crypto"
    private const val K_SALT = "salt"
    private const val K_PASS_WRAPPED = "pass_wrapped"
    private const val K_KEYSTORE_WRAPPED = "ks_wrapped"
    private const val K_KDF_ITERATIONS = "kdf_iter"
    private const val K_MODE = "lock_mode"          // none | passcode | passphrase
    private const val K_FAILED = "failed_attempts"

    private const val KEYSTORE_ALIAS = "docket_db_key_wrapper"
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"

    /** OWASP-current floor for PBKDF2-HMAC-SHA256. Stored, so it can be raised later. */
    private const val DEFAULT_ITERATIONS = 210_000
    private const val DB_KEY_BYTES = 32
    private const val GCM_TAG_BITS = 128

    enum class LockMode { NONE, PASSCODE, PASSPHRASE }

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun lockMode(ctx: Context): LockMode =
        runCatching { LockMode.valueOf(prefs(ctx).getString(K_MODE, "NONE")!!) }
            .getOrDefault(LockMode.NONE)

    fun isEncrypted(ctx: Context): Boolean = lockMode(ctx) != LockMode.NONE

    fun hasBiometricWrap(ctx: Context): Boolean =
        prefs(ctx).contains(K_KEYSTORE_WRAPPED)

    fun failedAttempts(ctx: Context): Int = prefs(ctx).getInt(K_FAILED, 0)

    fun recordFailure(ctx: Context): Int {
        val n = failedAttempts(ctx) + 1
        prefs(ctx).edit().putInt(K_FAILED, n).apply()
        return n
    }

    fun clearFailures(ctx: Context) =
        prefs(ctx).edit().putInt(K_FAILED, 0).apply()

    /**
     * Delay after repeated wrong entries. Not a lockout — locking you out of
     * your own ledger permanently is worse than a slow brute force against a
     * key that already has 210k KDF iterations behind it.
     */
    fun backoffMillis(attempts: Int): Long = when {
        attempts < 3 -> 0
        attempts < 6 -> 5_000
        attempts < 10 -> 30_000
        else -> 120_000
    }

    /* ── Key derivation ────────────────────────────────────────────── */

    private fun deriveFromSecret(secret: CharArray, salt: ByteArray, iterations: Int): SecretKey {
        val spec = PBEKeySpec(secret, salt, iterations, DB_KEY_BYTES * 8)
        val kf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val bytes = kf.generateSecret(spec).encoded
        spec.clearPassword()
        return SecretKeySpec(bytes, "AES")
    }

    private fun wrap(key: SecretKey, payload: ByteArray): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key)
        val iv = c.iv
        val ct = c.doFinal(payload)
        return Base64.encodeToString(iv + ct, Base64.NO_WRAP)
    }

    private fun unwrap(key: SecretKey, blob: String): ByteArray {
        val all = Base64.decode(blob, Base64.NO_WRAP)
        val iv = all.copyOfRange(0, 12)
        val ct = all.copyOfRange(12, all.size)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
        return c.doFinal(ct)
    }

    /* ── Android Keystore wrapper (biometric convenience path) ─────── */

    private fun keystoreKey(requireBiometric: Boolean): SecretKey {
        val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        (ks.getKey(KEYSTORE_ALIAS, null) as? SecretKey)?.let { return it }

        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEYSTORE_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            // Invalidate if the user adds or removes a fingerprint: prevents
            // someone enrolling their own finger to gain access.
            .apply {
                if (requireBiometric) {
                    setUserAuthenticationRequired(true)
                    setInvalidatedByBiometricEnrollment(true)
                    if (android.os.Build.VERSION.SDK_INT >= 30) {
                        setUserAuthenticationParameters(
                            0, KeyProperties.AUTH_BIOMETRIC_STRONG or
                               KeyProperties.AUTH_DEVICE_CREDENTIAL
                        )
                    }
                }
            }
            .build()
        gen.init(spec)
        return gen.generateKey()
    }

    /* ── Setup ─────────────────────────────────────────────────────── */

    /**
     * Turn encryption on. Generates the database key and wraps it with the
     * secret you supply. Returns the raw key so the caller can open the DB.
     */
    fun enableEncryption(
        ctx: Context,
        secret: CharArray,
        mode: LockMode,
        alsoWrapWithBiometric: Boolean
    ): ByteArray {
        val dbKey = ByteArray(DB_KEY_BYTES).also { SecureRandom().nextBytes(it) }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val iterations = DEFAULT_ITERATIONS

        val passKey = deriveFromSecret(secret, salt, iterations)
        val passWrapped = wrap(passKey, dbKey)

        val e = prefs(ctx).edit()
            .putString(K_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(K_PASS_WRAPPED, passWrapped)
            .putInt(K_KDF_ITERATIONS, iterations)
            .putString(K_MODE, mode.name)

        if (alsoWrapWithBiometric) {
            runCatching {
                val ksWrapped = wrap(keystoreKey(requireBiometric = true), dbKey)
                e.putString(K_KEYSTORE_WRAPPED, ksWrapped)
            }.onFailure {
                // Hardware keystore unavailable — passphrase path still works.
                e.remove(K_KEYSTORE_WRAPPED)
            }
        }
        e.apply()
        return dbKey
    }

    /** Unlock with the typed secret. Returns null if it's wrong. */
    fun unlockWithSecret(ctx: Context, secret: CharArray): ByteArray? {
        val p = prefs(ctx)
        val salt = Base64.decode(p.getString(K_SALT, null) ?: return null, Base64.NO_WRAP)
        val wrapped = p.getString(K_PASS_WRAPPED, null) ?: return null
        val iterations = p.getInt(K_KDF_ITERATIONS, DEFAULT_ITERATIONS)
        return runCatching {
            unwrap(deriveFromSecret(secret, salt, iterations), wrapped)
        }.getOrNull()
    }

    /**
     * Unlock via the Keystore-wrapped copy. Call only after a successful
     * BiometricPrompt — the Keystore itself enforces that too.
     */
    fun unlockWithBiometric(ctx: Context): ByteArray? {
        val wrapped = prefs(ctx).getString(K_KEYSTORE_WRAPPED, null) ?: return null
        return runCatching { unwrap(keystoreKey(requireBiometric = true), wrapped) }.getOrNull()
    }

    /**
     * Change the passphrase or passcode. Re-wraps the SAME database key, so
     * nothing has to be re-encrypted and the operation can't half-fail.
     */
    fun changeSecret(
        ctx: Context,
        oldSecret: CharArray,
        newSecret: CharArray,
        newMode: LockMode
    ): Boolean {
        val dbKey = unlockWithSecret(ctx, oldSecret) ?: return false
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val iterations = DEFAULT_ITERATIONS
        val wrapped = wrap(deriveFromSecret(newSecret, salt, iterations), dbKey)
        prefs(ctx).edit()
            .putString(K_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(K_PASS_WRAPPED, wrapped)
            .putInt(K_KDF_ITERATIONS, iterations)
            .putString(K_MODE, newMode.name)
            .apply()
        return true
    }

    /** Add or refresh the biometric wrapper without changing the passphrase. */
    fun enableBiometricWrap(ctx: Context, secret: CharArray): Boolean {
        val dbKey = unlockWithSecret(ctx, secret) ?: return false
        return runCatching {
            val wrapped = wrap(keystoreKey(requireBiometric = true), dbKey)
            prefs(ctx).edit().putString(K_KEYSTORE_WRAPPED, wrapped).apply()
            true
        }.getOrDefault(false)
    }

    fun disableBiometricWrap(ctx: Context) {
        prefs(ctx).edit().remove(K_KEYSTORE_WRAPPED).apply()
        runCatching {
            KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
                .deleteEntry(KEYSTORE_ALIAS)
        }
    }

    /**
     * SQLCipher's native library. SupportOpenHelperFactory loads this for
     * you, but the direct SQLiteDatabase API below does not — without this
     * call it throws UnsatisfiedLinkError at runtime.
     */
    private fun ensureNativeLoaded() {
        runCatching { System.loadLibrary("sqlcipher") }
    }

    /**
     * Delete the -wal and -shm sidecar files belonging to a database.
     * Leaving a stale WAL next to a swapped-in database file causes SQLite
     * to try to replay a journal that belongs to different content, which
     * corrupts or refuses to open it.
     */
    private fun deleteSidecars(ctx: Context, name: String) {
        listOf("$name-wal", "$name-shm", "$name-journal").forEach {
            runCatching { ctx.getDatabasePath(it).delete() }
        }
    }

    /**
     * Physically rewrite the on-disk database file as an encrypted one.
     *
     * Generating a key and wrapping it (above) does nothing to bytes
     * already sitting on disk. A plaintext SQLite file stays plaintext
     * until it is actually re-written with SQLCipher, which is what this
     * does via SQLCipher's own `sqlcipher_export`: attach a brand-new
     * encrypted file, copy every table into it, then swap the files. If
     * anything fails, the original plaintext file is left untouched —
     * there is no window where the data exists nowhere.
     *
     * The caller MUST have closed any open Room/AppDatabase handle on this
     * file first, and must reopen with AppDatabase.get(ctx, key) after.
     */
    fun encryptExistingDatabase(ctx: Context, dbKey: ByteArray): Boolean {
        ensureNativeLoaded()
        val plainFile = ctx.getDatabasePath("smm.db")
        if (!plainFile.exists()) return true   // nothing to migrate yet

        val encryptedFile = ctx.getDatabasePath("smm_encrypting.db")
        if (encryptedFile.exists()) encryptedFile.delete()
        deleteSidecars(ctx, "smm_encrypting.db")

        val hexKey = dbKey.joinToString("") { "%02x".format(it) }

        return runCatching {
            // Empty passphrase = open the existing PLAINTEXT file.
            val db = net.zetetic.database.sqlcipher.SQLiteDatabase.openOrCreateDatabase(
                plainFile.absolutePath, "", null
            )
            db.use {
                it.execSQL(
                    "ATTACH DATABASE '${encryptedFile.absolutePath}' AS encrypted KEY \"x'$hexKey'\""
                )
                // A SELECT, not a statement: it must be run as a query and
                // the cursor stepped, or the export never actually runs.
                it.rawQuery("SELECT sqlcipher_export('encrypted')", null)
                    .use { c -> c.moveToFirst() }
                it.execSQL("DETACH DATABASE encrypted")
            }

            if (encryptedFile.length() <= 0L) {
                throw IllegalStateException("Encrypted copy came out empty")
            }

            // Only now, with the encrypted copy written and non-empty, replace
            // the original. Keep a backup until the swap is confirmed.
            val backup = ctx.getDatabasePath("smm_preencryption.bak")
            plainFile.copyTo(backup, overwrite = true)
            if (!plainFile.delete()) throw IllegalStateException("Could not remove plaintext file")
            deleteSidecars(ctx, "smm.db")
            if (!encryptedFile.renameTo(plainFile)) {
                // Swap failed — put the original back before giving up.
                backup.copyTo(plainFile, overwrite = true)
                throw IllegalStateException("Could not install encrypted file")
            }
            backup.delete()
            true
        }.getOrElse {
            // Leave the original plaintext file exactly as it was.
            encryptedFile.delete()
            deleteSidecars(ctx, "smm_encrypting.db")
            false
        }
    }

    /**
     * Reverse of the above: write a plaintext copy out from the encrypted
     * file, for turning encryption off. Same swap-on-success pattern.
     */
    fun decryptExistingDatabase(ctx: Context, dbKey: ByteArray): Boolean {
        ensureNativeLoaded()
        val encFile = ctx.getDatabasePath("smm.db")
        if (!encFile.exists()) return true

        val plainFile = ctx.getDatabasePath("smm_decrypting.db")
        if (plainFile.exists()) plainFile.delete()
        deleteSidecars(ctx, "smm_decrypting.db")

        val hexKey = dbKey.joinToString("") { "%02x".format(it) }

        return runCatching {
            val db = net.zetetic.database.sqlcipher.SQLiteDatabase.openOrCreateDatabase(
                encFile.absolutePath, "x'$hexKey'", null
            )
            db.use {
                it.execSQL("ATTACH DATABASE '${plainFile.absolutePath}' AS plain KEY ''")
                it.rawQuery("SELECT sqlcipher_export('plain')", null)
                    .use { c -> c.moveToFirst() }
                it.execSQL("DETACH DATABASE plain")
            }

            if (plainFile.length() <= 0L) {
                throw IllegalStateException("Plaintext copy came out empty")
            }

            val backup = ctx.getDatabasePath("smm_preplaintext.bak")
            encFile.copyTo(backup, overwrite = true)
            if (!encFile.delete()) throw IllegalStateException("Could not remove encrypted file")
            deleteSidecars(ctx, "smm.db")
            if (!plainFile.renameTo(encFile)) {
                backup.copyTo(encFile, overwrite = true)
                throw IllegalStateException("Could not install plaintext file")
            }
            backup.delete()
            true
        }.getOrElse {
            plainFile.delete()
            deleteSidecars(ctx, "smm_decrypting.db")
            false
        }
    }

    /** Strength feedback shown live while setting a passphrase. */
    fun assess(secret: String, mode: LockMode): Pair<Int, String> {
        if (mode == LockMode.PASSCODE) {
            val digits = secret.length
            val trivial = secret.toSet().size <= 2 ||
                secret in listOf("123456", "000000", "111111", "123123", "654321")
            return when {
                digits < 4 -> 0 to "At least 4 digits."
                trivial -> 1 to "Too predictable — avoid repeats and sequences."
                digits < 6 -> 2 to "Workable. Six digits is meaningfully better."
                else -> 3 to "Good passcode."
            }
        }
        var score = 0
        if (secret.length >= 12) score++
        if (secret.length >= 20) score++
        if (secret.any { it.isDigit() } && secret.any { it.isLetter() }) score++
        if (secret.contains(' ')) score++          // passphrases beat passwords
        return when {
            secret.length < 8 -> 0 to "At least 8 characters."
            score <= 1 -> 1 to "Weak. Try four unrelated words."
            score == 2 -> 2 to "Reasonable."
            else -> 3 to "Strong."
        }
    }
}
