# Secure Money Manager

A multi-currency personal finance ledger for Android. Offline by construction, optionally encrypted, and free software under GPL-3.0.

Built by Sahil Shaikh and contributors.

---

## What makes it different

**It cannot phone home.** The app does not request Android's `INTERNET` permission. Without it, the operating system refuses to let the app open a network connection at all — it cannot upload your records, load an advert, or contact any server, regardless of what its code says. You can verify this yourself in two ways:

```bash
# Check the built APK's permission list
aapt dump permissions app-release.apk

# Or just read the manifest
grep -i internet app/src/main/AndroidManifest.xml   # returns nothing
```

**It never mixes currencies.** Money is stored as `Long` minor units (fils, paise, cents), never `Double`, and every amount travels with its currency code. Totals accumulate into a `MoneyBag`, which holds one figure per currency and *deliberately has no method that returns a single combined number* — because that number cannot exist without an exchange rate, and a rate baked into a stored total is a number that silently goes stale. You see `QAR 22,110 · INR 222,700`, which is two true figures instead of one invented one.

**Nothing is read without your say-so.** Bank SMS and notification reading ship switched off. Turning them on isn't enough — you then approve individual senders or apps one at a time. There is no "read everything" option. Content from an unapproved sender is discarded without being opened; the app records only that the sender exists, so you can approve it later.

---

## Building it

**Requirements:** Android Studio (Ladybug or newer), JDK 17, Android SDK 36.

1. Unzip the project.
2. In Android Studio choose **Open**, and select the `smm` folder itself — not a file inside it.
3. Wait for Gradle sync. All dependencies are declared, so this pulls everything automatically.
4. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.

The debug APK installs alongside a release build, since debug uses the application ID suffix `.debug`.

### Running the tests

```bash
./gradlew test
```

This is where the money guarantees are actually checked — minor-unit conversion, three-decimal currencies (KWD/BHD/OMR), zero-decimal currencies (JPY), HALF_UP rounding, the "1000 × 0.10 must equal exactly 100.00" float-drift case, and the full matrix of what counts as your spending versus someone else's.

### First build caveat

This project was written and cross-checked but has **not** been compiled by its author, who had no Android toolchain available. Expect Android Studio to possibly flag a small number of issues on first build — an import, or a Compose API that shifted between library versions. These are normally one-line fixes that the IDE points at directly. Please open an issue if you hit one.

The single piece to test deliberately before trusting it with real records is **enabling encryption**, which uses SQLCipher's `sqlcipher_export` through a direct native API. It is written to fail *safely* — on any error it returns false and leaves your original database file untouched — but confirm it works on your device before relying on it.

---

## Architecture

```
app/src/main/java/com/securemoney/manager/
├── data/
│   ├── Money.kt          Long minor units, Currencies table, MoneyBag
│   ├── Entities.kt        16 Room entities + TxKind + PersonEntryType
│   ├── AppDatabase.kt     DAO with per-currency projections, migrations
│   └── Crypto.kt          Key wrapping, DB re-encryption
├── parse/
│   └── TransactionParser.kt   Pure, testable, no Android dependency
├── io/
│   ├── ExportManager.kt   JSON / CSV / XLSX / encrypted .smmz
│   └── ImportManager.kt   Merge or replace, full ID remapping
├── ui/                    Compose screens and sheets
├── Platform.kt            Settings, seeding, capture gate, reminders
├── BiometricAuth.kt       BiometricPrompt wrapper
└── MainActivity.kt        Onboarding → Unlock → Main
```

### The rules the code enforces

These are load-bearing. Breaking one produces a silently wrong number rather than a crash, which is the dangerous kind of bug — so each has a test.

| Rule | Why |
|---|---|
| Money is `Long` minor units, never `Double` | 0.10 isn't representable in binary floating point; the error compounds |
| Currency always travels with the amount | Stops 5000 paise + 2000 fils = a meaningless 7000 |
| Balances are derived, never stored | `opening + SUM(movements)` can't drift from its transactions |
| Groups ≠ currencies | A group is organisational (Qatar, Business, Travel) and may hold accounts in any mix of currencies |
| Budgets are per (category, currency) | "Groceries" can hold a QAR 800 cap *and* an INR 15,000 cap independently |
| Transfers are two linked rows, budget-neutral | Moving your own money between your own accounts is not spending |
| Absorbing an advance *reclassifies* the original row | Inserting a second row would double-count cash that already left |
| Cross-currency rates are frozen onto the record | You supply the rate; it's stored permanently and never recalculated, so it can't drift |
| Destructive migration is disabled | A forgotten migration crashes loudly instead of wiping your history |
| Biometric failure fails *open* | No fingerprint enrolment means you get in with your passphrase, not locked out forever |

### The people model

The tricky part. Money you move on someone else's behalf has several possible endings:

- `paid_for` / `received_for` — an open claim. **Not** your spending; you expect it back.
- `settle_in` / `settle_out` — cash settlement; the claim clears.
- `absorbed` — you've given up on reimbursement. Becomes **your** expense, and the claim clears so it doesn't linger as a debt forever.
- `offset_support` — same as absorbed, *and* it counts toward that month's recurring support, so you skip that transfer. This is the case that can cross currencies.
- `support_paid` — the recurring payment itself. Your cost immediately, never a claim.

---

## Customising it

**Colours and theme** — `ui/Theme.kt`. Nothing is hardcoded in the screens.

**Adding a currency** — add a `CurrencyInfo` to `Currencies.BUILT_IN` in `data/Money.kt`. Mind the `decimals` field: KWD/BHD/OMR use 3, JPY uses 0.

**Adding a bank's SMS format** — do it in the app, not the code: Settings → Developer mode has a parser sandbox, and Settings → Bank SMS senders lets you attach a custom rule. No rebuild needed.

**Adding a database field** —
1. Add it to the entity **with a default value**
2. Bump `DB_VERSION` in `AppDatabase.kt`
3. Add a `Migration` with the `ALTER TABLE`

Skipping step 3 crashes on next launch rather than deleting anyone's data. That's intentional.

**Adding a screen** — add it to `ALL_NAV` in `Platform.kt` and to the `when (route)` block in `MainActivity.kt`.

---

## Distribution

**Google Play will most likely reject this app.** `READ_SMS` and `RECEIVE_SMS` are Restricted Permissions, granted essentially only to apps that are the user's default SMS handler. This app is not, and shouldn't be.

Realistic distribution routes:

- **Direct APK** — build it and install it yourself. Simplest.
- **GitHub Releases + [Obtainium](https://github.com/ImranR98/Obtainium)** — gives you update notifications without a store.
- **F-Droid** — the ideologically correct home for it, but expect months of review and a reproducible-build requirement.

You can also build a variant with the SMS permissions and `SmsReceiver` stripped from the manifest; everything else (manual entry, notification reading, import, export) works unchanged, and that variant is Play-compatible.

---

## Privacy

There is no privacy policy to read, because there is nothing to disclose. No analytics, no crash reporting, no telemetry, no ads, no account, no server. The app has no network permission with which to send anything.

Exported files in JSON, CSV and XLSX format are **not** encrypted. A backup sitting in cloud storage is only as private as that storage. Use the encrypted `.smmz` export if that matters.

**There is no passphrase recovery.** If you enable encryption and forget your passphrase, and also lose your biometric enrolment, the data is unrecoverable — by you, by us, by anyone. There is no master key and no reset. That is what encryption *is*. Keep an exported backup somewhere safe.

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Bank formats that don't parse are the single most useful thing to report — there is no analytics telling us, so we only know if you say so.

Please don't include passwords, passphrases, full account numbers, or unredacted bank messages in an issue.

## Licence

GPL-3.0. See [LICENSE](LICENSE).

Once released, this version stays free and open forever — that cannot be revoked, including by its authors. Future versions may be licensed differently, but every version published up to that point remains free under GPL-3.0, and anyone is free to continue from it.

## Contact

ops@sahilshaikh.org
